<?php
	$conn = mysqli_connect('localhost', 'fqckxrbk_vishalbro', 'fqckxrbk_vishalbro', 'fqckxrbk_vishalbro');
	
	if (!$conn) {
		echo "Error: " . mysqli_connect_error();
		exit();
	}
	
	date_default_timezone_set("Asia/Kolkata"); 
?>