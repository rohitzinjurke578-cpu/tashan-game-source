<?php
session_start();
if ($_SESSION['unohs'] == null) {
    header("location:index.php?msg=unauthorized");
}
date_default_timezone_set("Asia/Kolkata");
include("conn.php");

// Generate unique token for form
if (!isset($_SESSION['form_token'])) {
    $_SESSION['form_token'] = bin2hex(random_bytes(32));
}

// Bonus type mapping (only red envelope enabled)
$bonusTypes = [
    3 => "Red envelope",
];

// Function to add bonus
function addBonus($userId, $type, $amount, $remark, $conn, $bonusTypes) {
    $tableNames = [
        3 => "hodike_balakedara",
    ];

    if (!isset($tableNames[$type])) {
        return "Invalid bonus type";
    }

    $tableName = $tableNames[$type];
    $date = date("Y-m-d H:i:s");
    $serial = "Imitator";

    $stmt = $conn->prepare("INSERT INTO $tableName (userkani, price, serial, shonu, remark, type) VALUES (?, ?, ?, ?, ?, ?)");
    if (!$stmt) {
        return "Error preparing statement0";
    }

    if (!$stmt->bind_param("idssss", $userId, $amount, $serial, $date, $remark, $bonusTypes)) {
        return "Error binding parameters";
    }

    if ($stmt->execute()) { 
    
        $wal = mysqli_query($conn, "UPDATE shonu_kaichila SET motta = motta +'".$amount."' WHERE balakedara = '".$userId."'");
    if (!$wal) {
        return "Error updating wallet: " . $conn->error;
    }
        $stmt->close();
        return "Bonus added successfully";
    } else {
        $stmt->close();
        return "Error adding bonus";
    } 
}

// Function to get bonus list
function getBonusList($conn) {
    $query = "SELECT userkani, price, shonu FROM hodike_balakedara ORDER BY shonu DESC LIMIT 50";
    $result = mysqli_query($conn, $query);
    $bonuses = [];
    
    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $bonuses[] = $row;
        }
    }
    
    return $bonuses;
}

// Handle bonus submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['bonus_form'])) {
    $userId = intval($_POST['user_id']);
    $type = intval($_POST['type']);
    $amount = floatval($_POST['amount']);
    $remark = htmlspecialchars($_POST['remark'] ?? '');

    if ($userId > 0 && $type > 0 && $amount > 0) {
        $result = addBonus($userId, $type, $amount, $remark, $conn, $bonusTypes);
        $_SESSION['toast'] = [
            'type' => 'success',
            'message' => $result
        ];
    } else {
        $_SESSION['toast'] = [
            'type' => 'error',
            'message' => 'Invalid input values'
        ];
    }
    
    header("Location: ".$_SERVER['PHP_SELF']);
    exit();
}

// Get bonus list
$bonusList = getBonusList($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
  <title>Bonus Management</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="css/common.css" rel="stylesheet">
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
        :root {
      --primary: #4f46e5;
      --primary-dark: #4338ca;
      --danger: #dc2626;
      --success: #16a34a;
      --dark: #1e293b;
      --light: #f8fafc;
    }
    
    body {
      font-family: 'Inter', sans-serif;
      background-color: #f1f5f9;
      overflow-x: hidden;
    }
    
    .wrapper {
      display: flex;
      min-height: 100vh;
    }
    
    .main-content {
      flex: 1;
      min-width: 0;
    }
    
    .form-container {
      background: white;
      padding: 1.25rem;
      border-radius: 0.5rem;
      margin: 0.5rem;
      box-shadow: 0 1px 3px rgba(0,0,0,0.1);
      max-width: 600px;
      box-sizing: border-box;
    }
    
    /* Custom Select Dropdown */
    .custom-select {
      position: relative;
      margin-bottom: 1.25rem;
    }
    
    .select-selected {
      background-color: white;
      border: 1px solid #e2e8f0;
      border-radius: 0.375rem;
      padding: 0.75rem;
      cursor: pointer;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    
    .select-selected:after {
      content: "▼";
      font-size: 0.75rem;
      color: #64748b;
      transition: transform 0.2s;
    }
    
    .select-selected.select-arrow-active:after {
      transform: rotate(180deg);
    }
    
    .select-items {
      position: absolute;
      background-color: white;
      top: 100%;
      left: 0;
      right: 0;
      z-index: 99;
      border: 1px solid #e2e8f0;
      border-radius: 0.375rem;
      max-height: 200px;
      overflow-y: auto;
      display: none;
      margin-top: 4px;
      box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }
    
    .select-items div {
      padding: 0.75rem;
      cursor: pointer;
      transition: background-color 0.2s;
    }
    
    .select-items div:hover {
      background-color: #f8fafc;
    }
    
    .select-items div.same-as-selected {
      background-color: rgba(79, 70, 229, 0.1);
      color: var(--primary);
    }
    
    /* Input styles */
    .input-field {
      width: 100%;
      padding: 0.75rem;
      border: 1px solid #e2e8f0;
      border-radius: 0.375rem;
      margin-bottom: 1.25rem;
      font-size: 0.875rem;
    }
    
    .input-field:focus {
      outline: none;
      border-color: var(--primary);
      box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1);
    }
    
    /* Buttons */
    .btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: 0.625rem 1.25rem;
      border-radius: 0.375rem;
      font-weight: 500;
      font-size: 0.875rem;
      cursor: pointer;
      transition: all 0.2s;
      border: none;
    }
    
    .btn-primary {
      background-color: var(--primary);
      color: white;
    }
    
    .btn-primary:hover {
      background-color: var(--primary-dark);
    }
    
    /* Toast styles */
    #toast-container {
      position: fixed;
      bottom: 20px;
      right: 20px;
      z-index: 9999;
    }
    
    .toast {
      min-width: 280px;
      padding: 12px 16px;
      margin-bottom: 10px;
      border-radius: 8px;
      color: white;
      font-size: 14px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      animation: slideIn 0.3s, fadeOut 0.5s 2.5s forwards;
    }
    
    .toast-success {
      background-color: var(--success);
    }
    
    .toast-error {
      background-color: var(--danger);
    }
    
    .toast-close {
      background: none;
      border: none;
      color: white;
      font-size: 18px;
      cursor: pointer;
      margin-left: 10px;
    }
    
    @keyframes slideIn {
      from { transform: translateX(100%); opacity: 0; }
      to { transform: translateX(0); opacity: 1; }
    }
    
    @keyframes fadeOut {
      from { opacity: 1; }
      to { opacity: 0; }
    }
    
    /* Bonus list styles */
    .bonus-list-container {
      background: white;
      padding: 1.25rem;
      border-radius: 0.5rem;
      margin: 0.5rem;
      box-shadow: 0 1px 3px rgba(0,0,0,0.1);
      max-width: 100%;
      box-sizing: border-box;
    }
    
    .bonus-list-header {
      font-size: 1.125rem;
      font-weight: 600;
      color: #1e293b;
      margin-bottom: 1rem;
      display: flex;
      align-items: center;
    }
    
    .bonus-list {
      width: 100%;
      border-collapse: collapse;
    }
    
    .bonus-list th {
      background-color: #f8fafc;
      padding: 0.75rem;
      text-align: left;
      font-weight: 600;
      color: #64748b;
      border-bottom: 1px solid #e2e8f0;
    }
    
    .bonus-list td {
      padding: 0.75rem;
      border-bottom: 1px solid #e2e8f0;
      color: #334155;
    }
    
    .bonus-list tr:last-child td {
      border-bottom: none;
    }
    
    .bonus-list tr:hover {
      background-color: #f8fafc;
    }
    
    .user-id {
      font-weight: 500;
      color: #1e293b;
    }
    
    .amount {
      font-weight: 600;
      color: #16a34a;
    }
    
    .time {
      color: #64748b;
      font-size: 0.875rem;
    }
    
    @media (max-width: 640px) {
      .bonus-list th, .bonus-list td {
        padding: 0.5rem;
        font-size: 0.875rem;
      }
    }
  </style>
</head>

<body>
  <div class="wrapper">
    <?php include('compass.php'); ?>
  
    <div class="main-content">
      <nav class="navbar">
        <a href="#" class="navbar-brand" id="sidebarToggle">
          <i class="fas fa-bars"></i>
          <span>Menu</span>
        </a>
        
        <ul class="navbar-nav">
          <li class="nav-item dropdown">
            <a href="#" class="nav-link" id="settingsDropdown">
              <i class="fas fa-user-cog"></i>
            </a>
            <div class="dropdown-menu" id="settingsMenu">
              <a href="logout.php" class="dropdown-item">
                <i class="fas fa-sign-out-alt"></i> Logout
              </a>
            </div>
          </li>
        </ul>
      </nav>
      
      <div class="form-container">
        <h3 class="text-lg font-semibold text-gray-800 mb-4">
          <i class="fas fa-gift text-blue-500 mr-2"></i>Assign Bonus
        </h3>
        
        <form method="POST">
          <input type="hidden" name="form_token" value="<?php echo $_SESSION['form_token']; ?>">
          <input type="hidden" name="bonus_form" value="1">
          
          <div class="mb-3">
            <label class="block text-sm font-medium text-gray-700 mb-1">User ID</label>
            <input type="number" name="user_id" class="input-field" required>
          </div>
          
          <div class="mb-3">
            <label class="block text-sm font-medium text-gray-700 mb-1">Bonus Type</label>
            <div class="custom-select">
              <div class="select-selected">Select Bonus Type</div>
              <div class="select-items select-hide">
                <?php foreach ($bonusTypes as $typeId => $typeName): ?>
                  <div data-value="<?= $typeId ?>"><?= htmlspecialchars($typeName) ?></div>
                <?php endforeach; ?>
              </div>
              <input type="hidden" name="type" id="bonus-type" required>
            </div>
          </div>
          
          <div class="mb-3">
            <label class="block text-sm font-medium text-gray-700 mb-1">Bonus Amount</label>
            <input type="number" step="0.01" name="amount" class="input-field" required>
          </div>
          
          <div class="mb-3">
            <label class="block text-sm font-medium text-gray-700 mb-1">Remark (Optional)</label>
            <textarea name="remark" class="input-field" rows="3"></textarea>
          </div>
          
          <button type="submit" class="btn btn-primary">
            <i class="fas fa-paper-plane mr-2"></i> Assign Bonus
          </button>
        </form>
      </div>
      
      <!-- Bonus List Section -->
      <div class="bonus-list-container">
        <h3 class="bonus-list-header">
          <i class="fas fa-list-ul text-blue-500 mr-2"></i>Recent Bonus Assignments
        </h3>
        
        <?php if (!empty($bonusList)): ?>
          <table class="bonus-list">
            <thead>
              <tr>
                <th>Time</th>
                <th>User ID</th>
                <th>Amount</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($bonusList as $bonus): ?>
                <tr>
                  <td class="time"><?= date('d M Y H:i', strtotime($bonus['shonu'])) ?></td>
                  <td class="user-id"><?= htmlspecialchars($bonus['userkani']) ?></td>
                  <td class="amount"><?= number_format($bonus['price'], 2) ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        <?php else: ?>
          <p class="text-gray-500">No bonus assignments found</p>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <div id="toast-container"></div>

  <script>
      // Toggle sidebar on mobile
    document.getElementById('sidebarToggle').addEventListener('click', function(e) {
      e.preventDefault();
      document.querySelector('.sidebar').classList.toggle('show');
    });
    
    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', function(e) {
      const sidebar = document.querySelector('.sidebar');
      const sidebarToggle = document.getElementById('sidebarToggle');
      
      if (window.innerWidth <= 768) {
        if (!sidebar.contains(e.target) && !sidebarToggle.contains(e.target)) {
          sidebar.classList.remove('show');
        }
      }
    });
    
    // Toggle dropdown menu
    document.getElementById('settingsDropdown').addEventListener('click', function(e) {
      e.preventDefault();
      document.getElementById('settingsMenu').classList.toggle('show');
    });
    
    // Close dropdown when clicking outside
    document.addEventListener('click', function(e) {
      if (!e.target.closest('.nav-item.dropdown')) {
        document.getElementById('settingsMenu').classList.remove('show');
      }
    });
    
    // Toggle submenus in sidebar
    document.querySelectorAll('.sidebar-menu .has-submenu > a').forEach(item => {
      item.addEventListener('click', function(e) {
        e.preventDefault();
        const parent = this.parentElement;
        const submenu = this.nextElementSibling;
        
        document.querySelectorAll('.sidebar-menu .submenu').forEach(menu => {
          if (menu !== submenu) {
            menu.classList.remove('active');
            menu.previousElementSibling.classList.remove('active');
          }
        });
        
        parent.classList.toggle('active');
        submenu.classList.toggle('active');
      });
    });
    
    // Custom select dropdown functionality
    document.addEventListener('DOMContentLoaded', function() {
      const customSelects = document.getElementsByClassName("custom-select");
      for (let i = 0; i < customSelects.length; i++) {
        const select = customSelects[i];
        const selected = select.getElementsByClassName("select-selected")[0];
        const items = select.getElementsByClassName("select-items")[0];
        const hiddenInput = select.querySelector('input[type="hidden"]');
        
        // Set default selection if only one option
        if (items.children.length === 1) {
          const firstOption = items.children[0];
          selected.textContent = firstOption.textContent;
          hiddenInput.value = firstOption.getAttribute('data-value');
          firstOption.classList.add('same-as-selected');
        }
        
        selected.addEventListener("click", function(e) {
          e.stopPropagation();
          closeAllSelect(this);
          items.classList.toggle("select-hide");
          this.classList.toggle("select-arrow-active");
        });
        
        const options = items.getElementsByTagName("div");
        for (let j = 0; j < options.length; j++) {
          options[j].addEventListener("click", function(e) {
            e.stopPropagation();
            const value = this.getAttribute("data-value");
            const text = this.textContent;
            
            // Update selected display
            selected.textContent = text;
            hiddenInput.value = value;
            
            // Highlight selected option
            const sameAsSelected = items.getElementsByClassName("same-as-selected");
            for (let k = 0; k < sameAsSelected.length; k++) {
              sameAsSelected[k].classList.remove("same-as-selected");
            }
            this.classList.add("same-as-selected");
            
            // Close dropdown
            items.classList.add("select-hide");
            selected.classList.remove("select-arrow-active");
          });
        }
      }
      
      function closeAllSelect(elmnt) {
        const selectItems = document.getElementsByClassName("select-items");
        const selectSelected = document.getElementsByClassName("select-selected");
        
        for (let i = 0; i < selectSelected.length; i++) {
          if (elmnt !== selectSelected[i]) {
            selectSelected[i].classList.remove("select-arrow-active");
          }
        }
        
        for (let i = 0; i < selectItems.length; i++) {
          if (elmnt !== selectItems[i] && elmnt !== selectSelected[i]) {
            selectItems[i].classList.add("select-hide");
          }
        }
      }
      
      // Close dropdown when clicking outside
      document.addEventListener("click", closeAllSelect);
    });
    // Show toast notification
    function showToast(message, type) {
      const toastContainer = document.getElementById('toast-container');
      const toast = document.createElement('div');
      toast.className = `toast toast-${type}`;
      toast.innerHTML = `
        <span>${message}</span>
        <button class="toast-close">&times;</button>
      `;
      toastContainer.appendChild(toast);
      
      // Add click handler for close button
      toast.querySelector('.toast-close').addEventListener('click', function() {
        toast.remove();
      });
      
      setTimeout(() => {
        toast.remove();
      }, 3000);
    }
    
    <?php if (isset($_SESSION['toast'])): ?>
      document.addEventListener('DOMContentLoaded', function() {
        showToast('<?php echo $_SESSION['toast']['message']; ?>', '<?php echo $_SESSION['toast']['type']; ?>');
      });
      <?php unset($_SESSION['toast']); ?>
    <?php endif; ?>
  </script>
</body>
</html>