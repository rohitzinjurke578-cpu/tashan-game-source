<?php
session_start();
include("conn.php");

// Initialize toast message variables
$toastClass = '';
$toastIcon = '';
$toastMessage = '';

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $adid = htmlspecialchars(mysqli_real_escape_string($conn, $_POST['username']));
    $psad = htmlspecialchars(mysqli_real_escape_string($conn, $_POST['password']));
    
    // Query to check admin credentials
    $samasye = "SELECT * FROM `nirvahaka_shonu` WHERE `nirvahaka_hesaru`='".$adid."' AND `guptapada`='".md5($psad)."' AND `sthiti`='1'";
    $phalitansa = mysqli_query($conn, $samasye);
    $sankhye = mysqli_num_rows($phalitansa);
    
    if ($sankhye >= 1) {
        $salu = mysqli_fetch_assoc($phalitansa);
        $_SESSION['unohs'] = $salu['unohs'];
        $_SESSION['nirvahaka_hesaru'] = $salu['nirvahaka_hesaru'];
        
        // Set success toast
        $toastClass = 'success';
        $toastIcon = 'fas fa-shield-check';
        $toastMessage = 'Authentication successful! Redirecting...';
    } else {
        // Set error toast
        $toastClass = 'error';
        $toastIcon = 'fas fa-shield-exclamation';
        $toastMessage = 'Invalid credentials. Please try again.';
    }
}

// Redirect if already logged in
if (isset($_SESSION['nirvahaka_hesaru'])) {
    header("location:dashboard.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #e63946;
            --primary-dark: #d90429;
            --primary-light: #ffb4a2;
            --text: #2b2d42;
            --text-light: #8d99ae;
            --error: #e63946;
            --success: #2a9d8f;
            --bg: linear-gradient(135deg, #ffafbd 0%, #ffc3a0 100%);
            --white: #ffffff;
            --white-transparent: rgba(255, 255, 255, 0.95);
            --border: #e2e8f0;
            --shadow: 0 10px 25px rgba(230, 57, 70, 0.15);
            --card-shadow: 0 8px 30px rgba(230, 57, 70, 0.2);
            --input-height: 44px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: var(--bg);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 1rem;
            background-attachment: fixed;
        }

        .login-container {
            background: var(--white-transparent);
            padding: 2rem;
            border-radius: 16px;
            box-shadow: var(--card-shadow);
            width: min(100%, 420px);
            border: 1px solid rgba(230, 57, 70, 0.1);
            margin-top: -50px; /* Form moved up */
        }

        .brand-wrapper {
            text-align: center;
            margin-bottom: 2rem;
            position: relative;
        }

        .logo-circle {
            width: 100px;
            height: 100px;
            margin: 0 auto 1.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            border-radius: 50%;
            color: var(--white);
            font-size: 2.2rem;
            box-shadow: 0 8px 20px rgba(230, 57, 70, 0.3);
            position: relative;
        }

        .logo-circle::before {
            content: "";
            position: absolute;
            width: 110%;
            height: 110%;
            border: 2px dashed var(--primary);
            border-radius: 50%;
            animation: spin 15s linear infinite;
        }

        .security-badge {
            position: absolute;
            bottom: -5px;
            right: -5px;
            background: var(--white);
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--success);
            font-size: 0.9rem;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            border: 2px solid var(--success);
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .brand-wrapper h2 {
            color: var(--primary-dark);
            font-size: 1.8rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
        }

        .brand-wrapper p {
            color: var(--text-light);
            font-size: 1rem;
            font-weight: 500;
        }

        .form-group {
            margin-bottom: 1.5rem;
            position: relative;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            color: var(--text);
            font-weight: 600;
            font-size: 0.95rem;
        }

        .input-wrapper {
            position: relative;
        }

        .form-control {
            width: 100%;
            height: var(--input-height);
            padding: 0 1rem 0 3rem;
            border: 1px solid var(--border);
            border-radius: 8px;
            font-size: 0.95rem;
            transition: all 0.2s ease;
            background: var(--white);
            color: var(--text);
        }

        .form-control:focus {
            border-color: var(--primary);
            outline: none;
            box-shadow: 0 0 0 3px rgba(230, 57, 70, 0.1);
        }

        .input-icon {
            position: absolute;
            left: 1rem;
            top: 50%;
            transform: translateY(-50%);
            color: var(--primary);
            font-size: 1.1rem;
        }

        .error-message {
            color: var(--error);
            font-size: 0.85rem;
            margin-top: 0.5rem;
            display: none;
            font-weight: 500;
        }

        .btn-login {
            width: 100%;
            height: var(--input-height);
            border: none;
            border-radius: 8px;
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            color: var(--white);
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.8rem;
            box-shadow: 0 4px 12px rgba(230, 57, 70, 0.3);
        }

        .btn-login:hover {
            background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary) 100%);
        }

        .password-toggle {
            position: absolute;
            right: 1rem;
            top: 50%;
            transform: translateY(-50%);
            color: var(--primary);
            cursor: pointer;
            font-size: 1.1rem;
        }

        .toast {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: var(--white);
            color: var(--text);
            padding: 1rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.8rem;
            z-index: 1000;
            opacity: 0;
            transition: all 0.3s ease;
            font-weight: 600;
            box-shadow: 0 -5px 15px rgba(0, 0, 0, 0.1);
            border-top: 3px solid var(--primary);
            text-align: center;
        }

        .toast.show {
            opacity: 1;
        }

        .toast i {
            font-size: 1.2rem;
        }

        .toast.success {
            border-top-color: var(--success);
        }

        .toast.error {
            border-top-color: var(--error);
        }

        .btn-loading .spinner {
            display: inline-block;
            width: 18px;
            height: 18px;
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top-color: white;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        @media (max-width: 480px) {
            .login-container {
                padding: 1.5rem;
                margin-top: -30px;
            }
            
            .logo-circle {
                width: 85px;
                height: 85px;
                font-size: 2rem;
            }
            
            .brand-wrapper h2 {
                font-size: 1.6rem;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="brand-wrapper">
            <div class="logo-circle">
                <i class="fas fa-lock"></i>
                <div class="security-badge">
                    <i class="fas fa-check"></i>
                </div>
            </div>
            <h2>Admin Login</h2>
            <p>Secure access to your dashboard</p>
        </div>
        
        <form id="loginForm" method="POST">
            <div class="form-group">
                <label for="username">Username</label>
                <div class="input-wrapper">
                    <i class="fas fa-user-tie input-icon"></i>
                    <input type="text" class="form-control" id="username" name="username" required 
                           placeholder="Enter your username">
                </div>
                <div class="error-message" id="username-error">Username is required</div>
            </div>
            
            <div class="form-group">
                <label for="password">Password</label>
                <div class="input-wrapper">
                    <i class="fas fa-lock input-icon"></i>
                    <input type="password" class="form-control" id="password" name="password" required
                           placeholder="Enter your password">
                    <span class="password-toggle" id="togglePassword">
                        <i class="fas fa-eye"></i>
                    </span>
                </div>
                <div class="error-message" id="password-error">Password is required</div>
            </div>
            
            <button type="submit" class="btn-login" id="loginButton">
                <span class="btn-text">Sign In</span>
            </button>
        </form>
    </div>

    <div class="toast" id="toast">
        <i id="toast-icon" class="fas fa-shield-check"></i>
        <span id="toast-message">Login successful!</span>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('loginForm');
            const usernameInput = document.getElementById('username');
            const passwordInput = document.getElementById('password');
            const usernameError = document.getElementById('username-error');
            const passwordError = document.getElementById('password-error');
            const toast = document.getElementById('toast');
            const toastMessage = document.getElementById('toast-message');
            const toastIcon = document.getElementById('toast-icon');
            const togglePassword = document.getElementById('togglePassword');
            const password = document.getElementById('password');
            const loginButton = document.getElementById('loginButton');
            let formSubmitted = false;
            
            // Toggle password visibility
            togglePassword.addEventListener('click', function() {
                const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
                password.setAttribute('type', type);
                this.innerHTML = type === 'password' ? '<i class="fas fa-eye"></i>' : '<i class="fas fa-eye-slash"></i>';
            });
            
            // Form validation and submission
            form.addEventListener('submit', function(e) {
                e.preventDefault();
                
                if (formSubmitted) return;
                
                // Reset error messages
                usernameError.style.display = 'none';
                passwordError.style.display = 'none';
                
                let isValid = true;
                
                // Validate username
                if (!usernameInput.value.trim()) {
                    usernameError.style.display = 'block';
                    usernameInput.focus();
                    isValid = false;
                }
                
                // Validate password
                if (!passwordInput.value.trim()) {
                    passwordError.style.display = 'block';
                    if (isValid) passwordInput.focus();
                    isValid = false;
                }
                
                if (!isValid) return;
                
                // Show loading state
                loginButton.innerHTML = '<div class="spinner"></div>';
                formSubmitted = true;
                
                // Submit the form
                form.submit();
            });
            
            // Show toast if PHP set one
            <?php if ($toastMessage): ?>
                setTimeout(() => {
                    showToast('<?php echo $toastMessage; ?>', '<?php echo $toastClass; ?>');
                    
                    // If success, redirect after delay
                    <?php if ($toastClass === 'success'): ?>
                        setTimeout(() => {
                            window.location.href = 'dashboard.php';
                        }, 2000);
                    <?php endif; ?>
                }, 100);
            <?php endif; ?>
            
            function showToast(message, type) {
                toastMessage.textContent = message;
                toast.className = 'toast show ' + type;
                
                // Update icon based on type
                toastIcon.className = type === 'success' ? 
                    'fas fa-shield-check' : 'fas fa-shield-exclamation';
            }
        });
    </script>
</body>
</html>