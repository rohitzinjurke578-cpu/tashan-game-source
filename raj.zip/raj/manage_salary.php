<?php
session_start();
if ($_SESSION['unohs'] == null) {
    header("location:index.php?msg=unauthorized");
}
date_default_timezone_set("Asia/Kolkata");
include("conn.php");

// Get daily salary data
$query = "SELECT `macau`, `userid`, `totalsucrech`, `totalfailrech`, `tsruser`, `tfruser`, 
                 `totalsucbet`, `tsbuser`, `totalfailbet`, `tfbuser`, `salary`, `status`, 
                 `remarks`, `createdate` 
          FROM `dailysalary` 
          WHERE 1
          ORDER BY createdate DESC";
$salaryData = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
  <title>Daily Salary Report</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="css/common.css" rel="stylesheet">
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    :root {
      --primary: #4f46e5;
      --primary-dark: #4338ca;
      --danger: #dc2626;
      --success: #16a34a;
      --dark: #1e293b;
      --light: #f8fafc;
    }
    
    body {
      font-family: 'Inter', sans-serif;
      background-color: #f1f5f9;
      overflow-x: hidden;
    }
    
    .wrapper {
      display: flex;
      min-height: 100vh;
    }
    
    .main-content {
      flex: 1;
      min-width: 0;
    }
    
    /* Toast styles */
    #toast-container {
      position: fixed;
      bottom: 20px;
      right: 20px;
      z-index: 9999;
    }
    
    .toast {
      min-width: 280px;
      padding: 12px 16px;
      margin-bottom: 10px;
      border-radius: 8px;
      color: white;
      font-size: 14px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      animation: slideIn 0.3s, fadeOut 0.5s 2.5s forwards;
    }
    
    .toast-success {
      background-color: var(--success);
    }
    
    .toast-error {
      background-color: var(--danger);
    }
    
    .toast-close {
      background: none;
      border: none;
      color: white;
      font-size: 18px;
      cursor: pointer;
      margin-left: 10px;
    }
    
    @keyframes slideIn {
      from { transform: translateX(100%); opacity: 0; }
      to { transform: translateX(0); opacity: 1; }
    }
    
    @keyframes fadeOut {
      from { opacity: 1; }
      to { opacity: 0; }
    }
    
    /* Salary Table Styles */
    .salary-table-container {
      background: white;
      padding: 1.25rem;
      border-radius: 0.5rem;
      margin: 0.5rem;
      box-shadow: 0 1px 3px rgba(0,0,0,0.1);
      max-width: 100%;
      box-sizing: border-box;
      overflow-x: auto;
    }
    
    .salary-table-header {
      font-size: 1.125rem;
      font-weight: 600;
      color: #1e293b;
      margin-bottom: 1rem;
      display: flex;
      align-items: center;
    }
    
    .salary-table {
      width: 100%;
      border-collapse: collapse;
    }
    
    .salary-table th {
      background-color: #f8fafc;
      padding: 0.75rem;
      text-align: left;
      font-weight: 600;
      color: #64748b;
      border-bottom: 1px solid #e2e8f0;
    }
    
    .salary-table td {
      padding: 0.75rem;
      border-bottom: 1px solid #e2e8f0;
      color: #334155;
    }
    
    .salary-table tr:last-child td {
      border-bottom: none;
    }
    
    .salary-table tr:hover {
      background-color: #f8fafc;
    }
    
    .text-aqua {
      color: #00c0ef;
    }
    
    .status-pending {
      color: #d97706;
      font-weight: 500;
    }
    
    .status-approved {
      color: #16a34a;
      font-weight: 500;
    }
    
    .status-rejected {
      color: #dc2626;
      font-weight: 500;
    }
    
    @media (max-width: 640px) {
      .salary-table th, .salary-table td {
        padding: 0.5rem;
        font-size: 0.875rem;
      }
    }
    
    /* Modal styles */
    .modal {
      display: none;
      position: fixed;
      z-index: 1000;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      overflow: auto;
      background-color: rgba(0,0,0,0.4);
    }
    
    .modal-content {
      background-color: #fefefe;
      margin: 15% auto;
      padding: 20px;
      border: 1px solid #888;
      width: 80%;
      max-width: 500px;
      border-radius: 0.5rem;
    }
    
    .modal-header {
      padding: 10px 0;
      border-bottom: 1px solid #e2e8f0;
      margin-bottom: 15px;
    }
    
    .modal-title {
      margin: 0;
      font-size: 1.25rem;
    }
    
    .close {
      color: #aaa;
      float: right;
      font-size: 28px;
      font-weight: bold;
      cursor: pointer;
    }
    
    .close:hover {
      color: black;
    }
    
    .form-group {
      margin-bottom: 15px;
    }
    
    .form-control {
      width: 100%;
      padding: 0.5rem;
      border: 1px solid #e2e8f0;
      border-radius: 0.25rem;
    }
    
    .btn {
      padding: 0.5rem 1rem;
      border-radius: 0.25rem;
      cursor: pointer;
    }
    
    .btn-primary {
      background-color: var(--primary);
      color: white;
      border: none;
    }
    
    .btn-primary:hover {
      background-color: var(--primary-dark);
    }
    
    .btn-danger {
      background-color: var(--danger);
      color: white;
      border: none;
    }
    
    .btn-danger:hover {
      background-color: #b91c1c;
    }
    
    #copied {
      visibility: hidden;
      z-index: 1;
      position: fixed;
      bottom: 50%;
      background-color: #333;
      color: #fff;
      border-radius: 6px;
      padding: 16px;
      max-width: 250px;
      font-size: 17px;
    }
    
    #copied.show {
      visibility: visible;
      -webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
      animation: fadein 0.5s, fadeout 0.5s 2.5s;
    }
    
    @keyframes fadein {
      from {opacity: 0;}
      to {opacity: 1;}
    }
    
    @keyframes fadeout {
      from {opacity: 1;}
      to {opacity: 0;}
    }
  </style>
</head>

<body>
  <div class="wrapper">
    <?php include('compass.php'); ?>
  
    <div class="main-content">
      <nav class="navbar">
        <a href="#" class="navbar-brand" id="sidebarToggle">
          <i class="fas fa-bars"></i>
          <span>Menu</span>
        </a>
        
        <ul class="navbar-nav">
          <li class="nav-item dropdown">
            <a href="#" class="nav-link" id="settingsDropdown">
              <i class="fas fa-user-cog"></i>
            </a>
            <div class="dropdown-menu" id="settingsMenu">
              <a href="logout.php" class="dropdown-item">
                <i class="fas fa-sign-out-alt"></i> Logout
              </a>
            </div>
          </li>
        </ul>
      </nav>
      
      <!-- Daily Salary Table Section -->
      <div class="salary-table-container">
        <h3 class="salary-table-header">
          <i class="fas fa-money-bill-wave text-blue-500 mr-2"></i>Daily Salary Report
        </h3>
        
        <div class="table-responsive">
          <table id="salaryTable" class="salary-table">
            <thead>
              <tr>
                <th>Macau ID</th>
                <th>User ID</th>
                <th>Total Success Recharge</th>
                <th>Total Failed Recharge</th>
                <th>TSR User</th>
                <th>TFR User</th>
                <th>Total Success Bet</th>
                <th>TSB User</th>
                <th>Total Failed Bet</th>
                <th>TFB User</th>
                <th>Salary</th>
                <th>Status</th>
                <th>Remarks</th>
                <th>Created Date</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php while($row = mysqli_fetch_assoc($salaryData)): ?>
                <tr>
                  <td><?= htmlspecialchars($row['macau']) ?></td>
                  <td><?= htmlspecialchars($row['userid']) ?></td>
                  <td><?= htmlspecialchars($row['totalsucrech']) ?></td>
                  <td><?= htmlspecialchars($row['totalfailrech']) ?></td>
                  <td><?= htmlspecialchars($row['tsruser']) ?></td>
                  <td><?= htmlspecialchars($row['tfruser']) ?></td>
                  <td><?= htmlspecialchars($row['totalsucbet']) ?></td>
                  <td><?= htmlspecialchars($row['tsbuser']) ?></td>
                  <td><?= htmlspecialchars($row['totalfailbet']) ?></td>
                  <td><?= htmlspecialchars($row['tfbuser']) ?></td>
                  <td><?= htmlspecialchars($row['salary']) ?></td>
                  <td>
                    <?php 
                      $statusClass = '';
                      if($row['status'] == 0) $statusClass = 'status-pending';
                      elseif($row['status'] == 1) $statusClass = 'status-approved';
                      else $statusClass = 'status-rejected';
                    ?>
                    <span class="<?= $statusClass ?>">
                      <?php 
                        if($row['status'] == 0) echo 'Pending';
                        elseif($row['status'] == 1) echo 'Approved';
                        else echo 'Rejected';
                      ?>
                    </span>
                  </td>
                  <td><?= htmlspecialchars($row['remarks']) ?></td>
                  <td><?= htmlspecialchars($row['createdate']) ?></td>
                  <td>
                    <?php if($row['status'] == 0): ?>
                      <a href="javascript:void(0);" onClick="approveSalary(<?= $row['macau'] ?>)" class="text-aqua" title="Approve">
                        <i class="fas fa-check-circle"></i>
                      </a>
                      <a href="javascript:void(0);" onClick="rejectSalary(<?= $row['macau'] ?>)" class="text-danger ml-2" title="Reject">
                        <i class="fas fa-times-circle"></i>
                      </a>
                    <?php endif; ?>
                    <a href="javascript:void(0);" onClick="editSalary(<?= $row['macau'] ?>, <?= $row['userid'] ?>, <?= $row['salary'] ?>)" class="text-aqua ml-2" title="Edit">
                      <i class="fas fa-edit"></i>
                    </a>
                  </td>
                </tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

  <!-- Edit Salary Modal -->
  <div id="editSalaryModal" class="modal">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Edit Salary<br>
          <small id="editUserInfo"></small>
        </h4>
        <span class="close">&times;</span>
      </div>
      <form name="editSalaryForm" id="editSalaryForm" enctype="multipart/form-data" action="#" method="post">
        <div class="modal-body">              
          <div class="form-group">
            <label for="salaryAmount">Salary Amount</label>  
            <input class="form-control" id="salaryAmount" name="salaryAmount" type="text" value="" onkeypress="return isNumber(event)" required>
            <input class="form-control" id="salaryMacauId" name="salaryMacauId" type="hidden">
            <input class="form-control" id="salaryUserId" name="salaryUserId" type="hidden">
          </div>
          <div class="form-group">
            <label for="salaryRemarks">Remarks</label>
            <textarea class="form-control" id="salaryRemarks" name="salaryRemarks" rows="3"></textarea>
          </div>
        </div>
        <div class="modal-footer">              
          <button type="submit" class="btn btn-primary">Save Changes</button>
        </div>
      </form>
    </div>
  </div>

  <div id="toast-container"></div>
  <div id="copied"></div>

  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
  <script>
    // Toggle sidebar on mobile
    document.getElementById('sidebarToggle').addEventListener('click', function(e) {
      e.preventDefault();
      document.querySelector('.sidebar').classList.toggle('show');
    });
    
    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', function(e) {
      const sidebar = document.querySelector('.sidebar');
      const sidebarToggle = document.getElementById('sidebarToggle');
      
      if (window.innerWidth <= 768) {
        if (!sidebar.contains(e.target) && !sidebarToggle.contains(e.target)) {
          sidebar.classList.remove('show');
        }
      }
    });
    
    // Toggle dropdown menu
    document.getElementById('settingsDropdown').addEventListener('click', function(e) {
      e.preventDefault();
      document.getElementById('settingsMenu').classList.toggle('show');
    });
    
    // Close dropdown when clicking outside
    document.addEventListener('click', function(e) {
      if (!e.target.closest('.nav-item.dropdown')) {
        document.getElementById('settingsMenu').classList.remove('show');
      }
    });
    
    // Toggle submenus in sidebar
    document.querySelectorAll('.sidebar-menu .has-submenu > a').forEach(item => {
      item.addEventListener('click', function(e) {
        e.preventDefault();
        const parent = this.parentElement;
        const submenu = this.nextElementSibling;
        
        document.querySelectorAll('.sidebar-menu .submenu').forEach(menu => {
          if (menu !== submenu) {
            menu.classList.remove('active');
            menu.previousElementSibling.classList.remove('active');
          }
        });
        
        parent.classList.toggle('active');
        submenu.classList.toggle('active');
      });
    });
    
    // Show toast notification
    function showToast(message, type) {
      const toastContainer = document.getElementById('toast-container');
      const toast = document.createElement('div');
      toast.className = `toast toast-${type}`;
      toast.innerHTML = `
        <span>${message}</span>
        <button class="toast-close">&times;</button>
      `;
      toastContainer.appendChild(toast);
      
      // Add click handler for close button
      toast.querySelector('.toast-close').addEventListener('click', function() {
        toast.remove();
      });
      
      setTimeout(() => {
        toast.remove();
      }, 3000);
    }
    
    // Modal functionality
    function editSalary(macauId, userId, currentSalary) {
      const modal = document.getElementById('editSalaryModal');
      document.getElementById('editUserInfo').innerHTML = `Macau ID: ${macauId} | User ID: ${userId}`;
      document.getElementById('salaryAmount').value = currentSalary;
      document.getElementById('salaryMacauId').value = macauId;
      document.getElementById('salaryUserId').value = userId;
      modal.style.display = 'block';
    }
    
    // Close modal when clicking on X
    document.querySelectorAll('.close').forEach(closeBtn => {
      closeBtn.addEventListener('click', function() {
        this.closest('.modal').style.display = 'none';
      });
    });
    
    // Close modal when clicking outside
    window.addEventListener('click', function(event) {
      if (event.target.className === 'modal') {
        event.target.style.display = 'none';
      }
    });
    
    // Form submission for salary edit
    $(document).ready(function() {
      $("#editSalaryForm").on('submit', function(e) {
        e.preventDefault();
        
        $.ajax({
          type: "POST",
          url: "update_salary.php",
          data: $(this).serialize(),
          success: function(response) {
            if(response.success) {
              showToast(response.message, 'success');
              document.getElementById('editSalaryModal').style.display = 'none';
              setTimeout(() => {
                window.location.reload();
              }, 1500);
            } else {
              showToast(response.message, 'error');
            }
          },
          error: function() {
            showToast('0 An error occurred while processing your request', 'error');
          }
        });
      });
    });
    
    function approveSalary(macauId) {
      if(confirm('Are you sure you want to approve this salary?')) {
        $.ajax({
          type: "POST",
          url: "update_salary_status.php",
          data: { macauId: macauId, status: 1 },
          dataType: 'json',
          success: function(response) {
            if(response.success) {
              showToast(response.message, 'success');
              setTimeout(() => {
                window.location.reload();
              }, 1500);
            } else {
              showToast(response.message, 'error');
            }
          },
          error: function() {
            showToast('1 An error occurred while processing your request', 'error');
          }
        });
      }
    }
    
    function rejectSalary(macauId) {
      const remarks = prompt('Please enter reason for rejection:');
      if(remarks !== null) {
        $.ajax({
          type: "POST",
          url: "update_salary_status.php",
          data: { macauId: macauId, status: 2, remarks: remarks },
          dataType: 'json',
          success: function(response) {
            if(response.success) {
              showToast(response.message, 'success');
              setTimeout(() => {
                window.location.reload();
              }, 1500);
            } else {
              showToast(response.message, 'error');
            }
          },
          error: function() {
            showToast('2 An error occurred while processing your request', 'error');
          }
        });
      }
    }
    
    function isNumber(evt) {
      evt = (evt) ? evt : window.event;
      var charCode = (evt.which) ? evt.which : evt.keyCode;
      if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
      }
      return true;
    }
    
    // Initialize DataTable for salary table
    $(document).ready(function() {
      $('#salaryTable').DataTable({
        "paging": true,
        "lengthChange": true,
        "searching": true,
        "ordering": true,
        "info": true,
        "autoWidth": true,
        "pageLength": 50,
        "dom": 'lrtip',
        "order": [[13, 'desc']] // Sort by createdate descending by default
      });
    });
    
    <?php if (isset($_SESSION['toast'])): ?>
      document.addEventListener('DOMContentLoaded', function() {
        showToast('<?php echo $_SESSION['toast']['message']; ?>', '<?php echo $_SESSION['toast']['type']; ?>');
      });
      <?php unset($_SESSION['toast']); ?>
    <?php endif; ?>
  </script>
</body>
</html>