<?php
session_start();
if ($_SESSION['unohs'] == null) {
    header("location:index.php?msg=unauthorized");
    exit();
}
include("conn.php");

// Generate unique token for form
if (!isset($_SESSION['form_token'])) {
    $_SESSION['form_token'] = bin2hex(random_bytes(32));
}

// Handle QR image upload
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["image"])) {
    $target_dir = "../images_usdt/";
    $target_file = $target_dir . basename($_FILES["image"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    if(isset($_POST["submit"])) {
        $check = getimagesize($_FILES["image"]["tmp_name"]);
        if($check !== false) {
            $uploadOk = 1;
        } else {
            $_SESSION['toast'] = [
                'type' => 'error',
                'message' => 'File is not an image.'
            ];
            $uploadOk = 0;
        }
    }

    if (file_exists($target_file)) {
        $_SESSION['toast'] = [
            'type' => 'error',
            'message' => 'Sorry, file already exists.'
        ];
        $uploadOk = 0;
    }

    if ($_FILES["image"]["size"] > 500000) {
        $_SESSION['toast'] = [
            'type' => 'error',
            'message' => 'Sorry, your file is too large.'
        ];
        $uploadOk = 0;
    }

    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg") {
        $_SESSION['toast'] = [
            'type' => 'error',
            'message' => 'Sorry, only JPG, JPEG, PNG files are allowed.'
        ];
        $uploadOk = 0;
    }

    if ($uploadOk == 1) {
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
            $filename = basename($_FILES["image"]["name"]);
            $sql = "INSERT INTO images_usdt (filename) VALUES ('$filename')";
            if ($conn->query($sql) === TRUE) {
                $_SESSION['toast'] = [
                    'type' => 'success',
                    'message' => 'Record added to database successfully'
                ];
            } else {
                $_SESSION['toast'] = [
                    'type' => 'error',
                    'message' => 'Error adding record'
                ];
            }
        } else {
            $_SESSION['toast'] = [
                'type' => 'error',
                'message' => 'Sorry, there was an error uploading your file.'
            ];
        }
    }
    header("Location: ".$_SERVER['PHP_SELF']);
    exit();
}

// Handle QR image activation
if(isset($_POST['upiid'])){
    $a_id = $_POST['upiid'];
    $sql_s = "SELECT * FROM images_usdt WHERE filename = '".$a_id."'";
    $run = mysqli_query($conn, $sql_s);

    //Set status to 0
    $sql_d = "SELECT * FROM images_usdt WHERE status = '1'";
    $run_d = mysqli_query($conn, $sql_d);
    $rund_f = mysqli_fetch_array($run_d);
    $ch_s0 = "UPDATE images_usdt SET status='0' WHERE id='".$rund_f['id']."'";
    $exe_ch_s0 = mysqli_query($conn, $ch_s0);

    //Set status to 1
    $run_f = mysqli_fetch_array($run);
    $ch_s1 = "UPDATE images_usdt SET status='1' WHERE id='".$run_f['id']."'";
    $exe_ch_s1 = mysqli_query($conn, $ch_s1);

    $_SESSION['toast'] = [
        'type' => 'success',
        'message' => 'QR code status updated'
    ];
    header("Location: ".$_SERVER['PHP_SELF']);
    exit();
}

// Handle QR image deletion
if(isset($_POST['delete_usdt']) && isset($_POST['delete_token']) && $_POST['delete_token'] === $_SESSION['form_token']) {
    $usdtToDelete = mysqli_real_escape_string($conn, $_POST['delete_usdt']);

    // First get the filename to delete from server
    $get_file = "SELECT filename FROM images_usdt WHERE filename = '$usdtToDelete'";
    $file_result = mysqli_query($conn, $get_file);

    if($file_row = mysqli_fetch_assoc($file_result)) {
        $file_path = "../images_usdt/" . $file_row['filename'];

        // Delete from database
        $deleteQuery = "DELETE FROM images_usdt WHERE filename = '$usdtToDelete'";
        if(mysqli_query($conn, $deleteQuery)) {
            // Delete the file from server
            if(file_exists($file_path)) {
                unlink($file_path);
            }
            $_SESSION['toast'] = [
                'type' => 'success',
                'message' => 'USDT QR image deleted successfully'
            ];
        } else {
            $_SESSION['toast'] = [
                'type' => 'error',
                'message' => 'Failed to delete USDT QR image'
            ];
        }
    }

    // Regenerate token after deletion
    $_SESSION['form_token'] = bin2hex(random_bytes(32));
    header("Location: ".$_SERVER['PHP_SELF']);
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>USDT QR Management</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="css/common.css" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        /* Main Content Styles */
        .main-content {
            flex: 1;
            margin-left: 0;
            transition: var(--transition);
            background-color: var(--white);
            min-height: 100vh;
        }
        
        .content-header {
            padding: 0.75rem 1.25rem;
            background: linear-gradient(to right, #ffffff, #f1f3f5);
            box-shadow: 0 1px 2px rgba(0, 0, 0, 0.06);
            border-radius: 0.375rem;
            border: 1px solid #e0e0e0;
            margin: 1rem;
            transition: all 0.3s ease;
        }
        
        .content-header h1 {
            font-size: 1rem;
            margin: 0;
            font-weight: 600;
            color: #343a40;
        }
        
        .breadcrumb {
            font-size: 0.75rem;
            color: #6c757d;
            margin-bottom: 0;
        }
        
        .breadcrumb a {
            color: #4f46e5;
            font-weight: 500;
            text-decoration: none;
            transition: color 0.2s ease-in-out;
        }
        
        .breadcrumb a:hover {
            color: #3730a3;
        }
        
        /* Form Styles */
        .form-container {
            background: var(--white);
            padding: 1.5rem;
            border-radius: 0.5rem;
            box-shadow: var(--card-shadow);
            margin-bottom: 1.5rem;
            border: 1px solid rgba(52, 152, 219, 0.1);
        }
        
        .form-container h3 {
            color: var(--dark);
            margin-bottom: 1.5rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 2px;
            font-size: 1.1rem;
        }
        
        .form-group {
            margin-bottom: 1rem;
        }
        
        .list-container{
            margin: 10px 15px;
        }
        
        .list-container h3{
            margin: 5px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
            color: var(--dark);
            font-size: 0.9rem;
        }
        
        /* Custom file input */
        .file-input-container {
            position: relative;
            margin-bottom: 1rem;
        }
        
        .file-input {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            opacity: 0;
            cursor: pointer;
        }
        
        .file-input-label {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0.75rem 1.5rem;
            border: 2px dashed #cbd5e0;
            border-radius: 0.375rem;
            background-color: #f8fafc;
            transition: all 0.3s ease;
            height: 120px;
            flex-direction: column;
            text-align: center;
        }
        
        .file-input-label:hover {
            border-color: #a0aec0;
            background-color: #edf2f7;
        }
        
        .file-input-label i {
            font-size: 2rem;
            color: #4f46e5;
            margin-bottom: 0.5rem;
        }
        
        .file-input-label span {
            color: #4a5568;
            font-size: 0.9rem;
        }
        
        .file-name {
            margin-top: 0.5rem;
            font-size: 0.8rem;
            color: #718096;
        }
        
        /* Button Styles */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 0.75rem 1.5rem;
            border-radius: 0.375rem;
            font-weight: 500;
            font-size: 0.9rem;
            line-height: 1.5;
            cursor: pointer;
            transition: all 0.3s ease;
            border: none;
        }
        
        .btn-primary {
            background-color: var(--primary);
            color: white;
            display: none;
        }
        
        .btn-primary:hover {
            background-color: var(--primary-dark);
            transform: translateY(-1px);
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        
        .btn-sm {
            padding: 0.5rem;
            width: 36px;
            height: 36px;
        }
        
        .btn-danger {
            background-color: var(--danger);
            color: white;
        }
        
        .btn-danger:hover {
            background-color: #c0392b;
            transform: translateY(-1px);
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        
        .btn-secondary {
            background-color: var(--gray);
            color: var(--white);
        }
        
        .btn-secondary:hover {
            background-color: #95a5a6;
            transform: translateY(-1px);
        }
        
        /* QR List Styles */
        .qr-list {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 1rem;
            margin-top: 1.5rem;
        }
        
        .qr-item {
            background-color: white;
            border-radius: 0.5rem;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            transition: all 0.3s ease;
            border: 1px solid rgba(52, 152, 219, 0.1);
        }
        
        .qr-item:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        
        .qr-image-container {
            height: 120px;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #f8fafc;
            padding: 1rem;
        }
        
        .qr-image {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
            width: 100px;
            height: 100px;
        }
        
        .qr-details {
            padding: 1rem;
            border-top: 1px solid #e2e8f0;
        }
        
        .qr-name {
            font-weight: 600;
            color: var(--dark);
            margin-bottom: 0.5rem;
            font-size: 0.9rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .qr-status {
            display: inline-block;
            padding: 0.25rem 0.5rem;
            border-radius: 1rem;
            font-size: 0.75rem;
            font-weight: 600;
            background-color: rgba(46, 204, 113, 0.1);
            color: var(--secondary);
        }
        
        .qr-actions {
            display: flex;
            gap: 0.5rem;
            margin-top: 0.5rem;
            align-items: center;
            justify-content: space-between;
        }
        
        .status-container {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        /* Radio button styles */
        .radio-active {
            accent-color: var(--secondary);
            width: 18px;
            height: 18px;
            cursor: pointer;
        }
        
        /* Toast Styles */
        #toast-container {
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 9999;
        }
        
        .toast {
            min-width: 300px;
            padding: 15px 20px;
            margin-bottom: 10px;
            border-radius: 8px;
            color: white;
            font-size: 14px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            animation: slideIn 0.3s, fadeOut 0.5s 2.5s forwards;
            transform: translateX(0);
        }
        
        .toast-success {
            background-color: var(--secondary);
        }
        
        .toast-error {
            background-color: var(--danger);
        }
        
        .toast-close {
            background: none;
            border: none;
            color: white;
            cursor: pointer;
            margin-left: 15px;
            font-size: 1rem;
        }
        
        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        
        @keyframes fadeOut {
            from { opacity: 1; }
            to { opacity: 0; }
        }
        
        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1050;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            overflow-y: auto;
        }
        
        .modal-content {
            background-color: white;
            margin: 250px auto;
            padding: 25px;
            border-radius: 8px;
            width: 90%;
            max-width: 400px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
            animation: modalFadeIn 0.3s;
        }
        
        @keyframes modalFadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .modal-header {
            margin-bottom: 20px;
        }
        
        .modal-header h3 {
            margin: 0;
            color: var(--dark);
            font-size: 1.20rem;
        }
        
        .modal-body {
            margin-bottom: 20px;
            color: var(--dark);
            font-size: 0.8rem;
        }
        
        .modal-actions {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }
        
        /* Responsive Styles */
        @media (min-width: 768px) {
            .sidebar {
                transform: translateX(0);
            }
            .main-content {
                margin-left: 220px;
            }
        }
        
        @media (max-width: 767px) {
            .form-container {
                margin: 1rem;
            }
            .qr-list {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <?php include('compass.php'); ?>
        
        <!-- Main Content -->
        <div class="main-content">
            <!-- Navbar -->
            <nav class="navbar">
                <a href="#" class="navbar-brand" id="sidebarToggle">
                    <i class="fas fa-bars"></i>
                    <span>Menu</span>
                </a>
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a href="#" class="nav-link" id="settingsDropdown">
                            <i class="fas fa-user-cog"></i>
                        </a>
                        <div class="dropdown-menu" id="settingsMenu">
                            <a href="logout.php" class="dropdown-item">
                                <i class="fas fa-sign-out-alt"></i> Logout
                            </a>
                        </div>
                    </li>
                </ul>
            </nav>
            <br>
            
            <!-- Content Area -->
            <div class="content-area">
                <!-- Content Header -->
                <div class="content-header">
                    <div class="breadcrumb">
                        <a href="dashboard.php">Home</a> / USDT QR Management
                    </div>
                    <h1 class="text-xl font-bold text-gray-800">USDT QR Code Management</h1>
                    <p class="text-gray-500 text-sm">
                        <?php echo date("l, F d, Y"); ?>
                    </p>
                </div>
                
                <!-- Main Content Area -->
                <div class="md:p-4">
                    <!-- Upload Form -->
                    <div class="form-container animate-fadeInUp">
                        <h3><i class="fas fa-qrcode text-blue-500"></i> Upload New QR Code</h3>
                        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data" autocomplete="off">
                            <input type="hidden" name="form_token" value="<?php echo $_SESSION['form_token']; ?>">
                            <div class="file-input-container">
                                <input type="file" name="image" id="image" class="file-input" accept="image/jpeg, image/png" required>
                                <label for="image" class="file-input-label">
                                    <i class="fas fa-cloud-upload-alt"></i>
                                    <span>Click to browse or drag & drop QR image</span>
                                    <small class="file-name" id="file-name">No file selected</small>
                                </label>
                            </div>
                            <p class="text-xs text-gray-500 mt-1">Only JPG, PNG images up to 500KB are allowed</p>
                            <button type="submit" name="submit" class="btn btn-primary" id="submitBtn">
                                <i class="fas fa-upload mr-2"></i> Upload QR Code
                            </button>
                        </form>
                    </div>
                    
                    <!-- QR Code List -->
                    <div class="list-container animate-fadeInUp">
                        <h3><i class="fas fa-list text-blue-500"></i> Manage QR Codes</h3>
                        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" id="qrForm" method="post" autocomplete="off">
                            <div class="qr-list">
                                <?php 
                                $sel_upi = "SELECT * FROM images_usdt WHERE status='0' OR status='1'";
                                $upi_r = mysqli_query($conn, $sel_upi);
                                if(mysqli_num_rows($upi_r) > 0):
                                    while ($row = mysqli_fetch_array($upi_r)): 
                                ?>
                                    <div class="qr-item">
                                        <div class="qr-image-container">
                                            <img src="../images_usdt/<?php echo $row['filename']; ?>" alt="USDT QR Code" class="qr-image">
                                        </div>
                                        <div class="qr-details">
                                            <div class="qr-name"><?php echo $row['filename']; ?></div>
                                            <div class="qr-actions">
                                                <div class="status-container">
                                                    <?php if($row['status'] == 1): ?>
                                                        <span class="qr-status">Active</span>
                                                    <?php endif; ?>
                                                    <input name="upiid" type="radio" class="radio-active" value="<?php echo $row['filename']; ?>" <?php if($row['status']==1){echo "checked";} ?> />
                                                </div>
                                                <button type="button" class="btn btn-danger btn-sm" onclick="confirmDelete('<?php echo $row['filename']; ?>')" title="Delete">
                                                    <i class="fas fa-trash-alt"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                <?php 
                                    endwhile;
                                else: 
                                ?>
                                    <div class="text-center py-4 text-gray-500">
                                        No QR codes found. Upload your first QR code above.
                                    </div>
                                <?php endif; ?>
                            </div>
                        </form>
                    </div>
                </div>
                
                <!-- Footer -->
                <footer class="footer w-full bg-gradient-to-r from-slate-50 to-slate-100 border-t border-slate-200 shadow-sm py-4 px-6 fade-in">
                    <div class="max-w-screen-xl mx-auto text-center">
                        <span class="text-sm text-slate-500">
                            Powered by <strong class="text-blue-900 font-semibold">RAJVEER CODER Admin</strong>
                        </span>
                    </div>
                </footer>
            </div>
        </div>
    </div>
    
    <!-- Toast Container -->
    <div id="toast-container"></div>
    
    <!-- Delete Confirmation Modal -->
    <div id="deleteModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-exclamation-triangle text-red-500 mr-2"></i> Confirm Deletion</h3>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete this QR code? This action cannot be undone.</p>
            </div>
            <form id="deleteForm" method="post">
                <input type="hidden" name="delete_usdt" id="deleteQrId">
                <input type="hidden" name="delete_token" value="<?php echo $_SESSION['form_token']; ?>">
                <div class="modal-actions">
                    <button type="button" onclick="closeModal()" class="btn btn-secondary">Cancel</button>
                    <button type="submit" class="btn btn-danger">Delete</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- JavaScript -->
    <script>
        // Wait for DOM to be fully loaded
        document.addEventListener('DOMContentLoaded', function() {
            // Toggle sidebar on mobile
            const sidebarToggle = document.getElementById('sidebarToggle');
            if (sidebarToggle) {
                sidebarToggle.addEventListener('click', function(e) {
                    e.preventDefault();
                    document.querySelector('.sidebar').classList.toggle('show');
                });
            }
            
            // Close sidebar when clicking outside on mobile
            document.addEventListener('click', function(e) {
                const sidebar = document.querySelector('.sidebar');
                const sidebarToggle = document.getElementById('sidebarToggle');
                if (window.innerWidth <= 768) {
                    if (sidebar && !sidebar.contains(e.target) && sidebarToggle && !sidebarToggle.contains(e.target)) {
                        sidebar.classList.remove('show');
                    }
                }
            });
            
            // Toggle dropdown menu
            const settingsDropdown = document.getElementById('settingsDropdown');
            if (settingsDropdown) {
                settingsDropdown.addEventListener('click', function(e) {
                    e.preventDefault();
                    const settingsMenu = document.getElementById('settingsMenu');
                    if (settingsMenu) {
                        settingsMenu.classList.toggle('show');
                    }
                });
            }
            
            // Close dropdown when clicking outside
            document.addEventListener('click', function(e) {
                if (!e.target.closest('.nav-item.dropdown')) {
                    const settingsMenu = document.getElementById('settingsMenu');
                    if (settingsMenu) {
                        settingsMenu.classList.remove('show');
                    }
                }
            });
            
            // Toggle submenus in sidebar
            document.querySelectorAll('.sidebar-menu .has-submenu > a').forEach(item => {
                item.addEventListener('click', function(e) {
                    e.preventDefault();
                    const parent = this.parentElement;
                    const submenu = this.nextElementSibling;
                    
                    // Close all other submenus
                    document.querySelectorAll('.sidebar-menu .submenu').forEach(menu => {
                        if (menu !== submenu) {
                            menu.classList.remove('active');
                            menu.previousElementSibling.classList.remove('active');
                        }
                    });
                    
                    // Toggle current submenu
                    parent.classList.toggle('active');
                    submenu.classList.toggle('active');
                });
            });
            
            // File input display
            const fileInput = document.getElementById('image');
            const fileNameDisplay = document.getElementById('file-name');
            if (fileInput && fileNameDisplay) {
                fileInput.addEventListener('change', function() {
                    if (this.files.length > 0) {
                        fileNameDisplay.textContent = this.files[0].name;
                        document.getElementById('submitBtn').style.display = 'inline-flex';
                    } else {
                        fileNameDisplay.textContent = 'No file selected';
                        document.getElementById('submitBtn').style.display = 'none';
                    }
                });
            }
            
            // Form submission handling
            const qrForm = document.getElementById('qrForm');
            if (qrForm) {
                qrForm.addEventListener('change', function(e) {
                    if (e.target && e.target.name === 'upiid') {
                        this.submit();
                    }
                });
            }
            
            // Show any server-side toast messages
            <?php if (isset($_SESSION['toast'])): ?>
                showToast('<?php echo addslashes($_SESSION['toast']['message']); ?>', '<?php echo $_SESSION['toast']['type']; ?>');
                <?php unset($_SESSION['toast']); ?>
            <?php endif; ?>
        });
        
        // Delete confirmation
        function confirmDelete(qrFilename) {
            const modal = document.getElementById('deleteModal');
            document.getElementById('deleteQrId').value = qrFilename;
            modal.style.display = 'block';
        }
        
        function closeModal() {
            document.getElementById('deleteModal').style.display = 'none';
        }
        
        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('deleteModal');
            if (event.target == modal) {
                modal.style.display = 'none';
            }
        }
        
        // Show toast notification
        function showToast(message, type) {
            const toastContainer = document.getElementById('toast-container');
            if (!toastContainer) return;
            
            const toast = document.createElement('div');
            toast.className = `toast toast-${type}`;
            toast.innerHTML = `
                <span>${message}</span>
                <button class="toast-close" onclick="this.parentElement.remove()">&times;</button>
            `;
            toastContainer.appendChild(toast);
            
            // Auto remove after 2.5 seconds
            setTimeout(() => {
                toast.remove();
            }, 2500);
        }
        
        // Prevent form resubmission on page refresh
        if (window.history.replaceState) {
            window.history.replaceState(null, null, window.location.href);
        }
    </script>
</body>
</html>