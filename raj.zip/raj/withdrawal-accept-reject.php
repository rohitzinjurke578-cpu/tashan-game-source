<?php
session_start();
if($_SESSION['unohs'] == null){
    header("location:index.php?msg=unauthorized");
    exit();
}
include("conn.php");

// Get withdrawal details
$id = encryptor('decrypt', $_GET['id']);
$Query = mysqli_query($conn,"SELECT 
    shonu_subjects.mobile,
    shonu_subjects.email,
    shonu_subjects.owncode,
    khate.phalanubhavi,
    khate.kod,
    khate.daka,
    khate.khatehesaru,
    khate.khatesankhye,
    `hintegedukolli`.`shonu`,
    `hintegedukolli`.`motta`,
    `hintegedukolli`.`khateshonu`,
    `hintegedukolli`.`sthiti`,
    `hintegedukolli`.`dinankavannuracisi` 
FROM `hintegedukolli`
INNER JOIN shonu_subjects ON shonu_subjects.id=`hintegedukolli`.`balakedara`
INNER JOIN khate ON khate.shonu=`hintegedukolli`.`khateshonu`
WHERE `hintegedukolli`.`shonu`='".$id."'");
$Result = mysqli_fetch_array($Query);

// Get status text
$status = '';
if($Result['sthiti'] == '0') {
    $status = 'Pending';
} elseif($Result['sthiti'] == '1') {
    $status = 'Approved';
} else {
    $status = 'Rejected';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Withdrawal Details</title>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="css/common.css" rel="stylesheet">
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    :root {
      --primary: #3498db;
      --primary-light: #5dade2;
      --primary-dark: #2874a6;
      --secondary: #2ecc71;
      --secondary-dark: #27ae60;
      --danger: #e74c3c;
      --warning: #f39c12;
      --info: #1abc9c;
      --dark: #2c3e50;
      --light: #ecf0f1;
      --gray: #bdc3c7;
      --white: #ffffff;
      --sidebar-bg: #2c3e50;
      --sidebar-text: #ecf0f1;
      --sidebar-active: rgba(52, 152, 219, 0.2);
      --sidebar-submenu: #34495e;
      --card-shadow: 0 2px 8px rgba(52, 152, 219, 0.1);
      --transition: all 0.2s ease;
    }
    
    /* Detail Card Styles */
    .detail-card {
      background: var(--white);
      border-radius: 0.5rem;
      box-shadow: var(--card-shadow);
      padding: 1.5rem;
      margin: 1rem auto;
      width: 340px;
      max-width: 100%;
    }
    
    .detail-row {
      display: flex;
      justify-content: space-between;
      padding: 1rem 0;
      border-bottom: 1px solid var(--light);
    }
    
    .detail-label {
      font-weight: 500;
      color: var(--dark);
      font-size: 0.9rem;
      text-align: left;
    }
    
    .detail-value {
      color: var(--dark);
      font-weight: 600;
      text-align: right;
    }
    
    .status-badge {
      display: inline-flex;
      align-items: center;
      padding: 0.25rem 0.75rem;
      border-radius: 9999px;
      font-size: 0.75rem;
      font-weight: 600;
    }
    
    .status-pending {
      background-color: rgba(243, 156, 18, 0.1);
      color: var(--warning);
    }
    
    .status-approved {
      background-color: rgba(46, 204, 113, 0.1);
      color: var(--secondary);
    }
    
    .status-rejected {
      background-color: rgba(231, 76, 60, 0.1);
      color: var(--danger);
    }
    
    /* Content Header */
    .content-header {
      padding: 0.75rem 1.25rem;
      background: linear-gradient(to right, #ffffff, #f1f3f5);
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.06);
      border-radius: 0.375rem;
      border: 1px solid #e0e0e0;
      margin: 1rem;
      transition: all 0.3s ease;
    }

    .content-header h1 {
      font-size: 1rem;
      margin: 0;
      font-weight: 600;
      color: #343a40;
    }

    .breadcrumb {
      font-size: 0.75rem;
      color: #6c757d;
      margin-bottom: 0;
    }

    .breadcrumb a {
      color: #4f46e5;
      font-weight: 500;
      text-decoration: none;
      transition: color 0.2s ease-in-out;
    }

    .breadcrumb a:hover {
      color: #3730a3;
    }
  </style>
</head>

<body>
  <div class="wrapper">
    <?php include('compass.php'); ?>
  
    <!-- Main Content -->
    <div class="main-content">
      <!-- Navbar -->
      <nav class="navbar">
        <a href="#" class="navbar-brand" id="sidebarToggle">
          <i class="fas fa-bars"></i>
          <span>Menu</span>
        </a>
        
        <ul class="navbar-nav">
          <li class="nav-item dropdown">
            <a href="#" class="nav-link" id="settingsDropdown">
              <i class="fas fa-user-cog"></i>
            </a>
            <div class="dropdown-menu" id="settingsMenu">
              <a href="logout.php" class="dropdown-item">
                <i class="fas fa-sign-out-alt"></i> Logout
              </a>
            </div>
          </li>
        </ul>
      </nav>
      
      <!-- Content Area -->
      <div class="content-area">
        <!-- Content Header -->
        <div class="content-header">
          <div class="breadcrumb">
            <a href="dashboard.php">Home</a> / Withdrawal Details
          </div>
          <h1 class="text-xl font-bold text-gray-800">Withdrawal Details</h1>
          <p class="text-gray-500 text-sm">
            <?php echo date("l, F d, Y"); ?>
          </p>
        </div>
        
        <!-- Withdrawal Card -->
        <div class="detail-card">
          <h2 class="text-xl font-semibold text-center mb-6" style="color: var(--primary);">Bank Withdrawal Details</h2>
          
          <div class="detail-row">
            <div class="detail-label">Status</div>
            <div class="detail-value">
              <?php if($Result['sthiti'] == '0'): ?>
                <span class="status-badge status-pending">Pending</span>
              <?php elseif($Result['sthiti'] == '1'): ?>
                <span class="status-badge status-approved">Approved</span>
              <?php else: ?>
                <span class="status-badge status-rejected">Rejected</span>
              <?php endif; ?>
            </div>
          </div>
          
          <div class="detail-row">
            <div class="detail-label">Mobile Number</div>
            <div class="detail-value"><?php echo $Result['mobile']; ?></div>
          </div>
          
          <div class="detail-row">
            <div class="detail-label">Email</div>
            <div class="detail-value"><?php echo $Result['daka']; ?></div>
          </div>
          
          <div class="detail-row">
            <div class="detail-label">User Code</div>
            <div class="detail-value"><?php echo $Result['owncode']; ?></div>
          </div>
          
          <div class="detail-row">
            <div class="detail-label">Request Date</div>
            <div class="detail-value"><?php echo date('d-m-Y', strtotime($Result['dinankavannuracisi'])); ?></div>
          </div>
          
          <div class="detail-row">
            <div class="detail-label">Amount</div>
            <div class="detail-value">₹<?php echo number_format($Result['motta'], 2); ?></div>
          </div>
          
          <div class="detail-row">
            <div class="detail-label">Bank Name</div>
            <div class="detail-value"><?php echo $Result['khatehesaru']; ?></div>
          </div>
          
          <div class="detail-row">
            <div class="detail-label">IFSC Code</div>
            <div class="detail-value"><?php echo $Result['kod']; ?></div>
          </div>
          
          <div class="detail-row">
            <div class="detail-label">Account Number</div>
            <div class="detail-value"><?php echo $Result['khatesankhye']; ?></div>
          </div>
          
          <div class="detail-row" style="border-bottom: none;">
            <div class="detail-label">Account Holder Name</div>
            <div class="detail-value"><?php echo $Result['phalanubhavi']; ?></div>
          </div>
        </div>
      </div>
      
      <!-- Footer - Fixed at bottom -->
      <footer class="footer w-full bg-gradient-to-r from-slate-50 to-slate-100 border-t border-slate-200 shadow-sm py-4 px-6">
        <div class="max-w-screen-xl mx-auto text-center">
          <span class="text-sm text-slate-500">
            Powered by <strong class="text-blue-900 font-semibold">RAJVEER CODER Admin</strong>
          </span>
        </div>
      </footer>
    </div>
  </div>

  <!-- Toast Container -->
  <div id="toast-container"></div>

  <!-- JavaScript -->
  <script>
    // Toggle sidebar on mobile
    document.getElementById('sidebarToggle').addEventListener('click', function(e) {
      e.preventDefault();
      document.querySelector('.sidebar').classList.toggle('show');
    });
    
    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', function(e) {
      const sidebar = document.querySelector('.sidebar');
      const sidebarToggle = document.getElementById('sidebarToggle');
      
      if (window.innerWidth <= 768) {
        if (!sidebar.contains(e.target) && !sidebarToggle.contains(e.target)) {
          sidebar.classList.remove('show');
        }
      }
    });
    
    // Toggle dropdown menu
    document.getElementById('settingsDropdown').addEventListener('click', function(e) {
      e.preventDefault();
      document.getElementById('settingsMenu').classList.toggle('show');
    });
    
    // Close dropdown when clicking outside
    document.addEventListener('click', function(e) {
      if (!e.target.closest('.nav-item.dropdown')) {
        document.getElementById('settingsMenu').classList.remove('show');
      }
    });
    
    // Toggle sidebar submenus
    document.querySelectorAll('.sidebar-menu .has-submenu > a').forEach(item => {
      item.addEventListener('click', function(e) {
        e.preventDefault();
        const parent = this.parentElement;
        const submenu = this.nextElementSibling;
        
        // Close all other submenus
        document.querySelectorAll('.sidebar-menu .submenu').forEach(menu => {
          if (menu !== submenu) {
            menu.classList.remove('active');
            menu.previousElementSibling.classList.remove('active');
          }
        });
        
        // Toggle current submenu
        parent.classList.toggle('active');
        submenu.classList.toggle('active');
      });
    });
    
    // Show any server-side toast messages
    <?php if (isset($_SESSION['toast'])): ?>
      showToast('<?php echo $_SESSION['toast']['message']; ?>', '<?php echo $_SESSION['toast']['type']; ?>');
      <?php unset($_SESSION['toast']); ?>
    <?php endif; ?>
    
    // Show toast notification
    function showToast(message, type) {
      const toastContainer = document.getElementById('toast-container');
      const toast = document.createElement('div');
      toast.className = `toast toast-${type}`;
      toast.innerHTML = `
        <span>${message}</span>
        <button class="toast-close" onclick="this.parentElement.remove()">&times;</button>
      `;
      toastContainer.appendChild(toast);
      
      // Auto remove after 3 seconds
      setTimeout(() => {
        toast.remove();
      }, 3000);
    }
  </script>
</body>
</html>