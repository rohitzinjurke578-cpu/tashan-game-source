<?php
session_start();
if($_SESSION['unohs'] == null){
    header("location:index.php?msg=unauthorized");
}

include ("conn.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['getperiodid'])) {
    // DB से latest period ID निकालना
    $samasye = "SELECT atadaaidi FROM `gelluonduhogu_drei` ORDER BY kramasankhye DESC LIMIT 1";
    $samasyephalitansa = $conn->query($samasye);
    $samasyephalitansa_dhadi = mysqli_fetch_assoc($samasyephalitansa);
    echo $samasyephalitansa_dhadi['atadaaidi']; // response
    exit;
} 

$samasye = "SELECT atadaaidi FROM `gelluonduhogu_drei` ORDER BY kramasankhye DESC LIMIT 1";
    $samasyephalitansa = $conn->query($samasye);
    $samasyephalitansa_dhadi = mysqli_fetch_assoc($samasyephalitansa);
    
// Check settings.json for mode
$settings_file = 'settings/3min_mode.json';
$settings = file_exists($settings_file) ? json_decode(file_get_contents($settings_file), true) : ['wingo_3min_mode' => 'auto'];
$current_mode = $settings['wingo_3min_mode'] ?? 'auto';

// Check 30s.json for prediction status
$prediction_file = 'settings/3min.json';
$prediction_data = file_exists($prediction_file) ? json_decode(file_get_contents($prediction_file), true) : ['number' => null, 'prediction' => null];
$prediction_status = $prediction_data['prediction'] ?? null;
$prediction_number = $prediction_data['number'] ?? null;

// Determine next prediction display
$uhisisankhye = ($prediction_status == 'set') ? $prediction_number : "NOT SET";
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>3Min Wingo Controller</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="css/common.css" rel="stylesheet">
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
  <style>
    :root {
      --primary: #4f46e5;
      --primary-dark: #4338ca;
      --secondary: #10b981;
      --danger: #ef4444;
      --light: #e2e8f0;
      --dark: #1e293b;
      --gray: #64748b;
    }
    
    body {
      font-family: 'Poppins', sans-serif;
      background-color: #f8fafc;
    }
    
    /* Modern Card Styles */
    .modern-card {
      background: white;
      border-radius: 10px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
      padding: 1.25rem;
      margin-bottom: 1.5rem;
      max-width: 340px;
      margin-left: auto;
      margin-right: auto;
      border: 1px solid rgba(0, 0, 0, 0.05);
    }
    
    .card-title {
      font-size: 1rem;
      font-weight: 600;
      color: var(--dark);
      margin-bottom: 1rem;
      display: flex;
      align-items: center;
    }
    
    .card-title i {
      margin-right: 0.5rem;
      color: var(--primary);
    }
    
    /* Status Box */
    .status-box {
      background: linear-gradient(135deg, #f0f4ff 0%, #e6edff 100%);
      border-radius: 8px;
      padding: 1rem;
      margin-bottom: 1.5rem;
    }
    
    .status-item {
      display: flex;
      justify-content: space-between;
      margin-bottom: 0.5rem;
    }
    
    .status-label {
      font-size: 0.875rem;
      color: var(--gray);
    }
    
    .status-value {
      font-weight: 600;
      color: var(--dark);
    }
    
    .prediction-status {
      font-weight: 600;
      color: white;
      padding: 0.25rem 0.5rem;
      border-radius: 4px;
      font-size: 0.75rem;
    }
    
    .status-set {
      background-color: var(--secondary);
    }
    
    .status-notset {
      background-color: var(--danger);
    }
    
    /* Mode Selector */
    .mode-selector {
      display: flex;
      gap: 0.5rem;
      margin-bottom: 1rem;
    }
    
    .mode-option {
      flex: 1;
      text-align: center;
      padding: 0.5rem;
      border-radius: 6px;
      cursor: pointer;
      transition: all 0.2s ease;
      border: 1px solid var(--light);
      background: white;
      font-size: 0.875rem;
      font-weight: 500;
    }
    
    .mode-option:hover {
      border-color: var(--primary);
    }
    
    .mode-option.active {
      background-color: var(--primary);
      color: white;
      border-color: var(--primary);
    }
    
    /* Custom Select Box */
    .custom-select {
      position: relative;
      margin-bottom: 1rem;
    }
    
    .select-selected {
      background-color: white;
      border-radius: 6px;
      border: 1px solid var(--light);
      padding: 0.5rem 1rem;
      cursor: pointer;
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 0.875rem;
    }
    
    .select-selected:after {
      content: "\f078";
      font-family: "Font Awesome 6 Free";
      font-weight: 900;
      font-size: 0.75rem;
      transition: all 0.2s;
    }
    
    .select-selected.select-arrow-active:after {
      transform: rotate(180deg);
    }
    
    .select-items {
      position: absolute;
      background-color: white;
      top: 100%;
      left: 0;
      right: 0;
      z-index: 99;
      border-radius: 0 0 6px 6px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      max-height: 200px;
      overflow-y: auto;
      display: none;
    }
    
    .select-items div {
      padding: 0.5rem 1rem;
      cursor: pointer;
      font-size: 0.875rem;
    }
    
    .select-items div:hover {
      background-color: rgba(0, 0, 0, 0.05);
    }
    
    .select-hide {
      display: none;
    }
    
    /* Modern Buttons */
    .modern-btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: 0.5rem 1rem;
      border-radius: 6px;
      font-weight: 500;
      font-size: 0.875rem;
      cursor: pointer;
      transition: all 0.2s ease;
      border: none;
    }
    
    .modern-btn i {
      margin-right: 0.5rem;
    }
    
    .btn-primary {
      background-color: var(--primary);
      color: white;
    }
    
    .btn-primary:hover {
      background-color: var(--primary-dark);
    }
    
    .btn-success {
      background-color: var(--secondary);
      color: white;
    }
    
    .btn-danger {
      background-color: var(--danger);
      color: white;
    }
    
    /* Tables */
    .table-container {
      max-width: 340px;
      margin: 0 auto;
      overflow-x: auto;
    }
    
    .modern-table {
      width: 100%;
      border-collapse: collapse;
      font-size: 0.8125rem;
    }
    
    .modern-table th {
      background-color: var(--primary);
      color: white;
      padding: 0.5rem 0.75rem;
      text-align: left;
      position: sticky;
      top: 0;
    }
    
    .modern-table td {
      padding: 0.5rem 0.75rem;
      border-bottom: 1px solid rgba(0, 0, 0, 0.05);
    }
    
    .modern-table tr:nth-child(even) {
      background-color: rgba(0, 0, 0, 0.02);
    }
    
    .modern-table tr:hover {
      background-color: rgba(0, 0, 0, 0.05);
    }
    
    /* Loading Animation */
    .loading {
      display: inline-block;
      width: 12px;
      height: 12px;
      border: 2px solid rgba(0, 0, 0, 0.1);
      border-radius: 50%;
      border-top-color: var(--primary);
      animation: spin 1s ease-in-out infinite;
    }
    
    @keyframes spin {
      to { transform: rotate(360deg); }
    }
    
    /* Total Bet Amount */
    .total-bet {
      background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
      border-radius: 6px;
      padding: 0.5rem 1rem;
      font-weight: 600;
      color: var(--dark);
      margin-bottom: 1rem;
      text-align: center;
    }
    
    /* Footer */
    .footer {
      background: linear-gradient(to right, #f8fafc, #f1f5f9);
      border-top: 1px solid rgba(0, 0, 0, 0.05);
      padding: 1rem;
      text-align: center;
      font-size: 0.75rem;
      color: var(--gray);
    }
    
    /* Toast */
    .toast {
      position: fixed;
      bottom: 20px;
      right: 20px;
      padding: 12px 16px;
      border-radius: 6px;
      color: white;
      font-size: 14px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
      z-index: 1000;
      animation: slideIn 0.3s, fadeOut 0.5s 2.5s forwards;
    }
    
    .toast-success {
      background-color: var(--secondary);
    }
    
    .toast-error {
      background-color: var(--danger);
    }
    
    @keyframes slideIn {
      from { transform: translateX(100%); opacity: 0; }
      to { transform: translateX(0); opacity: 1; }
    }
    
    @keyframes fadeOut {
      from { opacity: 1; }
      to { opacity: 0; }
    }
    
    /* Timer */
    .timer {
      font-size: 1.5rem;
      font-weight: bold;
      color: var(--primary);
    }
    
    /* Sidebar improvements */
    .sidebar {
      transition: transform 0.3s ease;
    }
    
    .sidebar.show {
      transform: translateX(0);
    }
    
    @media (max-width: 768px) {
      .sidebar:not(.show) {
        transform: translateX(-100%);
      }
    }
    
    /* Submenu improvements */
    .submenu {
      max-height: 0;
      overflow: hidden;
      transition: max-height 0.3s ease;
    }
    
    .submenu.active {
      max-height: 500px;
    }
  </style>
</head>

<body>
  <div class="container-scroller">
    <?php include('compass.php'); ?>
  
    <div class="main-content">
      <nav class="navbar">
        <a href="#" class="navbar-brand" id="sidebarToggle">
          <i class="fas fa-bars"></i>
          <span>Menu</span>
        </a>
        
        <ul class="navbar-nav">
          <li class="nav-item dropdown">
            <a href="#" class="nav-link" id="settingsDropdown">
              <i class="fas fa-user-cog"></i>
            </a>
            <div class="dropdown-menu" id="settingsMenu">
              <a href="logout.php" class="dropdown-item">
                <i class="fas fa-sign-out-alt"></i> Logout
              </a>
            </div>
          </li>
        </ul>
      </nav>
      
      <div class="content-wrapper">
        <!-- Status Box -->
        <div class="modern-card">
          <div class="status-box">
            <div class="status-item">
              <span class="status-label">Count Down:</span>
              <span class="status-value"><span id="demo" class="timer">03:00 Min</span></span>
            </div>
            <div class="status-item">
              <span class="status-label">Period ID:</span>
              <span class="status-value" id="period-id"><?php echo $samasyephalitansa_dhadi['atadaaidi']; ?></span>
            </div>
            <div class="status-item">
              <span class="status-label">Current Mode:</span>
              <span class="status-value"><?php echo strtoupper($current_mode); ?></span>
            </div>
            <div class="status-item">
              <span class="status-label">Prediction:</span>
              <span class="prediction-status <?php echo $prediction_status == 'set' ? 'status-set' : 'status-notset'; ?>">
                <?php echo $uhisisankhye; ?>
              </span>
            </div>
          </div>
          
          <!-- Total Bet Amount -->
          <div class="total-bet">
            <span>TOTAL BET AMOUNT: </span>
            <span id="tobet">0</span>
          </div>
        </div>

        <!-- Mode Selector -->
        <div class="modern-card">
          <div class="card-title">
            <i class="fas fa-cog"></i>
            <span>Prediction Mode</span>
          </div>
          
          <div class="mode-selector">
            <div class="mode-option <?php echo $current_mode == 'api' ? 'active' : ''; ?>" data-mode="api">
              <i class="fas fa-plug"></i> API
            </div>
            <div class="mode-option <?php echo $current_mode == 'auto' ? 'active' : ''; ?>" data-mode="auto">
              <i class="fas fa-robot"></i> Auto
            </div>
            <div class="mode-option <?php echo $current_mode == 'manual' ? 'active' : ''; ?>" data-mode="manual">
              <i class="fas fa-hand-paper"></i> Manual
            </div>
          </div>
        </div>

        <!-- Prediction Control -->
        <?php if($current_mode == 'manual'): ?>
        <div class="modern-card">
          <div class="card-title">
            <i class="fas fa-magic"></i>
            <span>Manual Prediction</span>
          </div>
          
          <div class="custom-select">
            <div class="select-selected">
              <span><?php echo $prediction_number !== null ? $prediction_number : 'Select number (0-9)'; ?></span>
            </div>
            <div class="select-items select-hide">
              <?php for($i = 0; $i <= 9; $i++): ?>
                <div data-value="<?php echo $i; ?>"><?php echo $i; ?></div>
              <?php endfor; ?>
            </div>
          </div>
          
          <div class="d-flex justify-content-center gap-2">
            <?php if($prediction_status == 'set'): ?>
              <button id="updatePrediction" class="modern-btn btn-success">
                <i class="fas fa-sync-alt"></i> Update
              </button>
              <button id="unsetPrediction" class="modern-btn btn-danger">
                <i class="fas fa-times"></i> Unset
              </button>
            <?php else: ?>
              <button id="setPrediction" class="modern-btn btn-primary w-full">
                <i class="fas fa-check"></i> Set Prediction
              </button>
            <?php endif; ?>
          </div>
        </div>
        <?php endif; ?>

        <!-- Bet Details -->
        <div class="modern-card">
          <div class="card-title">
            <i class="fas fa-table"></i>
            <span>Bet Details</span>
          </div>
          
          <div class="table-container">
            <table class="modern-table">
              <thead>
                <tr>
                  <th>Result</th>
                  <th>Number</th>
                  <th>Bet</th>
                  <th>Users</th>
                  <th>Payout</th>
                </tr>
              </thead>
              <tbody id="betdetail">
                <?php 
                $samasye = mysqli_query($conn,"select * from `hastacalita_phalitansa_drei`");
                while($dhadi = mysqli_fetch_array($samasye)):
                ?>
                <tr>
                  <td><?php echo $dhadi["banna"]; ?></td>
                  <td><?php echo $dhadi["sankhye"]; ?></td>
                  <td><span class="loading"></span></td>
                  <td><span class="loading"></span></td>
                  <td><span class="loading"></span></td>
                </tr>
                <?php endwhile; ?>
              </tbody>
            </table>
          </div>
        </div>

        <!-- Live Bets -->
        <div class="modern-card">
          <div class="card-title">
            <i class="fas fa-users"></i>
            <span>Live Bets</span>
          </div>
          
          <div class="table-container">
            <table class="modern-table" id="liveBetsTable">
              <thead>
                <tr>
                  <th>User ID</th>
                  <th>Value</th>
                  <th>Amount</th>
                  <th>Mobile</th>
                  <th>Balance</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td colspan="5" class="text-center py-4">
                    <span class="loading"></span> Loading live bets...
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      
      <footer class="footer">
        <div class="d-sm-flex justify-content-center justify-content-sm-between">
          <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © RAJVEER CODER Admin</span>
        </div>
      </footer>
    </div>
  </div>

  <!-- Toast Container -->
  <div id="toast-container"></div>

  <script>
    $(document).ready(function() { 
    
    function refreshPeriodID() {
  fetch(window.location.href, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    body: 'getperiodid=yes'
  })
  .then(response => response.text())
  .then(data => {
    document.getElementById('period-id').textContent = data;
  });
}

// Auto-refresh every 1 second
setInterval(refreshPeriodID, 1000);
    
    
      // Sidebar toggle with outside click handler
      $('#sidebarToggle').click(function(e) {
        e.preventDefault();
        $('.sidebar').toggleClass('show');
      });

      // Close sidebar when clicking outside
      $(document).click(function(e) {
        if (!$(e.target).closest('.sidebar').length && !$(e.target).closest('#sidebarToggle').length) {
          $('.sidebar').removeClass('show');
        }
      });

      // Dropdown toggle
      $('#settingsDropdown').click(function(e) {
        e.preventDefault();
        $('#settingsMenu').toggleClass('show');
      });

      // Close dropdown when clicking outside
      $(document).click(function(e) {
        if (!$(e.target).closest('.nav-item.dropdown').length) {
          $('#settingsMenu').removeClass('show');
        }
      });

      // Sidebar submenu toggle - only one open at a time
      $('.sidebar-menu .has-submenu > a').click(function(e) {
        e.preventDefault();
        // Close all other submenus
        $('.sidebar-menu .has-submenu').not($(this).parent()).removeClass('active');
        $('.sidebar-menu .submenu').not($(this).next()).removeClass('active');
        
        // Toggle current submenu
        $(this).parent().toggleClass('active');
        $(this).next('.submenu').toggleClass('active');
      });
      
      // Close all submenus when clicking outside
      $(document).click(function(e) {
        if (!$(e.target).closest('.sidebar-menu').length) {
          $('.sidebar-menu .has-submenu').removeClass('active');
          $('.sidebar-menu .submenu').removeClass('active');
        }
      });

      // Custom select box
      $('.custom-select .select-selected').click(function() {
        $(this).toggleClass('select-arrow-active');
        $(this).next('.select-items').toggle();
      });
      
      $('.select-items div').click(function() {
        const value = $(this).data('value');
        $('.select-selected span').text(value);
        $('.select-selected').removeClass('select-arrow-active');
        $('.select-items').hide();
      });
      
      // Close select box when clicking outside
      $(document).click(function(e) {
        if (!$(e.target).closest('.custom-select').length) {
          $('.select-selected').removeClass('select-arrow-active');
          $('.select-items').hide();
        }
      });

      // Mode selection
      $('.mode-option').click(function() {
        const mode = $(this).data('mode');
        const currentMode = '<?php echo $current_mode; ?>';
        
        // If switching from manual mode, unset prediction
        if(currentMode === 'manual' && mode !== 'manual') {
          unsetPrediction(function() {
            updateMode(mode);
          });
        } else {
          updateMode(mode);
        }
      });
      
      function updateMode(mode) {
        $.ajax({
          url: 'update_settings_3min.php',
          type: 'POST',
          data: { 
            wingo_3min_mode: mode,
            action: 'update_mode'
          },
          success: function(response) {
            const result = JSON.parse(response);
            if(result.status === 'success') {
              showToast('Mode changed to ' + mode.toUpperCase(), 'success');
              location.reload();
            } else {
              showToast(result.message, 'error');
              // Revert UI if failed
              $('.mode-option').removeClass('active');
              $('.mode-option[data-mode="' + result.current_mode + '"]').addClass('active');
            }
          },
          error: function() {
            showToast('Failed to update mode', 'error');
          }
        });
      }

      // Set prediction
      $('#setPrediction, #updatePrediction').click(function() {
        const number = $('.select-selected span').text();
        if(number === 'Select number (0-9)') {
          showToast('Please select a number first', 'error');
          return;
        }

        const btn = $(this);
        btn.prop('disabled', true);
        btn.html('<i class="fas fa-spinner fa-spin"></i> Processing...');
        
        $.ajax({
          url: 'update_settings_3min.php',
          type: 'POST',
          data: { 
            prediction_number: number,
            action: 'set_prediction'
          },
          success: function(response) {
            const result = JSON.parse(response);
            if(result.status === 'success') {
              showToast('Prediction set to ' + number, 'success');
              location.reload();
            } else {
              showToast(result.message, 'error');
              btn.prop('disabled', false);
              btn.html('<i class="fas fa-check"></i> Set Prediction');
            }
          },
          error: function() {
            showToast('Failed to set prediction', 'error');
            btn.prop('disabled', false);
            btn.html('<i class="fas fa-check"></i> Set Prediction');
          }
        });
      });

      // Unset prediction
      $('#unsetPrediction').click(function() {
        unsetPrediction(function() {
          location.reload();
        });
      });
      
      function unsetPrediction(callback) {
        const btn = $('#unsetPrediction');
        if(btn.length) {
          btn.prop('disabled', true);
          btn.html('<i class="fas fa-spinner fa-spin"></i> Processing...');
        }
        
        $.ajax({
          url: 'update_settings_3min.php',
          type: 'POST',
          data: { 
            action: 'unset_prediction'
          },
          success: function(response) {
            const result = JSON.parse(response);
            if(result.status === 'success') {
              showToast('Prediction unset', 'success');
              if(typeof callback === 'function') callback();
            } else {
              showToast(result.message, 'error');
              if(btn.length) {
                btn.prop('disabled', false);
                btn.html('<i class="fas fa-times"></i> Unset');
              }
            }
          },
          error: function() {
            showToast('Failed to unset prediction', 'error');
            if(btn.length) {
              btn.prop('disabled', false);
              btn.html('<i class="fas fa-times"></i> Unset');
            }
          }
        });
      }

      // Show any server-side toast messages
      <?php if (isset($_SESSION['toast'])): ?>
        showToast('<?php echo $_SESSION['toast']['message']; ?>', '<?php echo $_SESSION['toast']['type']; ?>');
        <?php unset($_SESSION['toast']); ?>
      <?php endif; ?>

      // Toast function
      function showToast(message, type) {
        const toast = $(`
          <div class="toast toast-${type}">
            <span>${message}</span>
            <button class="toast-close">&times;</button>
          </div>
        `);
        $('#toast-container').append(toast);
        
        toast.find('.toast-close').click(function() {
          toast.remove();
        });
        
        setTimeout(() => toast.remove(), 3000);
      }

      // Function to refresh total bet amount
      function refreshTotalBet() {
        $.ajax({
          url: 'ottu_gellaluhogiondu_drei.php',
          type: 'POST',
          success: function(response) {
            $('#tobet').text(response);
          }
        });
      }

      // Function to refresh bet details
      function refreshBetDetails() {
        $.ajax({
          url: 'mottavannupadeyiri_drei.php',
          type: 'POST',
          data: {
            periodid: '<?php echo $samasyephalitansa_dhadi['atadaaidi']; ?>',
            actiontype: 'getdata'
          },
          success: function(response) {
            $('#betdetail').html(response);
          }
        });
      }

      // Initialize DataTable for live bets
      function initLiveBetsTable() {
        $('#liveBetsTable').DataTable({
          "processing": true,
          "serverSide": true,
          "ajax": "detavannunirvahisi_drei.php",
          "paging": true,
          "lengthChange": false,
          "searching": true,
          "ordering": false,
          "info": true,
          "autoWidth": true,
          "pageLength": 50,
          "dom": 'lrtip',
          "bDestroy": true
        });
      }

      // Timer functions from second code
      function fetchServerTime() {
        return fetch('servertime')
          .then(response => {
            if (!response.ok) {
              throw new Error(`Failed to fetch server time. Status: ${response.status}`);
            }
            return response.json().then(data => data.serverTime);
          });
      }

      function startTimer(serverTime) {
        var distance = 30 - serverTime % 30; // Change from 600 seconds to 30 seconds
        var interval = setInterval(function () {
          var minutes = Math.floor(distance / 60);
          var seconds = ('0' + Math.floor(distance % 60)).slice(-2);

        /*  document.getElementById("demo").innerHTML = 
            "<span class='timer'>0" + minutes + "</span>" +
            "<span>:</span>" +
            "<span class='timer'>" + seconds + "</span>";*/

          if (distance === 5) { // Arbitrary example action 5 seconds before reset
            resetman();
          }

          distance--;
          if (distance === 0) {
            clearInterval(interval);
            fetchServerTime()
              .then(serverTime => {
                console.log("Server Time (Unix Epoch):", serverTime);
                startTimer(serverTime);
              })
              .catch(error => {
                console.error('Error:', error);
              });
          }
        }, 1000);
      }

      function resetman() {    
        $.ajax({
          type: "Post",
          data: "stat=1",
          url: "maruhondisi_gellalu_drei.php",
          success: function (html) {
            console.log(html);
            return false;
          },
          error: function (e) {}
        });
      }

      // Initial load
      refreshTotalBet();
      refreshBetDetails();
      initLiveBetsTable();
      
      // Initialize timer
      fetchServerTime()
        .then(serverTime => {
          console.log("Server Time (Unix Epoch):", serverTime);
          startTimer(serverTime);
        })
        .catch(error => {
          console.error('Error:', error);
        });

      // Set interval for refreshes (every second)
      setInterval(refreshTotalBet, 1000);
      setInterval(refreshBetDetails, 1000);
      
      // Refresh live bets table every 2 seconds
      setInterval(function() {
        $('#liveBetsTable').DataTable().ajax.reload(null, false);
      }, 2000);
    });
  </script>
</body>
</html>