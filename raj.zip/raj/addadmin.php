<?php
session_start();
if ($_SESSION['unohs'] == null) {
    header("location:index.php?msg=unauthorized");
}
date_default_timezone_set("Asia/Kolkata");
include("conn.php");

// Get current logged in admin details
$current_admin = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM nirvahaka_shonu WHERE nirvahaka_hesaru = '".$_SESSION['unohs']."'"));

// Generate unique token for form
if (!isset($_SESSION['form_token'])) {
    $_SESSION['form_token'] = bin2hex(random_bytes(32));
}

// Handle Admin addition
if (isset($_POST['serial']) && isset($_POST['maxusers']) && isset($_POST['form_token']) && $_POST['form_token'] === $_SESSION['form_token']) {
    $username = mysqli_real_escape_string($conn, $_POST['serial']);
    $password = mysqli_real_escape_string($conn, $_POST['maxusers']);
    
    // Validate inputs
    if (empty($username) || empty($password)) {
        $_SESSION['toast'] = [
            'type' => 'error',
            'message' => 'Username and password are required'
        ];
    } else {
        // Check for duplicate username
        $chkserial = mysqli_query($conn, "SELECT * FROM `nirvahaka_shonu` WHERE `nirvahaka_hesaru`='".$username."'");
        
        if(mysqli_num_rows($chkserial) > 0) {
            $_SESSION['toast'] = [
                'type' => 'error',
                'message' => 'Username already exists'
            ];
        } else {
            // Get permissions
            $dashboard = isset($_POST['dashboard']) ? 1 : 0;
            $wingomanager = isset($_POST['wingomanager']) ? 1 : 0;
            $k3manager = isset($_POST['k3manager']) ? 1 : 0;
            $d5manager = isset($_POST['d5manager']) ? 1 : 0;
            $finance = isset($_POST['finance']) ? 1 : 0;
            $managegame = isset($_POST['managegame']) ? 1 : 0;
            $status = 1;
            
            $sql_q = "INSERT INTO nirvahaka_shonu (hesaru, nirvahaka_hesaru, guptapada, sthiti, dashboard, wingomanager, k3manager, 5dmanager, finance, managegame, owner, pwd) 
                      VALUES ('".$username."', '".$username."', '".md5($password)."', '".$status."', '".$dashboard."', '".$wingomanager."', '".$k3manager."', '".$d5manager."', '".$finance."', '".$managegame."', NULL, $password)";
            
            if(mysqli_query($conn, $sql_q)) {
                $_SESSION['toast'] = [
                    'type' => 'success',
                    'message' => 'Admin added successfully'
                ];
            } else {
                $_SESSION['toast'] = [
                    'type' => 'error',
                    'message' => 'Failed to add admin: '.mysqli_error($conn)
                ];
            }
            
            // Regenerate token after submission
            $_SESSION['form_token'] = bin2hex(random_bytes(32));
            header("Location: ".$_SERVER['PHP_SELF']);
            exit();
        }
    }
}

// Handle Admin deletion
if (isset($_POST['delete_admin']) && isset($_POST['delete_token']) && $_POST['delete_token'] === $_SESSION['form_token']) {
    $adminToDelete = mysqli_real_escape_string($conn, $_POST['delete_admin']);
    
    // Check if the admin is owner (owner=1)
    $checkOwner = mysqli_fetch_assoc(mysqli_query($conn, "SELECT owner FROM nirvahaka_shonu WHERE nirvahaka_hesaru = '$adminToDelete'"));
    
    if($checkOwner['owner'] == 1) {
        $_SESSION['toast'] = [
            'type' => 'error',
            'message' => 'Cannot delete owner admin'
        ];
    } else {
        $deleteQuery = "DELETE FROM nirvahaka_shonu WHERE nirvahaka_hesaru = '$adminToDelete'";
        if(mysqli_query($conn, $deleteQuery)) {
            $_SESSION['toast'] = [
                'type' => 'success',
                'message' => 'Admin deleted successfully'
            ];
        } else {
            $_SESSION['toast'] = [
                'type' => 'error',
                'message' => 'Failed to delete admin'
            ];
        }
    }
    
    // Regenerate token after deletion
    $_SESSION['form_token'] = bin2hex(random_bytes(32));
    header("Location: ".$_SERVER['PHP_SELF']);
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Admin Management</title>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Montserrat:wght@600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/common.css"/>
  <!-- SweetAlert2 CSS -->
  <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.6.10/dist/sweetalert2.min.css" rel="stylesheet">
  <style>
    :root {
      --primary: #5e72e4;
      --primary-dark: #4a5acf;
      --secondary: #2dce89;
      --danger: #f5365c;
      --dark: #32325d;
      --light: #f8f9fa;
      --white: #ffffff;
      --gray: #6c757d;
      --card-shadow: 0 0 1rem 0 rgba(136, 152, 170, 0.1);
      --owner-color: #ffc107;
      --admin-color: #11cdef;
    }
    
    body {
      font-family: 'Poppins', sans-serif;
      background-color: #f5f7fb;
      color: #525f7f;
    }
    
    /* Main Content Styles */
    .main-content {
      padding: 5px;
      margin-left: 250px;
      transition: all 0.3s;
    }
    
    /* Form Styles */
    .form-container {
      background: var(--white);
      padding: 0.5rem;
      border-radius: 0.5rem;
      box-shadow: var(--card-shadow);
      margin-bottom: 2rem;
    }
    
    .form-container h3 {
      color: var(--dark);
      margin-bottom: 1.5rem;
      font-weight: 600;
      display: flex;
      align-items: center;
      gap: 10px;
    }
    
    .form-group {
      margin-bottom: 1rem; 
      margin-right: 20px;
    }
    
    .form-group label {
      display: block;
      margin-bottom: 0.5rem;
      font-weight: 500;
      color: var(--dark);
      font-size: 0.9rem;
    }
    
    .form-control {
      width: 100%;
      padding: 0.75rem;
      border: 1px solid #e9ecef;
      border-radius: 0.375rem;
      font-size: 0.9rem;
      transition: all 0.3s ease;
      height: 30px;
    }
    
    .form-control:focus {
      border-color: var(--primary);
      box-shadow: 0 0 0 0.2rem rgba(94, 114, 228, 0.25);
      outline: none;
    }
    
    /* Button Styles */
    .btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: 0.75rem 1.5rem;
      border-radius: 0.375rem;
      font-weight: 500;
      font-size: 0.9rem;
      line-height: 1.5;
      cursor: pointer;
      transition: all 0.3s ease;
      border: none;
    }
    
    .btn-primary {
      background-color: var(--primary);
      color: white;
    }
    
    .btn-primary:hover {
      background-color: var(--primary-dark);
      transform: translateY(-1px);
    }
    
    .btn-sm {
      padding: 0.5rem;
      width: 36px;
      height: 36px;
    }
    
    .btn-danger {
      background-color: var(--danger);
      color: white;
    }
    
    /* Admin List Styles */
    .admin-list {
      display: grid;
    /* grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));*/
      gap: 1rem;
      list-style: none;
      padding: 0;
      margin: 0;
    }
    
    .admin-item {
      display: flex;
      flex-direction: column;
      padding: 0.6rem;
      background-color: var(--white);
      border-radius: 0.5rem;
      box-shadow: var(--card-shadow);
      transition: all 0.3s ease;
      position: relative;
      min-height: 120px;
      margin:0;
    }
    
    .admin-item.owner {
      border-left: 4px solid var(--owner-color);
      background-color: rgba(255, 193, 7, 0.05);
    }
    
    .admin-item.admin {
      border-left: 4px solid var(--admin-color);
    }
    
    .admin-item:hover {
      transform: translateY(-2px);
      box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.1);
    }
    
    .admin-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 0.5rem;
    }
    
    .admin-name {
      font-weight: 700;
      color: var(--dark);
      font-size: 1.1rem;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    
    .admin-name i {
      font-size: 1rem;
      color: var(--owner-color);
    }
    
    .admin-name .admin-icon {
      color: var(--admin-color);
    }
    
    .admin-role {
      display: inline-block;
      padding: 0.25rem 0.5rem;
      border-radius: 1rem;
      font-size: 0.75rem;
      font-weight: 600;
    }
    
    .owner-badge {
      background-color: rgba(255, 193, 7, 0.2);
      color: var(--owner-color);
    }
    
    .admin-badge {
      background-color: rgba(17, 205, 239, 0.2);
      color: var(--admin-color);
    }
    
    .admin-permissions {
      display: flex;
      flex-wrap: wrap;
      gap: 0.5rem;
      margin-top: 0.5rem;
    }
    
    .permission-badge {
      display: inline-block;
      padding: 0.25rem 0.5rem;
      border-radius: 1rem;
      font-size: 0.75rem;
      font-weight: 600;
      background-color: rgba(45, 206, 137, 0.1);
      color: var(--secondary);
    }
    
    .admin-actions {
      position: absolute;
      bottom: 10px;
      right: 10px;
    }
    
    /* Checkbox Styles */
    .checkbox-container {
      display: flex;
      align-items: center;
      margin-bottom: 1rem;
      cursor: pointer;
      user-select: none;
    }
    
    .checkbox-input {
      position: absolute;
      opacity: 0;
      cursor: pointer;
      height: 0;
      width: 0;
      color: white;
    }
     
    .checkbox-custom {
      height: 20px;
      width: 20px;
      background-color: #eee;
      border-radius: 4px;
      margin-right: 10px;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.3s;
      color: white;
    } 
    
    .checkbox-container:hover .checkbox-custom {
      background-color: #ddd;
      color: white;
    }
    
    .checkbox-input:checked ~ .checkbox-custom {
      background-color: var(--primary);
      color: white;
    }
    
    .checkbox-input:checked ~ .checkbox-custom:after {
      content: "";
      color: white;
      font-size: 0px;
    }
    
    .checkbox-label {
      font-weight: 500;
      color: var(--dark);
    }
    
    /* Current Admin Info */
    .current-admin {
      display: flex;
      align-items: center;
      gap: 10px;
      background-color: rgba(255, 193, 7, 0.1);
      padding: 10px 15px;
      border-radius: 8px;
      margin-bottom: 20px;
      border-left: 4px solid var(--owner-color);
    }
    
    .current-admin i {
      color: var(--owner-color);
      font-size: 1.2rem;
    }
    
    .current-admin span {
      font-weight: 600;
      color: var(--dark);
    }
    
    /* Mobile Responsive Adjustments */
    @media (max-width: 992px) {
      .main-content {
        margin-left: 0;
        padding: 0px;
      }
      
      .form-container {
        margin: 10px;
      }
      
      .admin-list {
        grid-template-columns: 1fr;
      }
    }
    
    /* Toast Styles */
    #toast-container {
      position: fixed;
      bottom: 20px;
      left: 7%;
      transform: translateX(0);
      z-index: 9999;
      transition: 0.4s;
    }
    
    .toast {
      min-width: 300px;
      padding: 15px 20px;
      margin-bottom: 10px;
      border-radius: 8px;
      color: white;
      font-size:14px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
      animation: slideUp 0.5s, fadeOut 0.5s 2.5s forwards;
    }
    
    .toast-success {
      background-color: var(--secondary);
    }
    
    .toast-error {
      background-color: var(--danger);
    }
    
    .toast-close {
      background: none;
      border: none;
      color: white;
      cursor: pointer;
      margin-left: 15px;
    }
    
    @keyframes slideUp {
      from { transform: translate(0%, 100%); opacity: 0; }
      to { transform: translate(0%, 0); opacity: 1; }
    }
    
    @keyframes fadeOut {
      from { opacity: 1; }
      to { opacity: 0; }
    }
    
    /* Delete Modal */
    .modal {
      display: none;
      position: fixed;
      z-index: 1000;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0,0,0,0.5);
    }
    
    .modal-content {
      background-color: white;
      margin: 15% auto;
      padding: 25px;
      border-radius: 8px;
      width: 90%;
      max-width: 400px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.2);
    }
    
    .modal-actions {
      display: flex;
      justify-content: flex-end;
      gap: 10px;
      margin-top: 20px;
    }
    
    /* Username Styles */
    .username {
      font-weight: 700;
      position: relative;
      display: inline-block;
    }
    
    .username::after {
      content: '';
      position: absolute;
      bottom: -2px;
      left: 0;
      width: 100%;
      height: 2px;
      background: linear-gradient(90deg, var(--primary), transparent);
      opacity: 0.7;
    } 
    /* Responsive Styles */ 
    
    @media (min-width: 768px) {
      .main-content {
        margin-left: 220px;
        overflow-X: scroll;
      }
      
      .form-container,
      .table-scroll-container {
        max-width: 100%;
        overflow-X; auto;
      }
      
      
      
      
    }
  </style>
</head>

<body>
  <div class="wrapper">
    <?php include('compass.php'); ?>
  
    <!-- Main Content -->
    <div class="main-content">
      <!-- Navbar -->
      <nav class="navbar">
        <a href="#" class="navbar-brand" id="sidebarToggle">
          <i class="fas fa-bars"></i>
          <span>Menu</span>
        </a>
        
        <ul class="navbar-nav">
          <li class="nav-item dropdown">
            <a href="#" class="nav-link" id="settingsDropdown">
              <i class="fas fa-user-cog"></i>
            </a>
            <div class="dropdown-menu" id="settingsMenu">
              <a href="logout.php" class="dropdown-item">
                <i class="fas fa-sign-out-alt"></i> Logout
              </a>
            </div>
          </li>
        </ul>
      </nav>
      
      <!-- Content Header -->
     <div class="content-header">
        <!-- Breadcrumbs -->
        <!--<div class="breadcrumb">
          <a href="dashboard.php">Home</a> / Admin Management
        </div>
        <h1>Admin Management</h1>
        <p><?php echo date("F d, Y"); ?></p>
      </div>
      -->
      <!-- Current Admin Info -->
      <div class="current-admin">
        <i class="fas fa-crown"></i>
        <span>Logged in as: <span class="username"></span> (Owner)</span>
      </div>
      
      <!-- Form Container -->
      <div class="form-container" style="padding: 1.5rem">
        <h3><i class="fas fa-user-plus"></i> Add New Admin</h3>
        <form action="#" id="adminform" method="post" autocomplete="off">
          <input type="hidden" name="form_token" value="<?php echo $_SESSION['form_token']; ?>">
          
          <div class="form-group">
            <label>Username</label>
            <input name="serial" type="text" placeholder="Enter username" required class="form-control" />
          </div>
          
          <div class="form-group">
            <label>Password</label>
            <input name="maxusers" type="text" placeholder="Enter password" required class="form-control" />
          </div>
          
          <h4 style="margin: 1rem 0 0.5rem 0;">Permissions</h4>
          
          <div class="checkbox-container">
            <input type="checkbox" id="dashboard" name="dashboard" value="1" class="checkbox-input">
            <span class="checkbox-custom"></span>
            <label for="dashboard" class="checkbox-label">Dashboard Access</label>
          </div>
          
          <div class="checkbox-container">
            <input type="checkbox" id="wingomanager" name="wingomanager" value="1" class="checkbox-input">
            <span class="checkbox-custom"></span>
            <label for="wingomanager" class="checkbox-label">Wingo Manager</label>
          </div>
          
          <div class="checkbox-container">
            <input type="checkbox" id="k3manager" name="k3manager" value="1" class="checkbox-input">
            <span class="checkbox-custom"></span>
            <label for="k3manager" class="checkbox-label">K3 Manager</label>
          </div>
          
          <div class="checkbox-container">
            <input type="checkbox" id="d5manager" name="d5manager" value="1" class="checkbox-input">
            <span class="checkbox-custom"></span>
            <label for="d5manager" class="checkbox-label">5D Manager</label>
          </div>
          
          <div class="checkbox-container">
            <input type="checkbox" id="finance" name="finance" value="1" class="checkbox-input">
            <span class="checkbox-custom"></span>
            <label for="finance" class="checkbox-label">Finance</label>
          </div>
          
          <div class="checkbox-container">
            <input type="checkbox" id="managegame" name="managegame" value="1" class="checkbox-input">
            <span class="checkbox-custom"></span>
            <label for="managegame" class="checkbox-label">Manage Game</label>
          </div>
          
          <button type="submit" class="btn btn-primary" id="submitBtn">
            <i class="fas fa-user-plus"></i> Add Admin
          </button>
        </form>
      </div>
      
      <!-- Admin List -->
      <div class="form-container">
        <h3><i class="fas fa-users-cog"></i> Manage Admins</h3>
        
        <ul class="admin-list">
          <?php
          $sel_admins = "SELECT * FROM nirvahaka_shonu ORDER BY 
                         CASE WHEN owner = 1 THEN 0 ELSE 1 END,
                         nirvahaka_hesaru ASC";
          $admins_r = mysqli_query($conn, $sel_admins);
          
          while ($row = mysqli_fetch_array($admins_r)): 
            // Get permissions
            $permissions = [];
            if($row['dashboard']) $permissions[] = 'Dashboard';
            if($row['wingomanager']) $permissions[] = 'Wingo';
            if($row['k3manager']) $permissions[] = 'K3';
            if($row['5dmanager']) $permissions[] = '5D';
            if($row['finance']) $permissions[] = 'Finance';
            if($row['managegame']) $permissions[] = 'Game';
            
            $isOwner = ($row['owner'] == 1);
          ?>
            <li class="admin-item <?php echo $isOwner ? 'owner' : 'admin'; ?>">
              <div class="admin-header">
                <div class="admin-name">
                  <?php if($isOwner): ?>
                    <i class="fas fa-crown"></i>
                  <?php else: ?>
                    <i class="fas fa-user-shield admin-icon"></i>
                  <?php endif; ?>
                  <span class="username"><?php echo $row['nirvahaka_hesaru']; ?></span>
                </div>
                <span class="admin-role <?php echo $isOwner ? 'owner-badge' : 'admin-badge'; ?>">
                  <?php echo $isOwner ? 'Owner' : 'Admin'; ?>
                </span>
              </div>
              
              <div class="admin-permissions">
                <?php foreach($permissions as $perm): ?>
                  <span class="permission-badge"><?php echo $perm; ?></span>
                <?php endforeach; ?>
                <?php if(empty($permissions)): ?>
                  <span class="permission-badge" style="background-color: rgba(108, 117, 125, 0.1); color: var(--gray);">No Permissions</span>
                <?php endif; ?>
              </div>
              
              <div class="admin-actions">
                <?php if(!$isOwner): ?>
                  <button class="btn btn-danger btn-sm" onclick="confirmDelete('<?php echo $row['nirvahaka_hesaru']; ?>')" title="Delete">
                    <i class="fas fa-trash-alt"></i>
                  </button>
                <?php endif; ?>
              </div>
            </li>
          <?php endwhile; ?>
        </ul>
      </div>
      
      <!-- Footer -->
     <!-- <footer class="footer">
        <div class="d-sm-flex justify-content-center justify-content-sm-between">
          <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Powered by RAJVEER CODER Admin</span>
        </div>
      </footer>-->
    </div>
  </div>

  <!-- Toast Container -->
  <div id="toast-container"></div>

  <!-- Delete Confirmation Modal -->
  <div id="deleteModal" class="modal">
    <div class="modal-content">
      <h3>Confirm Deletion</h3>
      <p>Are you sure you want to delete this admin? This action cannot be undone.</p>
      <form id="deleteForm" method="post">
        <input type="hidden" name="delete_admin" id="deleteAdminId">
        <input type="hidden" name="delete_token" value="<?php echo $_SESSION['form_token']; ?>">
        <div class="modal-actions">
          <button type="button" onclick="closeModal()" class="btn btn-secondary">Cancel</button>
          <button type="submit" class="btn btn-danger">Delete</button>
        </div>
      </form>
    </div>
  </div>

  <!-- JavaScript -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.6.10/dist/sweetalert2.min.js"></script>
  <script>
    // Toggle sidebar on mobile
    document.getElementById('sidebarToggle').addEventListener('click', function(e) {
      e.preventDefault();
      document.querySelector('.sidebar').classList.toggle('show');
    });
    
    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', function(e) {
      const sidebar = document.querySelector('.sidebar');
      const sidebarToggle = document.getElementById('sidebarToggle');
      
      if (window.innerWidth <= 992) {
        if (!sidebar.contains(e.target) && !sidebarToggle.contains(e.target)) {
          sidebar.classList.remove('show');
        }
      }
    });
    
    // Toggle dropdown menu
    document.getElementById('settingsDropdown').addEventListener('click', function(e) {
      e.preventDefault();
      document.querySelector('.dropdown-menu').classList.toggle('show');
    });
    
    // Close dropdown when clicking outside
    document.addEventListener('click', function(e) {
      if (!e.target.closest('.nav-item.dropdown')) {
        document.querySelector('.dropdown-menu').classList.remove('show');
      }
    });
    
    // Toggle submenus in sidebar - FIXED VERSION
    document.querySelectorAll('.sidebar-menu .has-submenu > a').forEach(item => {
      item.addEventListener('click', function(e) {
        e.preventDefault();
        const parent = this.parentElement;
        const submenu = this.nextElementSibling;
        
        // Close all other submenus
        document.querySelectorAll('.sidebar-menu .submenu').forEach(menu => {
          if (menu !== submenu) {
            menu.classList.remove('active');
            menu.previousElementSibling.classList.remove('active');
          }
        });
        
        // Toggle current submenu
        parent.classList.toggle('active');
        submenu.classList.toggle('active');
      });
    });
    // Form validation and submission handling
    document.getElementById('adminform').addEventListener('submit', function(e) {
      e.preventDefault();
      const usernameInput = this.querySelector('input[name="serial"]');
      const passwordInput = this.querySelector('input[name="maxusers"]');
      const submitBtn = document.getElementById('submitBtn');
      
      if (usernameInput.value.trim() === '' || passwordInput.value.trim() === '') {
        showToast('Username and password are required', 'error');
        return;
      }
      
      // Disable button to prevent double submission
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Adding...';
      
      // Submit form
      this.submit();
    });
    
    // Delete confirmation
    function confirmDelete(adminId) {
      const modal = document.getElementById('deleteModal');
      document.getElementById('deleteAdminId').value = adminId;
      modal.style.display = 'block';
    }
    
    function closeModal() {
      document.getElementById('deleteModal').style.display = 'none';
    }
    
    // Close modal when clicking outside
    window.onclick = function(event) {
      const modal = document.getElementById('deleteModal');
      if (event.target == modal) {
        modal.style.display = 'none';
      }
    }
    
    // Show toast notification
    function showToast(message, type) {
      const toastContainer = document.getElementById('toast-container');
      const toast = document.createElement('div');
      toast.className = `toast toast-${type}`;
      toast.innerHTML = `
        <span>${message}</span>
        <button class="toast-close" onclick="this.parentElement.remove()">&times;</button>
      `;
      toastContainer.appendChild(toast);
      
      // Auto remove after 3 seconds
      setTimeout(() => {
        toast.remove();
      }, 3000);
    }
    
    // Show any server-side toast messages
    <?php if (isset($_SESSION['toast'])): ?>
      document.addEventListener('DOMContentLoaded', function() {
        showToast('<?php echo $_SESSION['toast']['message']; ?>', '<?php echo $_SESSION['toast']['type']; ?>');
      });
      <?php unset($_SESSION['toast']); ?>
    <?php endif; ?>
    
    // Handle checkbox clicks
    document.querySelectorAll('.checkbox-container').forEach(container => {
      container.addEventListener('click', function() {
        const checkbox = this.querySelector('.checkbox-input');
        checkbox.checked = !checkbox.checked;
        
        // Trigger visual change
        const customCheckbox = this.querySelector('.checkbox-custom');
        if(checkbox.checked) {
          customCheckbox.style.backgroundColor = '#5e72e4';
          customCheckbox.innerHTML = '✓';
        } else {
          customCheckbox.style.backgroundColor = '#eee';
          customCheckbox.innerHTML = '';
        }
      });
    });
  </script>
</body>
</html>