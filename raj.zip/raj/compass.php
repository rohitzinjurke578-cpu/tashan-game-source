  <!-- ==================== Sidebar ==================== -->
    <div class="sidebar">
      <div class="sidebar-header">
        <img src="../logo.png" alt="Logo">
      </div>
      <?php
          $chkserial = mysqli_query($conn,"select * from `nirvahaka_shonu` where `unohs`='".$_SESSION['unohs']."'");
          $salu = mysqli_fetch_array($chkserial);
          $wingomanager = $salu['wingomanager'];
          $k3manager = $salu['k3manager'];
          $d5manager = $salu['5dmanager'];
          $finance = $salu['finance'];
          $managegame = $salu['managegame'];
          $support = $salu['support'];
          
          if($wingomanager == 1):
        ?>
      <div class="user-profile">
        <div class="user-image">
          <img src="images/rajveer.jpg" alt="User Image">
        </div>
        <h4 class="user-name" style="text-transform: uppercase; font-weight: bold"> <?php echo $admin = $salu['hesaru']; ?></h4>
        <div class="user-designation"></div>
      </div>
      
      <div class="sidebar-menu">
        <!-- Dashboard Link -->
        <a href="dashboard.php" class="active">
          <i class="fas fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
        
        
        <!-- WinGo Manager Section -->
        <div class="has-submenu">
          <a href="#">
            <i class="fas fa-gamepad"></i>
            <span>WinGo Manager</span>
          </a>
          <div class="submenu">
            <a href="wingo30s.php"><i class="fas fa-stopwatch"></i> WinGo 30 sec</a>
            <a href="wingo1min.php"><i class="fas fa-stopwatch"></i> WinGo 1 Min</a>
            <a href="wingo3min.php"><i class="fas fa-stopwatch"></i> WinGo 3 Min</a>
            <a href="wingo5min.php"><i class="fas fa-stopwatch"></i> WinGo 5 Min</a>
          </div>
        </div>
        <?php endif; ?>
        
        <?php if($k3manager == 1): ?>
        <!-- K3 Manager Section -->
        <div class="has-submenu">
          <a href="#">
            <i class="fas fa-dice-three"></i>
            <span>K3 Manager</span>
          </a>
          <div class="submenu">
            <a href="k31min.php"><i class="fas fa-stopwatch"></i> K3 1 Min</a>
            <a href="k33min.php"><i class="fas fa-stopwatch"></i> K3 3 Min</a>
            <a href="k35min.php"><i class="fas fa-stopwatch"></i> K3 5 Min</a>
            <a href="k310min.php"><i class="fas fa-stopwatch"></i> K3 10 Min</a>
          </div>
        </div>
        <?php endif; ?>
        
        <?php if($d5manager == 1): ?>
        <!-- 5D Manager Section -->
        <div class="has-submenu">
          <a href="#">
            <i class="fas fa-dice-five"></i>
            <span>5D Manager</span>
          </a>
          <div class="submenu">
            <a href="5d1min.php"><i class="fas fa-stopwatch"></i> 5D 1 Min</a>
            <a href="5d3min.php"><i class="fas fa-stopwatch"></i> 5D 3 Min</a>
            <a href="5d5min.php"><i class="fas fa-stopwatch"></i> 5D 5 Min</a>
            <a href="5d10min.php"><i class="fas fa-stopwatch"></i> 5D 10 Min</a>
          </div>
        </div>
        <?php endif; ?>
        
        <?php if($finance == 1): ?>
        <!-- Finance Section -->
        <div class="has-submenu">
          <a href="#">
            <i class="fas fa-wallet"></i>
            <span>Finance</span>
          </a>
          <div class="submenu">
            <a href="addupi.php"><i class="fas fa-money-bill-wave"></i> Manage UPI Details</a>
            <a href="usdtkids.php"><i class="fas fa-dollar-sign"></i> USDT RATE</a>
            <a href="addusdt.php"><i class="fas fa-coins"></i> USDT Address</a>
           
            <a href="addimgusdt_2.php"><i class="fas fa-image"></i>USDT QR</a>
            <a href="deposit_update.php"><i class="fas fa-hand-holding-usd"></i> Manage Deposits</a>
            <a href="manage_withdraw.php"><i class="fas fa-money-check-alt"></i> Manage Withdrawals</a>
           
          </div>
        </div>
        <?php endif; ?>
        
        <?php if($support == 1): ?>
        <!-- Support Section -->
        <div class="has-submenu">
          <a href="#">
            <i class="fas fa-headset"></i>
            <span>Support</span>
          </a>
          <div class="submenu">
            <a href="deposite.php"><i class="fas fa-question-circle"></i> Deposite Problem</a>
            <a href="withprob.php"><i class="fas fa-question-circle"></i> Withdrawal problem</a>
            <a href="ifscm.php"><i class="fas fa-university"></i> IFSC Modification</a>
            <a href="bankm.php"><i class="fas fa-exchange-alt"></i> Bank Modification</a>
            <a href="gamep.php"><i class="fas fa-gamepad"></i> Game Problem</a>
          </div>
        </div>
        <?php endif; ?>
        
        <?php if($managegame == 1): ?>
        <!-- Manage Game Section -->
        <div class="has-submenu">
          <a href="#">
            <i class="fas fa-cog"></i>
            <span>Manage Game</span>
          </a>
          <div class="submenu">
            <a href="userbonus.php"><i class="fas fa-gift"></i> Bonus Manage</a>
            <a href="adminpass.php"><i class="fas fa-key"></i> Admin Password</a>
            <a href="autobanuser.php"><i class="fas fa-user-shield"></i> Check Baned Users</a>
            <a href="abmain.php"><i class="fas fa-tools"></i> Site Maintance</a>
    
            <a href="manage_user.php"><i class="fas fa-users"></i> Users</a>
            <a href="manage_salary.php"><i class="fas fa-money-bill-alt"></i> Daily Salary</a>
            <a href="addgiftcode.php"><i class="fas fa-code"></i> Gift Code</a>
            <a href="addadmin.php"><i class="fas fa-user-plus"></i>Manage Admin</a>
            <a href="demouser.php"><i class="fas fa-user-edit"></i> Demo User</a>
            <a href="agentuser.php"><i class="fas fa-user-tie"></i> Agent User</a>
          </div>
        </div>
        <?php endif; ?>
        
        <!-- Website Link -->
        <a href="https://56lottery.site">
          <i class="fas fa-external-link-alt"></i>
          <span>Go To Website</span>
        </a>
      </div>
    </div>
    <!-- ==================== End Sidebar ==================== -->
    