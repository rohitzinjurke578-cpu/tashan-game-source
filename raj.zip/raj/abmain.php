<?php
session_start();
if ($_SESSION['unohs'] == null) {
    header("location:index.php?msg=unauthorized");
}
date_default_timezone_set("Asia/Kolkata");
include("conn.php");

// Generate unique token for form
if (!isset($_SESSION['form_token'])) {
    $_SESSION['form_token'] = bin2hex(random_bytes(32));
}

// Handle maintenance mode toggle
if (isset($_POST['toggleMaintenance']) && isset($_POST['form_token']) && $_POST['form_token'] === $_SESSION['form_token']) {
    $newStatus = ($_POST['toggleMaintenance'] === 'active') ? 'inactive' : 'active';
    $updateQuery = "UPDATE maintenance SET status='$newStatus' WHERE id=1";
    $updateResult = mysqli_query($conn, $updateQuery);

    if ($updateResult) {
        $_SESSION['toast'] = [
            'type' => 'success',
            'message' => 'Maintenance mode ' . $newStatus
        ];
    } else {
        $_SESSION['toast'] = [
            'type' => 'error',
            'message' => 'Failed to update maintenance mode'
        ];
    }
    
    header("Location: ".$_SERVER['PHP_SELF']);
    exit();
}

// Handle maintenance message update
if (isset($_POST['maintenance_message']) && isset($_POST['form_token']) && $_POST['form_token'] === $_SESSION['form_token']) {
    $message = mysqli_real_escape_string($conn, $_POST['maintenance_message']);
    $updateQuery = "UPDATE maintenance SET message='$message' WHERE id=1";
    $updateResult = mysqli_query($conn, $updateQuery);

    if ($updateResult) {
        $_SESSION['toast'] = [
            'type' => 'success',
            'message' => 'Maintenance message updated'
        ];
    } else {
        $_SESSION['toast'] = [
            'type' => 'error',
            'message' => 'Failed to update maintenance message'
        ];
    }
    
    header("Location: ".$_SERVER['PHP_SELF']);
    exit();
}

// Get current maintenance status
$query = "SELECT status, message FROM maintenance WHERE id = 1";
$result = mysqli_query($conn, $query);
$maintenanceData = ['status' => 'inactive', 'message' => ''];
if ($result && mysqli_num_rows($result) > 0) {
    $maintenanceData = mysqli_fetch_assoc($result);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
  <title>Maintenance Mode</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="css/common.css" rel="stylesheet">
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    :root {
      --primary: #4f46e5;
      --primary-dark: #4338ca;
      --danger: #dc2626;
      --success: #16a34a;
      --dark: #1e293b;
      --light: #f8fafc;
    }
    
    body {
      font-family: 'Inter', sans-serif;
      background-color: #f1f5f9;
      overflow-x: hidden;
    }
    
    .wrapper {
      display: flex;
      min-height: 100vh;
    }
    
    .main-content {
      flex: 1;
      min-width: 0; /* Fixes overflow issues */
    }
    
    .content-header {
      padding: 0.75rem 1rem;
      background: white;
      margin: 0.5rem;
      border-radius: 0.5rem;
      box-shadow: 0 1px 2px rgba(0,0,0,0.05);
    }
    
    .form-container {
      background: white;
      padding: 1.25rem;
      border-radius: 0.5rem;
      margin: 0.5rem;
      box-shadow: 0 1px 3px rgba(0,0,0,0.1);
      max-width: 100%;
      box-sizing: border-box;
    }
    
    /* Professional Toggle Switch */
    .toggle-container {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0.75rem;
      background: #f8fafc;
      border-radius: 0.5rem;
      margin-bottom: 1rem;
    }
    
    .toggle-wrapper {
      display: flex;
      align-items: center;
    }
    
    .toggle-switch {
      position: relative;
      width: 50px;
      height: 26px;
    }
    
    .toggle-switch input {
      opacity: 0;
      width: 0;
      height: 0;
    }
    
    .toggle-slider {
      position: absolute;
      cursor: pointer;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: #e2e8f0;
      transition: .4s;
      border-radius: 34px;
    }
    
    .toggle-slider:before {
      position: absolute;
      content: "";
      height: 20px;
      width: 20px;
      left: 3px;
      bottom: 3px;
      background-color: white;
      transition: .4s;
      border-radius: 50%;
      box-shadow: 0 1px 3px rgba(0,0,0,0.2);
    }
    
    input:checked + .toggle-slider {
      background-color: var(--primary);
    }
    
    input:checked + .toggle-slider:before {
      transform: translateX(24px);
    }
    
    /* Status Badge */
    .status-badge {
      display: inline-flex;
      align-items: center;
      padding: 0.35rem 0.75rem;
      border-radius: 9999px;
      font-size: 0.8125rem;
      font-weight: 600;
    }
    
    .status-active {
      background-color: #fee2e2;
      color: var(--danger);
    }
    
    .status-inactive {
      background-color: #dcfce7;
      color: var(--success);
    }
    
    /* Message Box */
    .message-box {
      width: 100%;
      min-height: 120px;
      padding: 0.75rem;
      border-radius: 0.375rem;
      border: 1px solid #e2e8f0;
      font-family: inherit;
      box-sizing: border-box;
      resize: vertical;
    }
    
    .message-box:focus {
      outline: none;
      border-color: var(--primary);
      box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1);
    }
    
    /* Buttons */
    .btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: 0.625rem 1.25rem;
      border-radius: 0.375rem;
      font-weight: 500;
      font-size: 0.875rem;
      cursor: pointer;
      transition: all 0.2s;
      border: none;
    }
    
    .btn-primary {
      background-color: var(--primary);
      color: white;
    }
    
    .btn-primary:hover {
      background-color: var(--primary-dark);
    }
    
    /* Mobile Responsiveness */
    @media (max-width: 640px) {
      .content-header, .form-container {
        margin: 0.5rem;
        width: calc(100% - 1rem);
        max-width: 100%;
        box-sizing: border-box;
      }
      
      .main-content {
        padding-bottom: 1rem;
      }
    }
    
    /* Keep existing toast styles */
    #toast-container {
      position: fixed;
      bottom: 20px;
      right: 20px;
      z-index: 9999;
    }
    
    .toast {
      min-width: 280px;
      padding: 12px 16px;
      margin-bottom: 10px;
      border-radius: 8px;
      color: white;
      font-size: 14px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      animation: slideIn 0.3s, fadeOut 0.5s 2.5s forwards;
    }
    
    .toast-success {
      background-color: var(--success);
    }
    
    .toast-error {
      background-color: var(--danger);
    }
  </style>
</head>

<body>
  <div class="wrapper">
    <?php include('compass.php'); ?>
  
    <div class="main-content">
      <nav class="navbar">
        <a href="#" class="navbar-brand" id="sidebarToggle">
          <i class="fas fa-bars"></i>
          <span>Menu</span>
        </a>
        
        <ul class="navbar-nav">
          <li class="nav-item dropdown">
            <a href="#" class="nav-link" id="settingsDropdown">
              <i class="fas fa-user-cog"></i>
            </a>
            <div class="dropdown-menu" id="settingsMenu">
              <a href="logout.php" class="dropdown-item">
                <i class="fas fa-sign-out-alt"></i> Logout
              </a>
            </div>
          </li>
        </ul>
      </nav>
      
      <div class="content-header hidden">
        <div class="breadcrumb">
          <a href="dashboard.php">Home</a> / Maintenance
        </div>
        <h1 class="text-xl font-bold text-gray-800">Maintenance Mode</h1>
      </div>
      
      <div class="form-container">
        <h3 class="text-lg font-semibold text-gray-800 mb-4">
          <i class="fas fa-tools text-blue-500 mr-2"></i>System Status
        </h3>
        
        <div class="toggle-container">
          <div class="toggle-wrapper">
            <span class="status-badge <?php echo $maintenanceData['status'] === 'active' ? 'status-active' : 'status-inactive'; ?>">
              <i class="fas <?php echo $maintenanceData['status'] === 'active' ? 'fa-exclamation-circle' : 'fa-check-circle'; ?> mr-1"></i>
              <?php echo ucfirst($maintenanceData['status']); ?>
            </span>
          </div>
          
          <form method="post" class="flex items-center">
            <input type="hidden" name="form_token" value="<?php echo $_SESSION['form_token']; ?>">
            <input type="hidden" name="toggleMaintenance" value="<?php echo $maintenanceData['status']; ?>">
            <label class="toggle-switch">
              <input type="checkbox" <?php echo $maintenanceData['status'] === 'active' ? 'checked' : ''; ?> onchange="this.form.submit()">
              <span class="toggle-slider"></span>
            </label>
          </form>
        </div>
        
        <?php if (!empty($maintenanceData['message'])): ?>
        <div class="bg-blue-50 border-l-4 border-blue-400 rounded p-3 mb-4">
          <div class="flex">
            <div class="flex-shrink-0 text-blue-400">
              <i class="fas fa-info-circle"></i>
            </div>
            <div class="ml-3">
              <p class="text-sm text-blue-700">
                <strong>Current Message:</strong><br>
                <?php echo htmlspecialchars($maintenanceData['message']); ?>
              </p>
            </div>
          </div>
        </div>
        <?php endif; ?>
        
        <form method="post">
          <input type="hidden" name="form_token" value="<?php echo $_SESSION['form_token']; ?>">
          <div class="mb-3">
            <label class="block text-sm font-medium text-gray-700 mb-1">Maintenance Message</label>
            <textarea name="maintenance_message" class="message-box" placeholder="Enter message to display to users..."><?php echo htmlspecialchars($maintenanceData['message']); ?></textarea>
          </div>
          <button type="submit" class="btn btn-primary">
            <i class="fas fa-save mr-2"></i> Update Message
          </button>
        </form>
      </div>
    </div>
  </div>

  <div id="toast-container"></div>

  <script>
        // Toggle sidebar on mobile
    document.getElementById('sidebarToggle').addEventListener('click', function(e) {
      e.preventDefault();
      document.querySelector('.sidebar').classList.toggle('show');
    });
    
    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', function(e) {
      const sidebar = document.querySelector('.sidebar');
      const sidebarToggle = document.getElementById('sidebarToggle');
      
      if (window.innerWidth <= 768) {
        if (!sidebar.contains(e.target) && !sidebarToggle.contains(e.target)) {
          sidebar.classList.remove('show');
        }
      }
    });
    
    // Toggle dropdown menu
    document.getElementById('settingsDropdown').addEventListener('click', function(e) {
      e.preventDefault();
      document.getElementById('settingsMenu').classList.toggle('show');
    });
    
    // Close dropdown when clicking outside
    document.addEventListener('click', function(e) {
      if (!e.target.closest('.nav-item.dropdown')) {
        document.getElementById('settingsMenu').classList.remove('show');
      }
    });
    
    // Toggle submenus in sidebar
    document.querySelectorAll('.sidebar-menu .has-submenu > a').forEach(item => {
      item.addEventListener('click', function(e) {
        e.preventDefault();
        const parent = this.parentElement;
        const submenu = this.nextElementSibling;
        
        // Close all other submenus
        document.querySelectorAll('.sidebar-menu .submenu').forEach(menu => {
          if (menu !== submenu) {
            menu.classList.remove('active');
            menu.previousElementSibling.classList.remove('active');
          }
        });
        
        // Toggle current submenu
        parent.classList.toggle('active');
        submenu.classList.toggle('active');
      });
    });
    
    // Show toast notification
    function showToast(message, type) {
      const toastContainer = document.getElementById('toast-container');
      const toast = document.createElement('div');
      toast.className = `toast toast-${type}`;
      toast.innerHTML = `
        <span>${message}</span>
        <button class="toast-close" onclick="this.parentElement.remove()">&times;</button>
      `;
      toastContainer.appendChild(toast);
      
      setTimeout(() => {
        toast.remove();
      }, 3000);
    }
    
    <?php if (isset($_SESSION['toast'])): ?>
      document.addEventListener('DOMContentLoaded', function() {
        showToast('<?php echo $_SESSION['toast']['message']; ?>', '<?php echo $_SESSION['toast']['type']; ?>');
      });
      <?php unset($_SESSION['toast']); ?>
    <?php endif; ?>
  </script>
</body>
</html>