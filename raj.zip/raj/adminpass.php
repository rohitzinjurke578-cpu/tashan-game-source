<?php
session_start();
if ($_SESSION['unohs'] == null) {
    header("location:index.php?msg=unauthorized");
}
date_default_timezone_set("Asia/Kolkata");
include("conn.php");

// Generate unique token for form
if (!isset($_SESSION['form_token'])) {
    $_SESSION['form_token'] = bin2hex(random_bytes(32));
}

// Function to update admin password
function updateAdminPassword($username, $newPassword, $conn) {
    // Check if user is owner (owner=1)
    $checkQuery = "SELECT owner FROM nirvahaka_shonu WHERE nirvahaka_hesaru = '$username'";
    $checkResult = mysqli_query($conn, $checkQuery);
    
    if (!$checkResult || mysqli_num_rows($checkResult) == 0) {
        return "Admin not found";
    }
    
    $adminData = mysqli_fetch_assoc($checkResult);
    if ($adminData['owner'] != 1) {
        return "Only owner can change passwords";
    }
    
    $hashedPassword = md5($newPassword);
    $query = "UPDATE nirvahaka_shonu SET guptapada='$hashedPassword', pwd='$newPassword' WHERE nirvahaka_hesaru='$username'";
    $result = mysqli_query($conn, $query);
    return $result ? "Password updated successfully" : "Failed to update password";
}

// Function to get admin list with decoded password
function getAdminList($conn) {
    $query = "SELECT unohs, hesaru, pwd, nirvahaka_hesaru, guptapada, owner FROM nirvahaka_shonu ORDER BY unohs";
    $result = mysqli_query($conn, $query);
    $admins = [];
    
    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            // Note: MD5 is one-way hashing, we can't truly "decode" it
            // We'll just show the hash but allow copying
            $row['password_display'] = $row['pwd'];
            $admins[] = $row;
        }
    }
    
    return $admins;
}

// Handle admin password update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['admin_form'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $newPassword = mysqli_real_escape_string($conn, $_POST['new_password']);
    
    if (!empty($username) && !empty($newPassword)) {
        $result = updateAdminPassword($username, $newPassword, $conn);
        $_SESSION['toast'] = [
            'type' => strpos($result, 'successfully') !== false ? 'success' : 'error',
            'message' => $result
        ];
    } else {
        $_SESSION['toast'] = [
            'type' => 'error',
            'message' => 'Username and password cannot be empty'
        ];
    }
    
    header("Location: ".$_SERVER['PHP_SELF']);
    exit();
}

// Get admin list
$adminList = getAdminList($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
  <title>Admin Management</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="css/common.css" rel="stylesheet">
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
        :root {
      --primary: #4f46e5;
      --primary-dark: #4338ca;
      --danger: #dc2626;
      --success: #16a34a;
      --dark: #1e293b;
      --light: #f8fafc;
    }
    
    body {
      font-family: 'Inter', sans-serif;
      background-color: #f1f5f9;
      overflow-x: hidden;
    }
    
    .wrapper {
      display: flex;
      min-height: 100vh;
    }
    
    .main-content {
      flex: 1;
      min-width: 0;
    }
    
    .form-container {
      background: white;
      padding: 1.25rem;
      border-radius: 0.5rem;
      margin: 0.5rem;
      box-shadow: 0 1px 3px rgba(0,0,0,0.1);
      max-width: 600px;
      box-sizing: border-box;
    }
    
    /* Input styles */
    .input-field {
      width: 100%;
      padding: 0.75rem;
      border: 1px solid #e2e8f0;
      border-radius: 0.375rem;
      margin-bottom: 1.25rem;
      font-size: 0.875rem;
    }
    
    .input-field:focus {
      outline: none;
      border-color: var(--primary);
      box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1);
    }
    
    /* Buttons */
    .btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: 0.625rem 1.25rem;
      border-radius: 0.375rem;
      font-weight: 500;
      font-size: 0.875rem;
      cursor: pointer;
      transition: all 0.2s;
      border: none;
    }
    
    .btn-primary {
      background-color: var(--primary);
      color: white;
    }
    
    .btn-primary:hover {
      background-color: var(--primary-dark);
    }
    
    /* Toast styles */
    #toast-container {
      position: fixed;
      bottom: 20px;
      right: 20px;
      z-index: 9999;
    }
    
    .toast {
      min-width: 280px;
      padding: 12px 16px;
      margin-bottom: 10px;
      border-radius: 8px;
      color: white;
      font-size: 14px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      animation: slideIn 0.3s, fadeOut 0.5s 2.5s forwards;
    }
    
    .toast-success {
      background-color: var(--success);
    }
    
    .toast-error {
      background-color: var(--danger);
    }
    
    .toast-close {
      background: none;
      border: none;
      color: white;
      font-size: 18px;
      cursor: pointer;
      margin-left: 10px;
    }
    
    @keyframes slideIn {
      from { transform: translateX(100%); opacity: 0; }
      to { transform: translateX(0); opacity: 1; }
    }
    
    @keyframes fadeOut {
      from { opacity: 1; }
      to { opacity: 0; }
    }
    
    /* Admin list styles */
    .admin-list-container {
      background: white;
      padding: 1.25rem;
      border-radius: 0.5rem;
      margin: 0.5rem;
      box-shadow: 0 1px 3px rgba(0,0,0,0.1);
      max-width: 100%;
      box-sizing: border-box;
      overflow-X: scroll;
    }
    
    .admin-list-header {
      font-size: 1.125rem;
      font-weight: 600;
      color: #1e293b;
      margin-bottom: 1rem;
      display: flex;
      align-items: center;
    }
    
    .admin-list {
      width: 100%;
      border-collapse: collapse;
    }
    
    .admin-list th {
      background-color: #f8fafc;
      padding: 0.75rem;
      text-align: left;
      font-weight: 600;
      color: #64748b;
      border-bottom: 1px solid #e2e8f0;
    }
    
    .admin-list td {
      padding: 0.75rem;
      border-bottom: 1px solid #e2e8f0;
      color: #334155;
    }
    
    .admin-list tr:last-child td {
      border-bottom: none;
    }
    
    .admin-list tr:hover {
      background-color: #f8fafc;
    }
    
    .admin-id {
      font-weight: 500;
      color: #1e293b;
    }
    
    .admin-name {
      font-weight: 500;
      color: #1e293b;
    }
    
    .admin-username {
      color: #64748b;
    }
    
    .password-container {
      display: flex;
      align-items: center;
    }
    
    .password-display {
      font-family: monospace;
      margin-right: 8px;
    }
    
    .password-toggle {
      background: none;
      border: none;
      color: #64748b;
      cursor: pointer;
    }
    
    .copy-password {
      background: none;
      border: none;
      color: #64748b;
      cursor: pointer;
      margin-left: 8px;
    }
    
    .owner-badge {
      display: inline-block;
      padding: 2px 6px;
      border-radius: 4px;
      font-size: 0.75rem;
      font-weight: 600;
    }
    
    .owner-yes {
      background-color: #dcfce7;
      color: #166534;
    }
    
    .owner-no {
      background-color: #fee2e2;
      color: #991b1b;
    }
    
    @media (max-width: 640px) {
      .admin-list th, .admin-list td {
        padding: 0.5rem;
        font-size: 0.875rem;
      }
    }
  </style>
</head>

<body>
  <div class="wrapper">
    <?php include('compass.php'); ?>
  
    <div class="main-content">
      <nav class="navbar">
        <a href="#" class="navbar-brand" id="sidebarToggle">
          <i class="fas fa-bars"></i>
          <span>Menu</span>
        </a>
        
        <ul class="navbar-nav">
          <li class="nav-item dropdown">
            <a href="#" class="nav-link" id="settingsDropdown">
              <i class="fas fa-user-cog"></i>
            </a>
            <div class="dropdown-menu" id="settingsMenu">
              <a href="logout.php" class="dropdown-item">
                <i class="fas fa-sign-out-alt"></i> Logout
              </a>
            </div>
          </li>
        </ul>
      </nav>
      
      <div class="form-container">
        <h3 class="text-lg font-semibold text-gray-800 mb-4">
          <i class="fas fa-user-shield text-blue-500 mr-2"></i>Admin Password Management
        </h3>
        
        <form method="POST">
          <input type="hidden" name="form_token" value="<?php echo $_SESSION['form_token']; ?>">
          <input type="hidden" name="admin_form" value="1">
          
          <div class="mb-3">
            <label class="block text-sm font-medium text-gray-700 mb-1">Enter Admin Username</label>
            <input type="text" name="username" class="input-field" required>
          </div>
          
          <div class="mb-3">
            <label class="block text-sm font-medium text-gray-700 mb-1">Set New Password</label>
            <input type="password" name="new_password" class="input-field" required>
          </div>
          
          <button type="submit" class="btn btn-primary">
            <i class="fas fa-save mr-2"></i> Update Password
          </button>
        </form>
      </div>
      
      <!-- Admin List Section -->
      <div class="admin-list-container">
        <h3 class="admin-list-header">
          <i class="fas fa-users text-blue-500 mr-2"></i>Admin List
        </h3>
        
        <?php if (!empty($adminList)): ?>
          <table class="admin-list">
            <thead>
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Username</th>
                <th>Password (MD5)</th>
                <th>Owner</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($adminList as $admin): ?>
                <tr>
                  <td class="admin-id"><?= htmlspecialchars($admin['unohs']) ?></td>
                  <td class="admin-name"><?= htmlspecialchars($admin['hesaru']) ?></td>
                  <td class="admin-username"><?= htmlspecialchars($admin['nirvahaka_hesaru']) ?></td>
                  <td>
                    <div class="password-container">
                      <span class="password-display" data-password="<?= htmlspecialchars($admin['pwd']) ?>" style="display: none;"><?= htmlspecialchars($admin['pwd']) ?></span>
                      <span class="password-display">••••••••</span>
                      <button class="password-toggle" onclick="togglePassword(this)">
                        <i class="fas fa-eye"></i>
                      </button>
                      <button class="copy-password" onclick="copyPassword(this)" title="Copy password">
                        <i class="fas fa-copy"></i>
                      </button>
                    </div>
                  </td>
                  <td>
                    <span class="owner-badge <?= $admin['owner'] == 1 ? 'owner-yes' : 'owner-no' ?>">
                      <?= $admin['owner'] == 1 ? 'Owner' : 'Non-Owner' ?>
                    </span>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        <?php else: ?>
          <p class="text-gray-500">No admins found</p>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <div id="toast-container"></div>

  <script>
    // Toggle sidebar on mobile
    document.getElementById('sidebarToggle').addEventListener('click', function(e) {
      e.preventDefault();
      document.querySelector('.sidebar').classList.toggle('show');
    });
    
    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', function(e) {
      const sidebar = document.querySelector('.sidebar');
      const sidebarToggle = document.getElementById('sidebarToggle');
      
      if (window.innerWidth <= 768) {
        if (!sidebar.contains(e.target) && !sidebarToggle.contains(e.target)) {
          sidebar.classList.remove('show');
        }
      }
    });
    
    // Toggle dropdown menu
    document.getElementById('settingsDropdown').addEventListener('click', function(e) {
      e.preventDefault();
      document.getElementById('settingsMenu').classList.toggle('show');
    });
    
    // Close dropdown when clicking outside
    document.addEventListener('click', function(e) {
      if (!e.target.closest('.nav-item.dropdown')) {
        document.getElementById('settingsMenu').classList.remove('show');
      }
    });
    
    // Toggle submenus in sidebar
    document.querySelectorAll('.sidebar-menu .has-submenu > a').forEach(item => {
      item.addEventListener('click', function(e) {
        e.preventDefault();
        const parent = this.parentElement;
        const submenu = this.nextElementSibling;
        
        document.querySelectorAll('.sidebar-menu .submenu').forEach(menu => {
          if (menu !== submenu) {
            menu.classList.remove('active');
            menu.previousElementSibling.classList.remove('active');
          }
        });
        
        parent.classList.toggle('active');
        submenu.classList.toggle('active');
      });
    });
    
    // Toggle password visibility
    function togglePassword(button) {
      const container = button.closest('.password-container');
      const hiddenPassword = container.querySelector('[data-password]');
      const dots = container.querySelector('.password-display:not([data-password])');
      
      if (hiddenPassword.style.display === 'none') {
        hiddenPassword.style.display = 'inline';
        dots.style.display = 'none';
        button.innerHTML = '<i class="fas fa-eye-slash"></i>';
      } else {
        hiddenPassword.style.display = 'none';
        dots.style.display = 'inline';
        button.innerHTML = '<i class="fas fa-eye"></i>';
      }
    }
    
    // Copy password to clipboard
    function copyPassword(button) {
      const container = button.closest('.password-container');
      const password = container.querySelector('[data-password]').textContent;
      
      navigator.clipboard.writeText(password).then(() => {
        showToast('Password copied to clipboard', 'success');
      }).catch(err => {
        showToast('Failed to copy password', 'error');
      });
    }
    
    // Show toast notification
    function showToast(message, type) {
      const toastContainer = document.getElementById('toast-container');
      const toast = document.createElement('div');
      toast.className = `toast toast-${type}`;
      toast.innerHTML = `
        <span>${message}</span>
        <button class="toast-close">&times;</button>
      `;
      toastContainer.appendChild(toast);
      
      // Add click handler for close button
      toast.querySelector('.toast-close').addEventListener('click', function() {
        toast.remove();
      });
      
      setTimeout(() => {
        toast.remove();
      }, 3000);
    }
    
    <?php if (isset($_SESSION['toast'])): ?>
      document.addEventListener('DOMContentLoaded', function() {
        showToast('<?php echo $_SESSION['toast']['message']; ?>', '<?php echo $_SESSION['toast']['type']; ?>');
      });
      <?php unset($_SESSION['toast']); ?>
    <?php endif; ?>
  </script>
</body>
</html>