<?php
session_start();
if (!isset($_SESSION['unohs']) || $_SESSION['unohs'] == null) {
    header("location:index.php?msg=unauthorized");
    exit();
}

date_default_timezone_set("Asia/Kolkata");
include("conn.php");

// Pagination settings
$records_per_page = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start_from = ($page - 1) * $records_per_page;

// Get total number of banned users
$total_query = "SELECT COUNT(*) as total FROM shonu_subjects WHERE status = 0";
$total_result = mysqli_query($conn, $total_query);
$total_row = mysqli_fetch_assoc($total_result);
$total_records = $total_row['total'];
$total_pages = ceil($total_records / $records_per_page);

// Get paginated banned users list (without ban reason from database)
$query = "SELECT id, codechorkamukala FROM shonu_subjects WHERE status = 0 LIMIT $start_from, $records_per_page";
$result = mysqli_query($conn, $query);
$bannedUsers = [];

if ($result && mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $bannedUsers[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
  <title>Banned Users List</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="css/common.css" rel="stylesheet">
  <style>
    :root {
      --primary: #4f46e5;
      --primary-dark: #4338ca;
      --danger: #dc2626;
      --success: #16a34a;
      --dark: #1e293b;
      --light: #f8fafc;
    }
    
    body {
      font-family: 'Inter', sans-serif;
      background-color: #f1f5f9;
      margin: 0;
      padding: 0;
    }
    
    .main-container {
      padding: 0px;
    }
    
    .card {
      background: white;
      border-radius: 12px;
      box-shadow: 0 4px 6px rgba(0,0,0,0.05);
      padding: 10px;
      margin-bottom: 20px;
      height: 100vh;
    }
    
    .card-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 20px;
      padding-bottom: 15px;
      border-bottom: 1px solid #e2e8f0;
    }
    
    .card-title {
      font-size: 20px;
      font-weight: 600;
      color: #1e293b;
      display: flex;
      align-items: center;
    }
    
    .card-title i {
      margin-right: 10px;
      color: var(--danger);
    }
    
    .badge {
      display: inline-block;
      padding: 6px 10px;
      border-radius: 20px;
      font-size: 12px;
      font-weight: 600;
    }
    
    .badge-danger {
      background-color: #fee2e2;
      color: #b91c1c;
    }
    
    /* Table Styles */
    .table-container {
      overflow-x: auto;
      border-radius: 8px;
      border: 1px solid #e2e8f0;
      max-height: calc(100vh - 200px);
    }
    
    table {
      width: 100%;
      border-collapse: collapse;
      min-width: 350px;
    }
    
    th, td {
      padding: 12px 15px;
      text-align: left;
      border-bottom: 1px solid #e2e8f0;
    }
    
    th {
      background-color: #f8fafc;
      font-weight: 600;
      color: #64748b;
      text-transform: uppercase;
      font-size: 12px;
      letter-spacing: 0.5px;
      position: sticky;
      top: 0;
    }
    
    tr:hover {
      background-color: #f8fafc;
    }
    
    .status-badge {
      padding: 6px 12px;
      border-radius: 20px;
      font-size: 12px;
      font-weight: 600;
      display: inline-block;
    }
    
    /* Pagination Styles */
    .pagination {
      display: flex;
      justify-content: center;
      margin-top: 20px;
      gap: 8px;
      flex-wrap: wrap;
    }
    
    .pagination a, .pagination span {
      padding: 8px 12px;
      border: 1px solid #e2e8f0;
      border-radius: 6px;
      color: #4f46e5;
      text-decoration: none;
      font-size: 14px;
      transition: all 0.3s;
    }
    
    .pagination a:hover {
      background-color: #f1f5f9;
    }
    
    .pagination .active {
      background-color: #4f46e5;
      color: white;
      border-color: #4f46e5;
    }
    
    /* Empty State */
    .empty-state {
      text-align: center;
      padding: 40px 20px;
      color: #64748b;
    }
    
    .empty-state i {
      font-size: 40px;
      color: #cbd5e1;
      margin-bottom: 15px;
    }
    
    .empty-state p {
      font-size: 16px;
      margin: 0;
    }
    
    @media (max-width: 768px) {
      .main-container {
        padding: 15px;
      }
      
      .table-container {
        max-height: calc(100vh - 180px);
      }
      
      th, td {
        padding: 10px 8px;
        font-size: 14px;
      }
      
      .card-header {
        flex-direction: column;
        align-items: flex-start;
        gap: 10px;
      }
    }
  </style>
</head>
<body>
  
  
  <div class="main-container"> 
   
      
    <div class="card">
      <div class="card-header">
        <div class="card-title">
          <i class="fas fa-user-slash"></i>
          Banned Users List
        </div>
        <span class="badge badge-danger"><?php echo $total_records; ?> Banned Users</span>
      </div>
      
      <?php if (!empty($bannedUsers)): ?>
        <div class="table-container">
          <table id="bannedUsersTable">
            <thead>
              <tr>
                <th>User ID</th>
                <th>Name</th>
                <th>Ban Reason</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($bannedUsers as $user): ?>
                <tr>
                  <td><?php echo htmlspecialchars($user['id']); ?></td>
                  <td><?php echo htmlspecialchars($user['codechorkamukala']); ?></td>
                  <td>Violation of Terms of Service</td> <!-- Static ban reason -->
                  <td><span class="status-badge badge-danger">Banned</span></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
        
        <!-- Pagination -->
        <div class="pagination">
          <?php if ($page > 1): ?>
            <a href="?page=<?php echo $page - 1; ?>">&laquo; Previous</a>
          <?php endif; ?>
          
          <?php for ($i = 1; $i <= $total_pages; $i++): ?>
            <a href="?page=<?php echo $i; ?>" <?php echo ($i == $page) ? 'class="active"' : ''; ?>>
              <?php echo $i; ?>
            </a>
          <?php endfor; ?>
          
          <?php if ($page < $total_pages): ?>
            <a href="?page=<?php echo $page + 1; ?>">Next &raquo;</a>
          <?php endif; ?>
        </div>
      <?php else: ?>
        <div class="empty-state">
          <i class="fas fa-user-slash"></i>
          <p>No banned users found</p>
        </div>
      <?php endif; ?>
    </div>
  </div>

  <script>
    // Search function
    function searchTable() {
      const input = document.getElementById("searchInput");
      const filter = input.value.toUpperCase();
      const table = document.getElementById("bannedUsersTable");
      const tr = table.getElementsByTagName("tr");
      
      for (let i = 1; i < tr.length; i++) {
        const tdId = tr[i].getElementsByTagName("td")[0];
        const tdName = tr[i].getElementsByTagName("td")[1];
        if (tdId || tdName) {
          const txtValueId = tdId.textContent || tdId.innerText;
          const txtValueName = tdName.textContent || tdName.innerText;
          if (txtValueId.toUpperCase().indexOf(filter) > -1 || 
              txtValueName.toUpperCase().indexOf(filter) > -1) {
            tr[i].style.display = "";
          } else {
            tr[i].style.display = "none";
          }
        }
      }
    }
  </script>
</body>
</html>