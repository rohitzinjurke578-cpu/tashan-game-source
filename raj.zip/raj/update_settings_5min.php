<?php
session_start();
include ("conn.php");

if($_SESSION['unohs'] == null){
    die(json_encode(['status' => 'error', 'message' => 'Unauthorized']));
}

$response = ['status' => 'error', 'message' => 'Invalid action'];

if(isset($_POST['action'])) {
    switch($_POST['action']) {
        case 'update_mode':
            if(isset($_POST['wingo_5min_mode'])) {
                $mode = $_POST['wingo_5min_mode'];
                if(in_array($mode, ['auto', 'manual', 'api'])) {
                    $settings_file = 'settings/5min_mode.json';
                    $settings = file_exists($settings_file) ? json_decode(file_get_contents($settings_file), true) : [];
                    $settings['wingo_5min_mode'] = $mode;
                    
                    if(file_put_contents($settings_file, json_encode($settings))) {
                        $response = ['status' => 'success', 'current_mode' => $mode];
                    } else {
                        $response = ['status' => 'error', 'message' => 'Failed to save settings'];
                    }
                }
            }
            break;
            
        case 'set_prediction':
            if(isset($_POST['prediction_number'])) {
                $number = (int)$_POST['prediction_number'];
                if($number >= 0 && $number <= 9) {
                    $data = ['number' => $number, 'prediction' => 'set'];
                    if(file_put_contents('settings/5min.json', json_encode($data))) {
                        $response = ['status' => 'success'];
                    } else {
                        $response = ['status' => 'error', 'message' => 'Failed to save prediction'];
                    }
                }
            }
            break;
            
        case 'unset_prediction':
            $data = ['number' => null, 'prediction' => null];
            if(file_put_contents('settings/5min.json', json_encode($data))) {
                $response = ['status' => 'success'];
            } else {
                $response = ['status' => 'error', 'message' => 'Failed to unset prediction'];
            }
            break;
    }
}

echo json_encode($response);
?>