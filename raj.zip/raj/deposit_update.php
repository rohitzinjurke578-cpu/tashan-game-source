<?php 
session_start(); 
if($_SESSION['unohs'] == null){ 
    header("location:index.php?msg=unauthorized"); 
    exit();
} 
include("conn.php"); 

// Get counts for dashboard
$pending_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM `thevani` WHERE `sthiti` = '0'"))['count'];
$approved_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM `thevani` WHERE `sthiti` = '1'"))['count'];
$rejected_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM `thevani` WHERE `sthiti` = '2'"))['count'];

// Generate unique token for form
if (!isset($_SESSION['form_token'])) {
    $_SESSION['form_token'] = bin2hex(random_bytes(32));
}

// Handle deposit actions
if(isset($_POST['action']) && isset($_POST['token']) && $_POST['token'] === $_SESSION['form_token']) {
    $sid = mysqli_real_escape_string($conn, $_POST['sid']);
    $uid = mysqli_real_escape_string($conn, $_POST['uid']);
    $amount = mysqli_real_escape_string($conn, $_POST['amount']);
    $ref_num = mysqli_real_escape_string($conn, $_POST['ref_num']);
    $date = mysqli_real_escape_string($conn, $_POST['date']);
    
    if($_POST['action'] == 'approve') {
        // Find referer
        $self = mysqli_query($conn, "SELECT code FROM shonu_subjects WHERE id = '".$uid."'");
        $selfArray = mysqli_fetch_array($self);
        $ref = mysqli_query($conn, "SELECT id FROM shonu_subjects WHERE owncode = '".$selfArray['code']."'");
        $refArray = mysqli_fetch_array($ref);
        $refid = $refArray['id'];
        
        // Set referral bonus based on amount
        if($amount >= '500' && $amount < '1000'){
            $refbn = 0;
        }
        else if($amount >= '1000' && $amount < '3000'){
            $refbn = 0;
        }
        else if($amount >= '3000' && $amount < '4000'){
            $refbn = 0;
        }
        else if($amount >= '4000' && $amount < '5000'){
            $refbn = 0;
        }
        else if($amount >= '5000' && $amount < '10000'){
            $refbn = 0;
        }
        else if($amount >= '10000' && $amount < '50000'){
            $refbn = 0;
        }
        else if($amount >= '50000' && $amount < '100000'){
            $refbn = 0;
        }
        else if($amount >= '100000'){
            $refbn = 0;
        }
        else{
            $refbn = 0;
        }
        
        $refbnthr = 0;
        $refwal = mysqli_query($conn, "SELECT motta FROM shonu_kaichila WHERE balakedara = '".$refid."'");
        $refwalA = mysqli_fetch_array($refwal);
        $refwalB = $refwalA['motta'];
        $refwalF = intval($refwalB) + intval($refbn);
        $refwalFthr = intval($refwalB) + intval($refbnthr);
        
        // Check if this is first recharge
        $up2 = mysqli_query($conn, "SELECT shonu FROM thevani WHERE balakedara = '".$uid."' && sthiti = '1'");
        $up2row = mysqli_num_rows($up2);
        
        // Calculate bonus
        $rechqueryaa = mysqli_query($conn, "SELECT rechargebonus FROM parametredepaiement");
        $rechqueryarrayaa = mysqli_fetch_array($rechqueryaa);
        $rechargebonus = $rechqueryarrayaa['rechargebonus'];
        $bn = '0';
        if($up2row == 0){
            //$bn = ($rechargebonus*$amount)/100;
            $bn = '0';
        } else {
            $bn = '0';
        }
        
        // Get current wallet balance
        $up = mysqli_query($conn, "SELECT motta FROM shonu_kaichila WHERE balakedara = '".$uid."'");
        $rup = mysqli_fetch_array($up);
        
        // Calculate new balance
        $addmoney = intval($rup['motta']) + intval($amount) + intval($bn);
        
        // Update wallet
        $wal = mysqli_query($conn, "UPDATE shonu_kaichila SET motta = '".$addmoney."' WHERE balakedara = '".$uid."'");
        
        if($wal){
            $succes = mysqli_query($conn, "UPDATE thevani SET sthiti = '1' WHERE balakedara = '".$uid."' && motta = '$amount' && dinankavannuracisi = '".$date."' && shonu = '".$sid."'");
            
            // Update referer's wallet if first recharge
            if($up2row == 0){
                $refwll = mysqli_query($conn, "UPDATE shonu_kaichila SET motta = '".$refwalF."' WHERE balakedara = '".$refid."'");
            }
            else if($up2row == 2){
                $refwll = mysqli_query($conn, "UPDATE shonu_kaichila SET motta = '".$refwalFthr."' WHERE balakedara = '".$refid."'");
            }
            
            $_SESSION['toast'] = [
                'type' => 'success',
                'message' => 'Deposit approved successfully'
            ];
        } else {
            $_SESSION['toast'] = [
                'type' => 'error',
                'message' => 'Error approving deposit'
            ];
        }
    } elseif($_POST['action'] == 'reject') {
        $reject = mysqli_query($conn, "UPDATE thevani SET sthiti = '2' WHERE balakedara = '".$uid."' && motta = '$amount' && dinankavannuracisi = '".$date."' && shonu = '".$sid."'");
        
        if($reject){
            $_SESSION['toast'] = [
                'type' => 'success',
                'message' => 'Deposit rejected successfully'
            ];
        } else {
            $_SESSION['toast'] = [
                'type' => 'error',
                'message' => 'Error rejecting deposit'
            ];
        }
    }
    
    header("Location: ".$_SERVER['PHP_SELF']);
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Deposit Management</title>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="css/common.css" rel="stylesheet">
  <script src="https://cdn.tailwindcss.com"></script>
  <!-- DataTables CSS -->
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css">
  <style>
    :root {
     /* --primary: #4f46e5;
      --primary-dark: #4338ca;
      --secondary: #10b981;*/
      --danger: #ef4444;
      --warning: #f59e0b;
      --info: #3b82f6;
      --dark: #1f2937;
      --light: #f3f4f6;
    }
    body{
    min-height: 100vh; 
    }
    /* Main Content Styles */
    .main-content {
      flex: 1;
      margin-left: 0;
      transition: var(--transition);
      background-color: var(--white);
      min-height: 100vh;
    }
    
    .content-header 
    { display: none;
      padding: 0.75rem 1.25rem;
      background: linear-gradient(to right, #ffffff, #f1f3f5);
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.06);
      border-radius: 0.375rem;
      border: 1px solid #e0e0e0;
      margin: 1rem;
      transition: all 0.3s ease;
    }

    .content-header h1 {
      font-size: 1rem;
      margin: 0;
      font-weight: 600;
      color: #343a40;
    }

    .breadcrumb {
      font-size: 0.75rem;
      color: #6c757d;
      margin-bottom: 0;
    }

    .breadcrumb a {
      color: #4f46e5;
      font-weight: 500;
      text-decoration: none;
      transition: color 0.2s ease-in-out;
    }

    .breadcrumb a:hover {
      color: #3730a3;
    }
    
    /* Form Styles */
    .form-container {
      background: white;
      padding: 1.5rem;
      border-radius: 0.5rem;
      box-shadow: 0 1px 3px rgba(0,0,0,0.1);
      margin-bottom: 1.5rem;
      border: 1px solid rgba(52, 152, 219, 0.1);
      max-width: 340px;
      margin-left: auto;
      margin-right: auto;
      overflow-x: auto;
    }
    
    .form-container h3 {
      color: var(--dark);
      margin-bottom: 1.5rem;
      font-weight: 600;
      display: flex;
      align-items: center;
      gap: 2px;
      font-size: 1.1rem;
    }
    
    /* Button Styles */
    .btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: 0.5rem 1rem;
      border-radius: 0.375rem;
      font-weight: 500;
      font-size: 0.9rem;
      line-height: 1.5;
      cursor: pointer;
      transition: all 0.3s ease;
      border: none;
    }
    
    .btn-primary {
      background-color: var(--primary);
      color: white;
    }
    
    .btn-primary:hover {
      background-color: var(--primary-dark);
      transform: translateY(-1px);
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }
    
    .btn-sm {
      padding: 0.5rem;
      width: 36px;
      height: 36px;
    }
    
    .btn-success {
      background-color: var(--secondary);
      color: white;
    }
    
    .btn-success:hover {
      background-color: #0d9f6e;
      transform: translateY(-1px);
    }
    
    .btn-danger {
      background-color: var(--danger);
      color: white;
    }
    
    .btn-danger:hover {
      background-color: #dc2626;
      transform: translateY(-1px);
    }
    
    /* Status badges */
    .status-badge {
      display: inline-flex;
      align-items: center;
      padding: 0.25rem 0.75rem;
      border-radius: 9999px;
      font-size: 0.75rem;
      font-weight: 600;
    }
    
    .status-pending {
      background-color: rgba(245, 158, 11, 0.1);
      color: #f59e0b;
    }
    
    .status-approved {
      background-color: rgba(16, 185, 129, 0.1);
      color: #10b981;
    }
    
    .status-rejected {
      background-color: rgba(239, 68, 68, 0.1);
      color: #ef4444;
    }
    
    /* Count Cards */
    .count-card {
      background: white;
      border-radius: 0.5rem;
      padding: 1rem;
      box-shadow: 0 1px 3px rgba(0,0,0,0.1);
      transition: all 0.3s;
      height: 90px;
      display: flex;
      align-items: center;
      margin: 0 0.5rem;
    }
    
    .count-card:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }
    
    .count-icon {
      width: 50px;
      height: 50px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.25rem;
      color: white;
      margin-right: 1rem;
    }
    
    .count-text {
      flex: 1;
    }
    
    .count-number {
      font-size: 1.25rem;
      font-weight: 600;
      margin-bottom: 0.25rem;
    }
    
    .count-title {
      color: #64748b;
      font-size: 0.875rem;
    }
    
    /* Table Styles */
    .table-container {
      width: 100%;
      max-width: 340px;
      overflow-x: auto;
      -webkit-overflow-scrolling: touch;
      margin: 0 auto;
    }
    
    .dataTables_wrapper {
      padding: 0;
      width: 100%;
      max-width: 340px;
      margin: 0 auto;
    }
    
    .dataTables_wrapper .dataTables_filter {
      margin-bottom: 1rem;
    }
    
    .dataTables_wrapper .dataTables_filter input {
      border: 1px solid #d1d5db;
      border-radius: 0.375rem;
      padding: 0.375rem 0.75rem;
      background-color: white;
      margin-left: 0.5rem;
    }
    
    .dataTables_wrapper .dataTables_length select {
      border: 1px solid #d1d5db;
      border-radius: 0.375rem;
      padding: 0.375rem 0.75rem;
      background-color: white;
    }
    
    .dataTables_wrapper .dataTables_paginate {
      display: flex;
      justify-content: center;
      align-items: center;
      flex-wrap: wrap;
      gap: 0.5rem;
      margin-top: 1rem;
    }
    
    .dataTables_wrapper .dataTables_paginate .paginate_button {
      border: 1px solid #d1d5db;
      padding: 0.5rem 0.75rem;
      border-radius: 0.375rem;
      color: var(--dark);
      transition: all 0.3s ease;
      margin: 0;
      font-size: 0.8rem;
      min-width: 30px;
      height: 30px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    .dataTables_wrapper .dataTables_paginate .paginate_button.current,
    .dataTables_wrapper .dataTables_paginate .paginate_button.current:hover {
      background: var(--primary);
      color: white !important;
      border: 1px solid var(--primary);
    }
    
    .dataTables_wrapper .dataTables_paginate .paginate_button:hover {
      background: #e5e7eb;
      border: 1px solid #d1d5db;
      color: var(--dark) !important;
    }
    
    /* Table row styles */
    #pendingDeposits tbody tr,
    #allDeposits tbody tr {
      height: 60px;
    }
    
    #pendingDeposits tbody td,
    #allDeposits tbody td {
      padding: 0.75rem 1rem;
      vertical-align: middle;
    }
    
    /* Toast Styles */
    #toast-container {
      position: fixed;
      bottom: 20px;
      right: 20px;
      z-index: 9999;
    }
    
    .toast {
      min-width: 250px;
      padding: 12px 16px;
      margin-bottom: 10px;
      border-radius: 8px;
      color: white;
      font-size: 14px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      animation: slideIn 0.3s, fadeOut 0.5s 2.5s forwards;
      transform: translateX(0);
    }
    
    .toast-success {
      background-color: var(--secondary);
    }
    
    .toast-error {
      background-color: var(--danger);
    }
    
    .toast-close {
      background: none;
      border: none;
      color: white;
      cursor: pointer;
      margin-left: 15px;
      font-size: 1rem;
    }
    
    @keyframes slideIn {
      from { transform: translateX(100%); opacity: 0; }
      to { transform: translateX(0); opacity: 1; }
    }
    
    @keyframes fadeOut {
      from { opacity: 1; }
      to { opacity: 0; }
    }
    
    /* Navbar Styles */
    .navbar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0.75rem 1.5rem;
      background-color: white;
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
      position: sticky;
      top: 0;
      z-index: 100;
    }
    
    .navbar-brand {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      color: var(--primary);
      font-weight: 500;
      text-decoration: none;
    }
    
    .navbar-nav {
      display: flex;
      list-style: none;
      margin: 0;
      padding: 0;
      gap: 1rem;
    }
    
    .nav-item {
      position: relative;
    }
    
    .nav-link {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 36px;
      height: 36px;
      border-radius: 50%;
      color: var(--primary);
      transition: all 0.3s ease;
    }
    
    .nav-link:hover {
      background-color: rgba(79, 70, 229, 0.1);
    }
    
    .dropdown-menu {
      position: absolute;
      right: 0;
      top: 100%;
      background-color: white;
      border-radius: 0.5rem;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      padding: 0.5rem 0;
      min-width: 160px;
      display: none;
    }
    
    .dropdown-menu.show {
      display: block;
    }
    
    .dropdown-item {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      padding: 0.5rem 1rem;
      color: var(--dark);
      text-decoration: none;
      transition: all 0.3s ease;
    }
    
    .dropdown-item:hover {
      background-color: #f1f3f5;
    }
    
    /* Sidebar Logo Styles */
    .sidebar-logo {
      border-bottom: 2px solid var(--primary);
    }
    
    /* Responsive Styles */
    @media (min-width: 768px) {
      .main-content {
        margin-left: 220px;
        overflow-X: scroll;
      }
      
      .form-container {
        max-width: 100%; 
        overflow-X: scroll;
      }
      
      .table-container {
        max-width: 100%;
      }
      
      .dataTables_wrapper {
        max-width: 100%;
      }
    }
    
    @media (max-width: 767px) {
      .count-card {
        margin: 0.5rem;
      }
      
      .dataTables_wrapper .dataTables_paginate .paginate_button {
        padding: 0.3rem 0.5rem;
        min-width: 25px;
        height: 25px;
        font-size: 0.7rem;
      }
    }
  </style>
</head>

<body>
  <div class="wrapper">
    <?php include('compass.php'); ?>
  
    <!-- Main Content -->
    <div class="main-content">
      <!-- Navbar -->
      <nav class="navbar">
        <a href="#" class="navbar-brand" id="sidebarToggle">
          <i class="fas fa-bars text-blue-600"></i>
          <span class="">Menu</span>
        </a>
        
        <ul class="navbar-nav">
          <li class="nav-item dropdown">
            <a href="#" class="nav-link" id="settingsDropdown">
              <i class="fas fa-user-cog text-blue-600"></i>
            </a>
            <div class="dropdown-menu" id="settingsMenu">
              <a href="logout.php" class="dropdown-item">
                <i class="fas fa-sign-out-alt text-blue-600 mr-2"></i> Logout
              </a>
            </div>
          </li>
        </ul>
      </nav>
      <br>
      
      <!-- Content Area -->
      <div class="content-area">
        <!-- Content Header -->
        <div class="content-header">
          <div class="breadcrumb">
            <a href="dashboard.php">Home</a> / Deposit Management
          </div>
          <h1 class="text-xl font-bold text-gray-800">Deposit Management</h1>
          <p class="text-gray-500 text-sm">
            <?php echo date("l, F d, Y"); ?>
          </p>
        </div>
        
        <!-- Main Content Area -->
        <div class="md:p-4">
          <!-- Count Cards -->
          <div class="flex flex-col md:flex-row gap-3 mb-6 px-2">
            <div class="count-card">
              <div class="count-icon bg-yellow-500">
                <i class="fas fa-clock text-white"></i>
              </div>
              <div class="count-text">
                <div class="count-number"><?php echo $pending_count; ?></div>
                <div class="count-title">Pending Deposits</div>
              </div>
            </div>
            
            <div class="count-card">
              <div class="count-icon bg-green-500">
                <i class="fas fa-check-circle text-white"></i>
              </div>
              <div class="count-text">
                <div class="count-number"><?php echo $approved_count; ?></div>
                <div class="count-title">Approved Deposits</div>
              </div>
            </div>
            
            <div class="count-card">
              <div class="count-icon bg-red-500">
                <i class="fas fa-times-circle text-white"></i>
              </div>
              <div class="count-text">
                <div class="count-number"><?php echo $rejected_count; ?></div>
                <div class="count-title">Rejected Deposits</div>
              </div>
            </div>
          </div>
          
          <!-- Pending Deposits -->
          <div class="form-container animate-fadeInUp">
            <h3><i class="fas fa-clock text-yellow-500 mr-2"></i>Pending Deposit Requests</h3>
            
            <div class="table-container">
              <table id="pendingDeposits" class="w-full">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>User ID</th>
                    <th>Mobile</th>
                    <th>Reference</th>
                    <th>Amount</th>
                    <th>Order ID</th>
                    <th>Pay Method</th>
                    <th>To UPI</th>
                    <th>Date</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $sqq = mysqli_query($conn, "SELECT * FROM `thevani` WHERE `sthiti` = '0' ORDER BY `shonu` DESC");
                  $i = 0;
                  while ($row = mysqli_fetch_array($sqq)) {
                      $i++;
                      echo '
                      <tr>
                        <td>'.$i.'</td>
                        <td>'.$row['balakedara'].'</td>
                        <td>'.$row['duravani'].'</td>
                        <td>'.$row['ullekha'].'</td>
                        <td>'.$row['motta'].'</td>
                        <td>'.$row['dharavahi'].'</td>
                        <td>'.$row['mula'].'</td>
                        <td>'.$row['ekikrtapavati'].'</td>
                        <td>'.$row['dinankavannuracisi'].'</td>
                        <td class="whitespace-nowrap">
                          <form class="inline-block" method="post">
                            <input type="hidden" name="token" value="'.$_SESSION['form_token'].'">
                            <input type="hidden" name="sid" value="'.$row['shonu'].'">
                            <input type="hidden" name="uid" value="'.$row['balakedara'].'">
                            <input type="hidden" name="amount" value="'.$row['motta'].'">
                            <input type="hidden" name="ref_num" value="'.$row['ullekha'].'">
                            <input type="hidden" name="date" value="'.$row['dinankavannuracisi'].'">
                            <input type="hidden" name="action" value="approve">
                            <button type="submit" class="btn btn-success btn-sm" title="Approve">
                              <i class="fas fa-check"></i>
                            </button>
                          </form>
                          <form class="inline-block ml-2" method="post">
                            <input type="hidden" name="token" value="'.$_SESSION['form_token'].'">
                            <input type="hidden" name="sid" value="'.$row['shonu'].'">
                            <input type="hidden" name="uid" value="'.$row['balakedara'].'">
                            <input type="hidden" name="amount" value="'.$row['motta'].'">
                            <input type="hidden" name="ref_num" value="'.$row['ullekha'].'">
                            <input type="hidden" name="date" value="'.$row['dinankavannuracisi'].'">
                            <input type="hidden" name="action" value="reject">
                            <button type="submit" class="btn btn-danger btn-sm" title="Reject">
                              <i class="fas fa-times"></i>
                            </button>
                          </form>
                        </td>
                      </tr>
                      ';
                  }
                  ?>
                </tbody>
              </table>
            </div>
          </div>
          
          <!-- All Deposit Records -->
          <div class="form-container animate-fadeInUp">
            <h3><i class="fas fa-history text-blue-500 mr-2"></i>All Deposit Records</h3>
            
            <div class="table-container">
              <table id="allDeposits" class="w-full">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>User ID</th>
                    <th>Mobile</th>
                    <th>Reference</th>
                    <th>Amount</th>
                    <th>Order ID</th>
                    <th>Pay Method</th>
                    <th>To UPI</th>
                    <th>Date</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $sqq = mysqli_query($conn, "SELECT * FROM `thevani` WHERE `sthiti` != '0' ORDER BY `shonu` DESC");
                  $i = 0;
                  while ($row = mysqli_fetch_array($sqq)) {
                      $i++;
                      $status = '';
                      if($row['sthiti'] == '1') {
                          $status = '<span class="status-badge status-approved">Approved</span>';
                      } else {
                          $status = '<span class="status-badge status-rejected">Rejected</span>';
                      }
                      
                      echo '
                      <tr>
                        <td>'.$i.'</td>
                        <td>'.$row['balakedara'].'</td>
                        <td>'.$row['duravani'].'</td>
                        <td>'.$row['ullekha'].'</td>
                        <td>'.$row['motta'].'</td>
                        <td>'.$row['dharavahi'].'</td>
                        <td>'.$row['mula'].'</td>
                        <td>'.$row['ekikrtapavati'].'</td>
                        <td>'.$row['dinankavannuracisi'].'</td>
                        <td>'.$status.'</td>
                      </tr>
                      ';
                  }
                  ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
        
        <!-- Footer -->
       <!-- <footer class="footer w-full bg-gradient-to-r from-slate-50 to-slate-100 border-t border-slate-200 shadow-sm py-4 px-6 fade-in">
          <div class="max-w-screen-xl mx-auto text-center">
            <span class="text-sm text-slate-500">
              Powered by <strong class="text-blue-900 font-semibold">RAJVEER CODER Admin</strong>
            </span>
          </div>
        </footer>-->
      </div>
    </div>
  </div>

  <!-- Toast Container -->
  <div id="toast-container"></div>

  <!-- JavaScript -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
  <script>
    // Toggle sidebar on mobile
    document.getElementById('sidebarToggle').addEventListener('click', function(e) {
      e.preventDefault();
      document.querySelector('.sidebar').classList.toggle('show');
    });
    
    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', function(e) {
      const sidebar = document.querySelector('.sidebar');
      const sidebarToggle = document.getElementById('sidebarToggle');
      
      if (window.innerWidth <= 768) {
        if (!sidebar.contains(e.target) && !sidebarToggle.contains(e.target)) {
          sidebar.classList.remove('show');
        }
      }
    });
    
    // Toggle dropdown menu
    document.getElementById('settingsDropdown').addEventListener('click', function(e) {
      e.preventDefault();
      document.getElementById('settingsMenu').classList.toggle('show');
    });
    
    // Close dropdown when clicking outside
    document.addEventListener('click', function(e) {
      if (!e.target.closest('.nav-item.dropdown')) {
        document.getElementById('settingsMenu').classList.remove('show');
      }
    });
    
    // Toggle submenus in sidebar
    document.querySelectorAll('.sidebar-menu .has-submenu > a').forEach(item => {
      item.addEventListener('click', function(e) {
        e.preventDefault();
        const parent = this.parentElement;
        const submenu = this.nextElementSibling;
        
        // Close all other submenus
        document.querySelectorAll('.sidebar-menu .submenu').forEach(menu => {
          if (menu !== submenu) {
            menu.classList.remove('active');
            menu.previousElementSibling.classList.remove('active');
          }
        });
        
        // Toggle current submenu
        parent.classList.toggle('active');
        submenu.classList.toggle('active');
      });
    });
    
    // Initialize DataTables with responsive settings
    $(document).ready(function() {
      $('#pendingDeposits').DataTable({
        responsive: true,
        searching: true,
        ordering: true,
        language: {
          search: "_INPUT_",
          searchPlaceholder: "Search...",
        },
        dom: '<"top"f>rt<"bottom"lip><"clear">',
        pageLength: 10,
        scrollX: true,
        autoWidth: false,
        columnDefs: [
          { width: '30px', targets: 0 },
          { width: '70px', targets: 1 },
          { width: '80px', targets: 2 },
          { width: '100px', targets: 3 },
          { width: '70px', targets: 4 },
          { width: '100px', targets: 5 },
          { width: '100px', targets: 6 },
          { width: '80px', targets: 7 }
        ]
      });
      
      $('#allDeposits').DataTable({
        responsive: true,
        searching: true,
        ordering: true,
        language: {
          search: "_INPUT_",
          searchPlaceholder: "Search...",
        },
        dom: '<"top"f>rt<"bottom"lip><"clear">',
        pageLength: 10,
        scrollX: true,
        autoWidth: false,
        columnDefs: [
          { width: '30px', targets: 0 },
          { width: '70px', targets: 1 },
          { width: '80px', targets: 2 },
          { width: '100px', targets: 3 },
          { width: '70px', targets: 4 },
          { width: '100px', targets: 5 },
          { width: '100px', targets: 6 },
          { width: '80px', targets: 7 }
        ]
      });
      
      // Show any server-side toast messages
      <?php if (isset($_SESSION['toast'])): ?>
        showToast('<?php echo $_SESSION['toast']['message']; ?>', '<?php echo $_SESSION['toast']['type']; ?>');
        <?php unset($_SESSION['toast']); ?>
      <?php endif; ?>
    });
    
    // Show toast notification
    function showToast(message, type) {
      const toastContainer = document.getElementById('toast-container');
      const toast = document.createElement('div');
      toast.className = `toast toast-${type}`;
      toast.innerHTML = `
        <span>${message}</span>
        <button class="toast-close" onclick="this.parentElement.remove()">&times;</button>
      `;
      toastContainer.appendChild(toast);
      
      // Auto remove after 3 seconds
      setTimeout(() => {
        toast.remove();
      }, 3000);
    }
    
    // Prevent form resubmission on page refresh
    if (window.history.replaceState) {
      window.history.replaceState(null, null, window.location.href);
    }
  </script>
</body>
</html>