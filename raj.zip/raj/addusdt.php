<?php
session_start();
if ($_SESSION['unohs'] == null) {
    header("location:index.php?msg=unauthorized");
}
date_default_timezone_set("Asia/Kolkata");
include("conn.php");

// Generate unique token for form
if (!isset($_SESSION['form_token'])) {
    $_SESSION['form_token'] = bin2hex(random_bytes(32));
}

// Handle USDT address addition
if (isset($_POST['newusdt']) && isset($_POST['form_token']) && $_POST['form_token'] === $_SESSION['form_token']) {
    $usdtAddress = mysqli_real_escape_string($conn, $_POST['newusdt']);
    
    // Validate USDT address format (basic validation)
    if (!preg_match('/^T[A-Za-z1-9]{33}$/', $usdtAddress)) {
        $_SESSION['toast'] = [
            'type' => 'error',
            'message' => 'Invalid USDT address format. Please use a valid TRC20 address'
        ];
    } else {
        // First set all records to inactive (0)
        $deactivateAll = "UPDATE deyyamrici SET sthiti='0'";
        mysqli_query($conn, $deactivateAll);
        
        // Then add new USDT as active
        $sql_q = "INSERT INTO deyyamrici (maulya, sthiti) VALUES ('".$usdtAddress."', '1')";
        $chk = mysqli_query($conn, $sql_q);
        
        if($chk){
            $_SESSION['toast'] = [
                'type' => 'success',
                'message' => 'USDT address added successfully'
            ];
        } else {
            $_SESSION['toast'] = [
                'type' => 'error',
                'message' => 'Failed to add USDT address'
            ];
        }
        
        // Regenerate token after submission
        $_SESSION['form_token'] = bin2hex(random_bytes(32));
        header("Location: ".$_SERVER['PHP_SELF']);
        exit();
    }
}

// Handle USDT address activation
if (isset($_POST['usdtid'])) {
    $a_id = mysqli_real_escape_string($conn, $_POST['usdtid']);
    
    // First set all records to inactive (0)
    $deactivateAll = "UPDATE deyyamrici SET sthiti='0'";
    mysqli_query($conn, $deactivateAll);
    
    // Then activate the selected USDT
    $activate = "UPDATE deyyamrici SET sthiti='1' WHERE maulya='".$a_id."'";
    $exe_ch_s1 = mysqli_query($conn, $activate);
    
    if($exe_ch_s1){
        $_SESSION['toast'] = [
            'type' => 'success',
            'message' => 'Active USDT address updated'
        ];
    } else {
        $_SESSION['toast'] = [
            'type' => 'error',
            'message' => 'Failed to update active USDT address'
        ];
    }
    
    header("Location: ".$_SERVER['PHP_SELF']);
    exit();
}

// Handle USDT address deletion
if (isset($_POST['delete_usdt']) && isset($_POST['delete_token']) && $_POST['delete_token'] === $_SESSION['form_token']) {
    $usdtToDelete = mysqli_real_escape_string($conn, $_POST['delete_usdt']);
    
    $deleteQuery = "DELETE FROM deyyamrici WHERE maulya = '$usdtToDelete'";
    if(mysqli_query($conn, $deleteQuery)) {
        $_SESSION['toast'] = [
            'type' => 'success',
            'message' => 'USDT address deleted successfully'
        ];
    } else {
        $_SESSION['toast'] = [
            'type' => 'error',
            'message' => 'Failed to delete USDT address'
        ];
    }
    
    // Regenerate token after deletion
    $_SESSION['form_token'] = bin2hex(random_bytes(32));
    header("Location: ".$_SERVER['PHP_SELF']);
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>USDT Address Management</title>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href ="css/common.css" rel="stylesheet">
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    /* Main Content Styles */
    .main-content {
      flex: 1;
      margin-left: 0;
      transition: var(--transition);
      background-color: var(--white);
      min-height: 100vh;
    }
    
    .content-header {
      padding: 0.75rem 1.25rem;
      background: linear-gradient(to right, #ffffff, #f1f3f5);
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.06);
      border-radius: 0.375rem;
      border: 1px solid #e0e0e0;
      margin: 1rem;
      transition: all 0.3s ease;
    }

    .content-header h1 {
      font-size: 1rem; /* Smaller title size */
      margin: 0;
      font-weight: 600;
      color: #343a40;
    }

    .breadcrumb {
      font-size: 0.75rem;
      color: #6c757d;
      margin-bottom: 0;
    }

    .breadcrumb a {
      color: #4f46e5;
      font-weight: 500;
      text-decoration: none;
      transition: color 0.2s ease-in-out;
    }

    .breadcrumb a:hover {
      color: #3730a3;
    }
    
    /* Form Styles */
    .form-container {
      background: var(--white);
      padding: 1.5rem;
      border-radius: 0.5rem;
      box-shadow: var(--card-shadow);
      margin-bottom: 1.5rem;
      border: 1px solid rgba(52, 152, 219, 0.1);
    }
    
    .form-container h3 {
      color: var(--dark);
      margin-bottom: 1.5rem;
      font-weight: 600;
      display: flex;
      align-items: center;
      gap: 2px;
      font-size: 1.1rem;
    }
    
    .form-group {
      margin-bottom: 1rem;
    }
    
    .form-group label {
      display: block;
      margin-bottom: 0.5rem;
      font-weight: 500;
      color: var(--dark);
      font-size: 0.9rem;
    }
    
    .form-control {
      width: 100%;
      padding: 0.75rem;
      border: 1px solid var(--light);
      border-radius: 0.375rem;
      font-size: 0.9rem;
      transition: all 0.3s ease;
      height: 45px;
    }
    
    .form-control:focus {
      border-color: var(--primary);
      box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.1);
      outline: none;
    }
    
    /* Button Styles */
    .btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: 0.75rem 1.5rem;
      border-radius: 0.375rem;
      font-weight: 500;
      font-size: 0.9rem;
      line-height: 1.5;
      cursor: pointer;
      transition: all 0.3s ease;
      border: none;
    }
    
    .btn-primary {
      background-color: var(--primary);
      color: white;
    }
    
    .btn-primary:hover {
      background-color: var(--primary-dark);
      transform: translateY(-1px);
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }
    
    .btn-sm {
      padding: 0.5rem;
      width: 36px;
      height: 36px;
    }
    
    .btn-danger {
      background-color: var(--danger);
      color: white;
    }
    
    .btn-danger:hover {
      background-color: #c0392b;
      transform: translateY(-1px);
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }
    
    .btn-secondary {
      background-color: var(--gray);
      color: var(--white);
    }
    
    .btn-secondary:hover {
      background-color: #95a5a6;
      transform: translateY(-1px);
    }
    
    /* USDT List Styles */
    .usdt-list {
      list-style: none;
      padding: 0;
      margin: 0;
    }
    
    .usdt-item {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 1rem;
      background-color: var(--white);
      border-radius: 0.5rem;
      box-shadow: var(--card-shadow);
      margin-bottom: 1rem;
      transition: all 0.3s ease;
      border: 1px solid rgba(52, 152, 219, 0.1);
    }
    
    .usdt-item:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    
    .usdt-details {
      flex: 1;
    }
    
    .usdt-address {
      font-weight: 600;
      color: var(--dark);
      margin-bottom: 0.25rem;
      font-size: 0.95rem;
      word-break: break-all;
    }
    
    .usdt-status {
      display: inline-block;
      padding: 0.25rem 0.5rem;
      border-radius: 1rem;
      font-size: 0.75rem;
      font-weight: 600;
      background-color: rgba(46, 204, 113, 0.1);
      color: var(--secondary);
    }
    
    .usdt-actions {
      display: flex;
      gap: 0.5rem;
      align-items: center;
    }
    
    /* Radio button styles */
    .radio-active {
      accent-color: var(--secondary);
      width: 18px;
      height: 18px;
      cursor: pointer;
    }
    
    /* Toast Styles */
    #toast-container {
      position: fixed;
      bottom: 20px;
      right: 20px;
      z-index: 9999;
    }
    
    .toast {
      min-width: 300px;
      padding: 15px 20px;
      margin-bottom: 10px;
      border-radius: 8px;
      color: white;
      font-size: 14px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      animation: slideIn 0.3s, fadeOut 0.5s 1.5s forwards;
      transform: translateX(0);
    }
    
    .toast-success {
      background-color: var(--secondary);
    }
    
    .toast-error {
      background-color: var(--danger);
    }
    
    .toast-close {
      background: none;
      border: none;
      color: white;
      cursor: pointer;
      margin-left: 15px;
      font-size: 1rem;
    }
    
    @keyframes slideIn {
      from { transform: translateX(100%); opacity: 0; }
      to { transform: translateX(0); opacity: 1; }
    }
    
    @keyframes fadeOut {
      from { opacity: 1; }
      to { opacity: 0; }
    }
    
    /* Modal Styles */
    .modal {
      display: none;
      position: fixed;
      z-index: 1050;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, 0.5);
      overflow-y: auto;
    }
    
    .modal-content {
      background-color: white;
      margin: 250px auto;
      padding: 25px;
      border-radius: 8px;
      width: 90%;
      max-width: 400px;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
      animation: modalFadeIn 0.3s;
    }
    
    @keyframes modalFadeIn {
      from { opacity: 0; transform: translateY(-20px); }
      to { opacity: 1; transform: translateY(0); }
    }
    
    .modal-header {
      margin-bottom: 20px;
    }
    
    .modal-header h3 {
      margin: 0;
      color: var(--dark);
      font-size: 1.20rem;
    }
    
    .modal-body {
      margin-bottom: 20px;
      color: var(--dark);
      font-size: 0.8rem;
    }
    
    .modal-actions {
      display: flex;
      justify-content: flex-end;
      gap: 10px;
    }
    
    .fade-in {
      animation: fadeIn 0.5s ease-in;
    }
    
    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }
    
    /* Responsive Styles */
    @media (min-width: 768px) {
      .sidebar {
        transform: translateX(0);
      }
      
      .main-content {
        margin-left: 220px;
      }
    }
    
    @media (max-width: 767px) {
      .form-container {
        margin: 1rem;
      }
      
      .usdt-item {
        flex-direction: column;
        align-items: flex-start;
        gap: 1rem;
      }
      
      .usdt-actions {
        width: 100%;
        justify-content: flex-end;
      }
    }
    .usdt-container{
      padding: 2px 14px;
    }
    
    .usdt-container h3{
      padding: 10px 5px;
    }
  </style>
</head>

<body>
  <div class="wrapper">
    <?php include('compass.php'); ?>
  
    <!-- Main Content -->
    <div class="main-content">
      <!-- Navbar -->
      <nav class="navbar">
        <a href="#" class="navbar-brand" id="sidebarToggle">
          <i class="fas fa-bars"></i>
          <span>Menu</span>
        </a>
        
        <ul class="navbar-nav">
          <li class="nav-item dropdown">
            <a href="#" class="nav-link" id="settingsDropdown">
              <i class="fas fa-user-cog"></i>
            </a>
            <div class="dropdown-menu" id="settingsMenu">
              <a href="logout.php" class="dropdown-item">
                <i class="fas fa-sign-out-alt"></i> Logout
              </a>
            </div>
          </li>
        </ul>
      </nav>
      <br>
      <!-- Content Header -->
      
      <!-- Content Area -->
      <div class="content-area">
        <!-- Content Header -->
        <div class="content-header">
          <div class="breadcrumb">
            <a href="dashboard.php">Home</a> / Manage USDT
          </div>
          <h1 class="text-xl font-bold text-gray-800">USDT Address Management</h1>
          <p class="text-gray-500 text-sm">
            <?php echo date("l, F d, Y"); ?>
          </p>
        </div>
        
        <!-- Main Content Area -->
        <div class="md:p-4">
          <!-- Form Container -->
          <div class="form-container animate-fadeInUp">
            <h3><i class="fas fa-wallet text-blue-500"></i> Add New USDT Address</h3>
            <form action="#" id="usdtform" method="post" autocomplete="off">
              <input type="hidden" name="form_token" value="<?php echo $_SESSION['form_token']; ?>">
              
              <div class="form-group">
                <label>USDT TRC20 Address</label>
                <input name="newusdt" type="text" placeholder="Enter USDT TRC20 Address (e.g. TAbCdEfGhIjKlMnOpQrStUvWxYz1234567)" required class="form-control" />
                <p class="text-xs text-gray-500 mt-1">Example: TAbCdEfGhIjKlMnOpQrStUvWxYz1234567</p>
              </div>
              <button type="submit" class="btn btn-primary" id="submitBtn">
                <i class="fas fa-plus-circle mr-2"></i> Add USDT Address
              </button>
            </form>
          </div>
          
          <!-- USDT List -->
          <div class="usdt-container animate-fadeInUp">
            <h3><i class="fas fa-list text-blue-500"></i> Manage USDT Addresses</h3>
            
            <form action="#" id="usdtsave" method="post" autocomplete="off">
              <ul class="usdt-list">
                <?php
                $sel_usdt = "SELECT * FROM deyyamrici ORDER BY maulya ASC";
                $usdt_r = mysqli_query($conn, $sel_usdt);
                
                if(mysqli_num_rows($usdt_r) > 0):
                  while ($row = mysqli_fetch_array($usdt_r)): 
                ?>
                  <li class="usdt-item">
                    <div class="usdt-details">
                      <div class="usdt-address"><?php echo $row['maulya']; ?></div>
                      <?php if($row['sthiti'] == 1): ?>
                        <span class="usdt-status">Active</span>
                      <?php endif; ?>
                    </div>
                    
                    <div class="usdt-actions">
                      <input name="usdtid" type="radio" class="radio-active" value="<?php echo $row['maulya']; ?>" <?php if($row['sthiti']==1){echo "checked";} ?> />
                      
                      <button type="button" class="btn btn-primary btn-sm" onclick="copyToClipboard('<?php echo $row['maulya']; ?>')" title="Copy">
                        <i class="fas fa-copy"></i>
                      </button>
                      
                      <button type="button" class="btn btn-danger btn-sm" onclick="confirmDelete('<?php echo $row['maulya']; ?>')" title="Delete">
                        <i class="fas fa-trash-alt"></i>
                      </button>
                    </div>
                  </li>
                <?php 
                  endwhile;
                else:
                ?>
                  <li class="text-center py-4 text-gray-500">
                    No USDT addresses found. Add your first USDT address above.
                  </li>
                <?php endif; ?>
              </ul>
              
              <?php if(mysqli_num_rows($usdt_r) > 0): ?>
                <button type="submit" class="btn btn-primary mt-3">
                  <i class="fas fa-save mr-2"></i> Save Changes
                </button>
              <?php endif; ?>
            </form>
          </div>
        </div>
        <br><br><br>
        <!-- Footer -->
        <footer class="footer w-full bg-gradient-to-r from-slate-50 to-slate-100 border-t border-slate-200 shadow-sm py-4 px-6 fade-in">
          <div class="max-w-screen-xl mx-auto text-center">
            <span class="text-sm text-slate-500">
              Powered by <strong class="text-blue-900 font-semibold">RAJVEER CODER Admin</strong>
            </span>
          </div>
        </footer>
      </div>
    </div>
  </div>

  <!-- Toast Container -->
  <div id="toast-container"></div>

  <!-- Delete Confirmation Modal -->
  <div id="deleteModal" class="modal">
    <div class="modal-content">
      <div class="modal-header">
        <h3><i class="fas fa-exclamation-triangle text-red-500 mr-2"></i> Confirm Deletion</h3>
      </div>
      <div class="modal-body">
        <p>Are you sure you want to delete this USDT address? This action cannot be undone.</p>
      </div>
      <form id="deleteForm" method="post">
        <input type="hidden" name="delete_usdt" id="deleteUsdtAddress">
        <input type="hidden" name="delete_token" value="<?php echo $_SESSION['form_token']; ?>">
        <div class="modal-actions">
          <button type="button" onclick="closeModal()" class="btn btn-secondary">Cancel</button>
          <button type="submit" class="btn btn-danger">Delete</button>
        </div>
      </form>
    </div>
  </div>

  <!-- JavaScript -->
  <script>
    // Toggle sidebar on mobile
    document.getElementById('sidebarToggle').addEventListener('click', function(e) {
      e.preventDefault();
      document.querySelector('.sidebar').classList.toggle('show');
    });
    
    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', function(e) {
      const sidebar = document.querySelector('.sidebar');
      const sidebarToggle = document.getElementById('sidebarToggle');
      
      if (window.innerWidth <= 768) {
        if (!sidebar.contains(e.target) && !sidebarToggle.contains(e.target)) {
          sidebar.classList.remove('show');
        }
      }
    });
    
    // Toggle dropdown menu
    document.getElementById('settingsDropdown').addEventListener('click', function(e) {
      e.preventDefault();
      document.getElementById('settingsMenu').classList.toggle('show');
    });
    
    // Close dropdown when clicking outside
    document.addEventListener('click', function(e) {
      if (!e.target.closest('.nav-item.dropdown')) {
        document.getElementById('settingsMenu').classList.remove('show');
      }
    });
    
    // Toggle submenus in sidebar
    document.querySelectorAll('.sidebar-menu .has-submenu > a').forEach(item => {
      item.addEventListener('click', function(e) {
        e.preventDefault();
        const parent = this.parentElement;
        const submenu = this.nextElementSibling;
        
        // Close all other submenus
        document.querySelectorAll('.sidebar-menu .submenu').forEach(menu => {
          if (menu !== submenu) {
            menu.classList.remove('active');
            menu.previousElementSibling.classList.remove('active');
          }
        });
        
        // Toggle current submenu
        parent.classList.toggle('active');
        submenu.classList.toggle('active');
      });
    });
    
    // Copy to clipboard function
    function copyToClipboard(text) {
      navigator.clipboard.writeText(text).then(function() {
        showToast('USDT address copied to clipboard', 'success');
      }, function(err) {
        showToast('Failed to copy USDT address', 'error');
      });
    }
    
    // Form validation and submission handling
    document.getElementById('usdtform').addEventListener('submit', function(e) {
      e.preventDefault();
      const usdtInput = this.querySelector('input[name="newusdt"]');
      const usdtValue = usdtInput.value.trim();
      const submitBtn = document.getElementById('submitBtn');
      
      // Basic TRC20 address validation (starts with T, 34 chars)
      if (!/^T[A-Za-z1-9]{33}$/.test(usdtValue)) {
        showToast('Invalid USDT address format. Please use a valid TRC20 address', 'error');
        usdtInput.focus();
        return;
      }
      
      // Disable button to prevent double submission
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Adding...';
      
      // Submit form
      this.submit();
    });
    
    // Delete confirmation
    function confirmDelete(usdtAddress) {
      const modal = document.getElementById('deleteModal');
      document.getElementById('deleteUsdtAddress').value = usdtAddress;
      modal.style.display = 'block';
    }
    
    function closeModal() {
      document.getElementById('deleteModal').style.display = 'none';
    }
    
    // Close modal when clicking outside
    window.onclick = function(event) {
      const modal = document.getElementById('deleteModal');
      if (event.target == modal) {
        modal.style.display = 'none';
      }
    }
    
    // Show toast notification
    function showToast(message, type) {
      const toastContainer = document.getElementById('toast-container');
      const toast = document.createElement('div');
      toast.className = `toast toast-${type}`;
      toast.innerHTML = `
        <span>${message}</span>
        <button class="toast-close" onclick="this.parentElement.remove()">&times;</button>
      `;
      toastContainer.appendChild(toast);
      
      // Auto remove after 2 seconds
      setTimeout(() => {
        toast.remove();
      }, 2000);
    }
    
    // Show any server-side toast messages
    <?php if (isset($_SESSION['toast'])): ?>
      document.addEventListener('DOMContentLoaded', function() {
        showToast('<?php echo $_SESSION['toast']['message']; ?>', '<?php echo $_SESSION['toast']['type']; ?>');
      });
      <?php unset($_SESSION['toast']); ?>
    <?php endif; ?>
    
    // Prevent form resubmission on page refresh
    if (window.history.replaceState) {
      window.history.replaceState(null, null, window.location.href);
    }
  </script>
</body>
</html>