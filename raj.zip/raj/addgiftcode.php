<?php
session_start();
if ($_SESSION['unohs'] == null) {
    header("location:index.php?msg=unauthorized");
}
date_default_timezone_set("Asia/Kolkata");
include("conn.php");

function generateRandomSerial($length = 32) {
    $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[random_int(0, $charactersLength - 1)];
    }
    return $randomString;
}

// Generate unique token for form
if (!isset($_SESSION['form_token'])) {
    $_SESSION['form_token'] = bin2hex(random_bytes(32));
}

// Handling form submission to generate codes
if (isset($_POST['maxserials']) && isset($_POST['form_token']) && $_POST['form_token'] === $_SESSION['form_token']) {
    $maxserials = mysqli_real_escape_string($conn, $_POST['maxserials']);
    $maxusers = mysqli_real_escape_string($conn, $_POST['maxusers']);
    $price = mysqli_real_escape_string($conn, $_POST['price']);
    $remark = mysqli_real_escape_string($conn, $_POST['remark']);

    if ($maxserials > 50) {
        echo '<script>alert("You can only generate a maximum of 50 serial numbers.");</script>';
        exit;
    }

    $totalusers = 0;
    $createdate = date("Y-m-d H:i");
    $status = 1;
    $generatedSerials = [];

    for ($i = 0; $i < $maxserials; $i++) {
        $newSerial = generateRandomSerial();
        $generatedSerials[] = $newSerial;

        $insertRandomSerial = "INSERT INTO hodike_nirvahaka (enserie, utilisateurmax, prix, nombredutilisateurs, creerunrendezvous, shonu, remark) 
                               VALUES ('".$newSerial."', '".$maxusers."', '".$price."', '".$totalusers."', '".$createdate."', '".$status."', '".$remark."')";
        mysqli_query($conn, $insertRandomSerial);
    }

    $generatedSerialsJson = json_encode($generatedSerials);
    
    // Regenerate token after successful submission
    $_SESSION['form_token'] = bin2hex(random_bytes(32));
    
    // Redirect to prevent form resubmission
    header("Location: ".$_SERVER['PHP_SELF']);
    exit();
}

// Pagination Setup
$limit = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Fetch history
$historyQuery = "SELECT * FROM hodike_nirvahaka ORDER BY creerunrendezvous DESC LIMIT $limit OFFSET $offset";
$historyResult = mysqli_query($conn, $historyQuery);

// Count total records
$totalQuery = "SELECT COUNT(*) AS total FROM hodike_nirvahaka";
$totalResult = mysqli_query($conn, $totalQuery);
$totalRow = mysqli_fetch_assoc($totalResult);
$totalRecords = $totalRow['total'];
$totalPages = ceil($totalRecords / $limit);

// Handle deletion
if (isset($_POST['delete_serial']) && isset($_POST['delete_token']) && $_POST['delete_token'] === $_SESSION['form_token']) {
    $serialToDelete = mysqli_real_escape_string($conn, $_POST['delete_serial']);
    $deleteQuery = "DELETE FROM hodike_nirvahaka WHERE enserie = '$serialToDelete'";
    mysqli_query($conn, $deleteQuery);
    
    // Regenerate token after deletion
    $_SESSION['form_token'] = bin2hex(random_bytes(32));
    header("Location: ".$_SERVER['PHP_SELF']);
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Gift Code Management</title>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Montserrat:wght@600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/common.css"/>
  <!-- SweetAlert2 CSS -->
  <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.6.10/dist/sweetalert2.min.css" rel="stylesheet">
  <style>
    :root {
      --primary: #5e72e4;
      --primary-dark: #4a5acf;
      --secondary: #2dce89;
      --danger: #f5365c;
      --dark: #32325d;
      --light: #f8f9fa;
      --white: #ffffff;
      --gray: #6c757d;
      --card-shadow: 0 0 1rem 0 rgba(136, 152, 170, 0.1);
    }
    
    body {
      font-family: 'Poppins', sans-serif;
      background-color: #f5f7fb;
      color: #525f7f;
    }
    
    /* Main Content Styles */
    .main-content {
      padding: 5px;
      margin-left: 220px; /* Reduced from 250px */
      transition: all 0.3s;
    }
    
    /* Form Styles */
    .form-container {
      background: var(--white);
      padding: 1rem;
      border-radius: 0.5rem;
      box-shadow: var(--card-shadow);
      margin-bottom: 1.5rem;
    }
    
    .form-container h3 {
      color: var(--dark);
      margin-bottom: 1rem;
      font-weight: 600;
      display: flex;
      align-items: center;
      gap: 10px;
      font-size: 1.1rem;
    }
    
    .form-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 1rem;
      margin-bottom: 1rem;
    }
    
    .form-group {
      margin-bottom: 0.5rem; 
      margin-right: 20px;
    }
    
    .form-group label {
      display: block;
      margin-bottom: 0.4rem;
      font-weight: 500;
      color: var(--dark);
      font-size: 0.85rem;
    }
    
    .form-control {
      width: 100%;
      padding: 0.5rem 0.75rem; /* Reduced padding */
      border: 1px solid #e9ecef;
      border-radius: 0.375rem;
      font-size: 0.9rem;
      transition: all 0.3s ease;
      height: 30px; /* Reduced height */
      
    }
    
    .form-control:focus {
      border-color: var(--primary);
      box-shadow: 0 0 0 0.2rem rgba(94, 114, 228, 0.25);
      outline: none;
    }
    
    /* Button Styles */
    .btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: 0.5rem 1rem; /* Reduced padding */
      border-radius: 0.375rem;
      font-weight: 500;
      font-size: 0.85rem;
      line-height: 1.5;
      cursor: pointer;
      transition: all 0.3s ease;
      border: none;
    }
    
    .btn-primary {
      background-color: var(--primary);
      color: white;
    }
    
    .btn-primary:hover {
      background-color: var(--primary-dark);
      transform: translateY(-1px);
    }
    
    .btn-sm {
      padding: 0.3rem 0.6rem;
      font-size: 0.75rem;
    }
    
    .btn-success {
      background-color: var(--secondary);
      color: white;
    }
    
    .btn-danger {
      background-color: var(--danger);
      color: white;
    }
    
    .btn i {
      margin-right: 0.4rem;
      font-size: 0.8rem;
    }
    
    /* Table Styles - Professional Look */
    .table-responsive {
      width: 100%;
      overflow-x: auto;
      -webkit-overflow-scrolling: touch;
      border-radius: 0.5rem;
      box-shadow: var(--card-shadow);
    }
    
    .gift-table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 1rem;
      font-size: 0.8rem;
      background-color: var(--white);
    }
    
    .gift-table th {
      background-color: #f8f9fa;
      padding: 0.65rem;
      text-align: left;
      font-weight: 600;
      color: var(--dark);
      border-bottom: 2px solid #dee2e6;
      font-size: 0.75rem;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    
    .gift-table td {
      padding: 0.65rem;
      vertical-align: middle;
      border-bottom: 1px solid #f0f0f0;
      font-size: 0.8rem;
    }
    
    .gift-table tr:last-child td {
      border-bottom: none;
    }
    
    .gift-table tr:hover td {
      background-color: rgba(94, 114, 228, 0.05);
    }
    
    .serial-code {
      font-family: 'Roboto Mono', monospace;
      font-weight: 500;
      color: var(--dark);
      font-size: 0.8rem;
    }
    
    /* Action Buttons */
    .action-buttons {
      display: flex;
      gap: 5px;
    }
    
    /* Pagination Styles */
    .pagination-container {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      margin-top: 1rem;
    }
    
    .pagination {
      display: flex;
      padding-left: 0;
      list-style: none;
      border-radius: 0.375rem;
    }
    
    .page-item {
      margin: 0 0.15rem;
    }
    
    .page-item.disabled .page-link {
      color: #6c757d;
      pointer-events: none;
      background-color: #fff;
      border-color: #dee2e6;
    }
    
    .page-item.active .page-link {
      z-index: 3;
      color: #fff;
      background-color: var(--primary);
      border-color: var(--primary);
    }
    
    .page-link {
      position: relative;
      display: block;
      padding: 0.4rem 0.65rem;
      margin-left: -1px;
      line-height: 1.25;
      color: var(--primary);
      background-color: #fff;
      border: 1px solid #dee2e6;
      text-decoration: none;
      font-size: 0.75rem;
    }
    
    .page-link:hover {
      z-index: 2;
      color: var(--primary-dark);
      background-color: #e9ecef;
      border-color: #dee2e6;
    }
    
    /* Navbar Styles - Reduced Height */
    .navbar {
      height: 50px; /* Reduced from default */
      padding: 0.5rem 1rem;
    }
    
    .navbar-brand {
      font-size: 0.9rem;
    }
    
    .nav-link {
      padding: 0.4rem 0.75rem;
    }
    
    /* Mobile Responsive Adjustments */
    @media (max-width: 992px) {
      .main-content {
        margin-left: 0;
        padding: 0px;
      }
      
      .form-grid {
        grid-template-columns: 1fr;
      }
      
      .form-container {
        padding: 1rem;
        margin: 10px 10px;
      }
      
      .gift-table {
        font-size: 0.75rem;
      }
      
      .gift-table th, 
      .gift-table td {
        padding: 0.5rem;
      }
      
      .btn {
        padding: 0.4rem 0.8rem;
        font-size: 0.8rem;
      }
      
      .page-link {
        padding: 0.3rem 0.5rem;
      }
    }
    
    @media (max-width: 768px) {
      .gift-table {
        display: block;
        width: 100%;
      }
      
      .gift-table thead {
        display: none;
      }
      
      .gift-table tr {
        display: block;
        margin-bottom: 1rem;
        border: 1px solid #dee2e6;
        border-radius: 0.375rem;
      }
      
      .gift-table td {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 0.5rem;
        border: none;
        border-bottom: 1px solid #dee2e6;
      }
      
      .gift-table td:before {
        content: attr(data-label);
        font-weight: 600;
        margin-right: 1rem;
        color: var(--dark);
        font-size: 0.7rem;
      }
      
      .gift-table td:last-child {
        border-bottom: none;
      }
      
      .serial-code {
        word-break: break-all;
      }
      
      .action-buttons {
        justify-content: flex-end;
      }
    }

    /* Content Header Styles */
    .content-header {
      margin-bottom: 1.2rem;
    }
    
    .content-header h1 {
      font-weight: 600;
      color: var(--dark);
      margin-bottom: 0.5rem;
      font-size: 1.3rem;
    }
    
    .breadcrumb {
      font-size: 0.8rem;
      color: var(--gray);
      margin-bottom: 0.5rem;
    }
    
    .breadcrumb a {
      color: var(--primary);
      text-decoration: none;
    }
    
    /* Animation */
    .fade-in {
      animation: fadeIn 0.5s ease-in-out;
    }
    
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(10px); }
      to { opacity: 1; transform: translateY(0); }
    }
    
    /* Status Badges */
    .status-badge {
      display: inline-block;
      padding: 0.25rem 0.5rem;
      border-radius: 0.25rem;
      font-size: 0.7rem;
      font-weight: 500;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    
    .status-active {
      background-color: rgba(45, 206, 137, 0.1);
      color: var(--secondary);
    }
    
    .status-inactive {
      background-color: rgba(245, 54, 92, 0.1);
      color: var(--danger);
    } 
    /* Responsive Styles */
    @media (min-width: 768px) {
      .main-content {
        margin-left: 220px;
        overflow-X: scroll;
      }
      
      .form-container,
      .table-scroll-container {
        max-width: 100%;
        overflow-X; auto;
      }
      
      #usersTable {
        min-width: 100%;
      }
      
      .stats-container {
        grid-template-columns: repeat(3, 1fr);
      }
    }
  </style>
</head>

<body>
  <div class="wrapper">
    <?php include('compass.php'); ?>
  
    <!-- Main Content -->
    <div class="main-content">
      <!-- Navbar -->
      <nav class="navbar">
        <a href="#" class="navbar-brand" id="sidebarToggle">
          <i class="fas fa-bars"></i>
          <span>Menu</span>
        </a>
        
        <ul class="navbar-nav">
          <li class="nav-item dropdown">
            <a href="#" class="nav-link" id="settingsDropdown">
              <i class="fas fa-user-cog"></i>
            </a>
            <div class="dropdown-menu" id="settingsMenu">
              <a href="logout.php" class="dropdown-item">
                <i class="fas fa-sign-out-alt"></i> Logout
              </a>
            </div>
          </li>
        </ul>
      </nav>
      
      <!-- Form Container -->
      <div class="form-container fade-in">
        <h3><i class="fas fa-gift"></i> Generate New Gift Codes</h3>
        <form action="#" id="redform" method="post" autocomplete="off">
          <input type="hidden" name="form_token" value="<?php echo $_SESSION['form_token']; ?>">
          
          <div class="form-grid">
            <div class="form-group">
              <label>Number of Codes</label>
              <input name="maxserials" type="number" placeholder="Enter quantity (max 50)" required class="form-control" min="1" max="50" />
            </div>
            <div class="form-group">
              <label>Max Users per Code</label>
              <input name="maxusers" type="number" placeholder="Enter max users" required class="form-control" min="1" />
            </div>
            <div class="form-group">
              <label>Price/Value</label>
              <input name="price" type="number" placeholder="Enter price" required class="form-control" min="0" step="0.01" />
            </div>
            <div class="form-group">
              <label>Remark</label>
              <input name="remark" type="text" placeholder="Add remark" required class="form-control" />
            </div>
          </div>
          <button type="submit" class="btn btn-primary">
            <i class="fas fa-magic"></i> Generate Codes
          </button>
        </form>
      </div>
      
      <!-- History Table -->
      <div class="form-container fade-in">
        <h3><i class="fas fa-history"></i> Generated Codes History</h3>
        
        <div class="table-responsive">
          <table class="gift-table">
            <thead>
              <tr>
                <th>Code</th>
                <th>Max Users</th>
                <th>Value</th>
                <th>Created On</th>
                <th>Remark</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php while ($row = mysqli_fetch_assoc($historyResult)): ?>
                <tr>
                  <td data-label="Code">
                    <span class="serial-code"><?php echo $row['enserie']; ?></span>
                    <button class="btn btn-success btn-sm ms-2" onclick="copyToClipboard('<?php echo $row['enserie']; ?>')">
                      <i class="fas fa-copy"></i> 
                    </button>
                  </td>
                  <td data-label="Max Users"><?php echo $row['utilisateurmax']; ?></td>
                  <td data-label="Value"><?php echo $row['prix']; ?></td>
                  <td data-label="Created On"><?php echo date("M d, Y H:i", strtotime($row['creerunrendezvous'])); ?></td>
                  <td data-label="Remark"><?php echo $row['remark']; ?></td>
                  <td data-label="Actions">
                    <form method="post" action="" class="action-buttons">
                      <input type="hidden" name="delete_serial" value="<?php echo $row['enserie']; ?>" />
                      <input type="hidden" name="delete_token" value="<?php echo $_SESSION['form_token']; ?>" />
                      <button type="submit" class="btn btn-danger btn-sm" onclick="return confirmDelete()">
                        <i class="fas fa-trash-alt"></i> 
                      </button>
                    </form>
                  </td>
                </tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        </div>

        <!-- Pagination -->
        <div class="pagination-container">
          <ul class="pagination">
            <?php if ($page > 1): ?>
              <li class="page-item">
                <a class="page-link" href="?page=<?php echo $page - 1; ?>" aria-label="Previous">
                  <span aria-hidden="true">&laquo;</span>
                </a>
              </li>
            <?php endif; ?>
            
            <?php 
            $startPage = max(1, $page - 2);
            $endPage = min($totalPages, $page + 2);
            
            if ($startPage > 1) {
                echo '<li class="page-item"><a class="page-link" href="?page=1">1</a></li>';
                if ($startPage > 2) {
                    echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                }
            }
            
            for ($i = $startPage; $i <= $endPage; $i++): ?>
              <li class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>">
                <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
              </li>
            <?php endfor; 
            
            if ($endPage < $totalPages) {
                if ($endPage < $totalPages - 1) {
                    echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                }
                echo '<li class="page-item"><a class="page-link" href="?page='.$totalPages.'">'.$totalPages.'</a></li>';
            }
            ?>
            
            <?php if ($page < $totalPages): ?>
              <li class="page-item">
                <a class="page-link" href="?page=<?php echo $page + 1; ?>" aria-label="Next">
                  <span aria-hidden="true">&raquo;</span>
                </a>
              </li>
            <?php endif; ?>
          </ul>
        </div>
        
        <div class="text-center text-muted mt-2" style="font-size: 0.75rem;">
          Showing page <?php echo $page; ?> of <?php echo $totalPages; ?> (Total <?php echo $totalRecords; ?> records)
        </div>
      </div>
    </div>
  </div>

  <!-- JavaScript -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.6.10/dist/sweetalert2.min.js"></script>
  <script>
    // Toggle sidebar on mobile
    document.getElementById('sidebarToggle').addEventListener('click', function(e) {
      e.preventDefault();
      document.querySelector('.sidebar').classList.toggle('show');
    });
    
    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', function(e) {
      const sidebar = document.querySelector('.sidebar');
      const sidebarToggle = document.getElementById('sidebarToggle');
      
      if (window.innerWidth <= 992) {
        if (!sidebar.contains(e.target) && !sidebarToggle.contains(e.target)) {
          sidebar.classList.remove('show');
        }
      }
    });
    
    // Toggle dropdown menu
    document.getElementById('settingsDropdown').addEventListener('click', function(e) {
      e.preventDefault();
      document.querySelector('.dropdown-menu').classList.toggle('show');
    });
    
    // Close dropdown when clicking outside
    document.addEventListener('click', function(e) {
      if (!e.target.closest('.nav-item.dropdown')) {
        document.querySelector('.dropdown-menu').classList.remove('show');
      }
    });
    
    // Toggle submenus in sidebar - FIXED VERSION
    document.querySelectorAll('.sidebar-menu .has-submenu > a').forEach(item => {
      item.addEventListener('click', function(e) {
        e.preventDefault();
        const parent = this.parentElement;
        const submenu = this.nextElementSibling;
        
        // Close all other submenus
        document.querySelectorAll('.sidebar-menu .submenu').forEach(menu => {
          if (menu !== submenu) {
            menu.classList.remove('active');
            menu.previousElementSibling.classList.remove('active');
          }
        });
        
        // Toggle current submenu
        parent.classList.toggle('active');
        submenu.classList.toggle('active');
      });
    });
    
    // Copy to clipboard function
    function copyToClipboard(text) {
      navigator.clipboard.writeText(text).then(function() {
        Swal.fire({
          icon: 'success',
          title: 'Copied!',
          text: 'Gift code copied to clipboard',
          showConfirmButton: false,
          timer: 1500
        });
      }, function(err) {
        Swal.fire({
          icon: 'error',
          title: 'Failed to copy',
          text: 'Please try again',
          showConfirmButton: false,
          timer: 1500
        });
      });
    }
    
    // Confirm deletion
    function confirmDelete() {
      return confirm('Are you sure you want to delete this gift code? This action cannot be undone.');
    }
    
    <?php if (isset($generatedSerialsJson)): ?>
      // Show success message after generating codes
      document.addEventListener('DOMContentLoaded', function() {
        Swal.fire({
          icon: 'success',
          title: 'Codes Generated!',
          html: '<?php echo count(json_decode($generatedSerialsJson)); ?> new gift codes have been generated successfully.',
          showConfirmButton: false,
          timer: 2000
        });
      });
    <?php endif; ?>
  </script>
</body>
</html>