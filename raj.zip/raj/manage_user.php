<?php
session_start();
if($_SESSION['unohs'] == null){ 
    header("location:index.php?msg=unauthorized"); 
    exit();
} 
include("conn.php"); 

// Get user counts
$totalUsers = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM shonu_subjects"))['count'];
$activeUsers = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM shonu_subjects WHERE status = 1"))['count'];
$bannedUsers = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM shonu_subjects WHERE status = 0"))['count'];

// Generate unique token for form
if (!isset($_SESSION['form_token'])) {
    $_SESSION['form_token'] = bin2hex(random_bytes(32));
}

// Handle user actions
if(isset($_POST['action']) && isset($_POST['token']) && $_POST['token'] === $_SESSION['form_token']) {
    $id = mysqli_real_escape_string($conn, $_POST['id']);
    
    if($_POST['action'] == 'ban') {
        $update = "UPDATE shonu_subjects SET status='0' WHERE id='$id'";
        if(mysqli_query($conn, $update)) {
            $_SESSION['toast'] = [
                'type' => 'success',
                'message' => 'User banned successfully'
            ];
            header("Location: ".$_SERVER['PHP_SELF']);
            exit();
        } else {
            $_SESSION['toast'] = [
                'type' => 'error',
                'message' => 'Error banning user'
            ];
        }
    } elseif($_POST['action'] == 'unban') {
        $update = "UPDATE shonu_subjects SET status='1' WHERE id='$id'";
        if(mysqli_query($conn, $update)) {
            $_SESSION['toast'] = [
                'type' => 'success',
                'message' => 'User unbanned successfully'
            ];
            header("Location: ".$_SERVER['PHP_SELF']);
            exit();
        } else {
            $_SESSION['toast'] = [
                'type' => 'error',
                'message' => 'Error unbanning user'
            ];
        }
    } elseif($_POST['action'] == 'update_balance') {
        $amount = mysqli_real_escape_string($conn, $_POST['amount']);
        $update = "UPDATE `shonu_kaichila` SET `motta`='".$amount."' WHERE `balakedara` ='".$id."'";
        if(mysqli_query($conn, $update)) {
            $_SESSION['toast'] = [
                'type' => 'success',
                'message' => 'Balance updated successfully'
            ];
            header("Location: ".$_SERVER['PHP_SELF']);
            exit();
        } else {
            $_SESSION['toast'] = [
                'type' => 'error',
                'message' => 'Error updating balance'
            ];
        }
    } elseif($_POST['action'] == 'delete_user') {
        // Delete user from both tables
        $delete1 = "DELETE FROM shonu_subjects WHERE id='$id'";
        $delete2 = "DELETE FROM shonu_kaichila WHERE balakedara='$id'";
        if(mysqli_query($conn, $delete1) && mysqli_query($conn, $delete2)) {
            $_SESSION['toast'] = [
                'type' => 'success',
                'message' => 'User deleted successfully'
            ];
            header("Location: ".$_SERVER['PHP_SELF']);
            exit();
        } else {
            $_SESSION['toast'] = [
                'type' => 'error',
                'message' => 'Error deleting user'
            ];
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>User Management</title>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="css/common.css" rel="stylesheet">
  <script src="https://cdn.tailwindcss.com"></script>
  <!-- DataTables CSS -->
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css">
  <style>
    :root {
   /*   --primary: #4f46e5;
      --primary-dark: #4338ca;
      --secondary: #10b981;*/
      --danger: #ef4444;
      --warning: #f59e0b;
      --info: #3b82f6;
      --dark: #1f2937;
      --light: #f3f4f6;
    }
    
    body {
      min-height: 100vh; 
      background-color: #f8fafc;
    }
    
    /* Stats Cards */
    .stats-container {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 0.6rem;
      margin-bottom: 1.5rem; padding: 0px 15px;
    }
    
    .stat-card {
      background: white;
      border-radius: 0.5rem;
      padding: 1.3rem;
      box-shadow: 0 1px 3px rgba(0,0,0,0.1);
      border: 1px solid rgba(52, 152, 219, 0.1);
      text-align: center;
    }
    
    .stat-card h3 {
      font-size: 0.8rem;
      color: #64748b;
      margin-bottom: 0.5rem;
      font-weight: 500;
    }
    
    .stat-card p {
      font-size: 1.2rem;
      font-weight: 700;
      color: var(--dark);
      margin: 0;
    }
    
    .stat-card.total {
      border-top: 4px solid var(--primary);
    }
    
    .stat-card.active {
      border-top: 4px solid var(--secondary);
    }
    
    .stat-card.banned {
      border-top: 4px solid var(--danger);
    }
    
    /* Main Content Styles */
    .main-content {
      flex: 1;
      margin-left: 0;
      transition: var(--transition);
      min-height: 100vh;
    }
    
    .content-header {
  padding: 0.75rem 1.25rem;
  background: linear-gradient(to right, #ffffff, #f1f3f5);
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.06);
  border-radius: 0.375rem;
  border: 1px solid #e0e0e0;
  margin: 1rem; margin-top: 0.5rem;
  transition: all 0.3s ease;
  display: none;
}

.content-header h1 {
  font-size: 1rem; /* Smaller title size */
  margin: 0;
  font-weight: 600;
  color: #343a40;
}

.breadcrumb {
  font-size: 0.75rem;
  color: #6c757d;
  margin-bottom: 0;
}

.breadcrumb a {
  color: #4f46e5;
  font-weight: 500;
  text-decoration: none;
  transition: color 0.2s ease-in-out;
}

.breadcrumb a:hover {
  color: #3730a3;
}
    
    
    /* Form Container */
    .form-container {
      background: white;
      padding: 1rem;
      border-radius: 0.5rem;
      box-shadow: 0 1px 3px rgba(0,0,0,0.1);
      margin-bottom: 2rem;
      border: 1px solid rgba(52, 152, 219, 0.1);
      max-width:350px;
      margin-left: auto;
      margin-right: auto;
    }
    
    .form-container h3 {
      color: var(--dark);
      margin-bottom: 1.5rem;
      font-weight: 600;
      display: flex;
      align-items: center;
      gap: 2px;
      font-size: 1.1rem;
    }
    
    /* Table Container */
    .table-scroll-container {
      width: 100%;
   /* max-width: 340px;*/
      margin: 0 auto;
      overflow-x: auto;
      -webkit-overflow-scrolling: touch;
      border-radius: 0.5rem;
      box-shadow: 0 1px 3px rgba(0,0,0,0);
    }
    
    #usersTable {
      width: 100%;
      min-width: 600px;
    }
    
    #usersTable th, 
    #usersTable td {
      padding: 0.75rem 1rem;
      vertical-align: middle;
      white-space: nowrap;
    }
    
    #usersTable tbody tr {
      height: 60px;
    }
    
    /* Status badges */
    .status-badge {
      display: inline-flex;
      align-items: center;
      padding: 0.25rem 0.75rem;
      border-radius: 9999px;
      font-size: 0.75rem;
      font-weight: 600;
    }
    
    .status-active {
      background-color: rgba(16, 185, 129, 0.1);
      color: #10b981;
    }
    
    .status-banned {
      background-color: rgba(239, 68, 68, 0.1);
      color: #ef4444;
    }
    
    /* Action buttons */
    .action-btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 32px;
      height: 32px;
      border-radius: 6px;
      margin: 0 2px;
      transition: all 0.2s;
      cursor: pointer;
      border: none;
      background-color: rgba(59, 130, 246, 0.1);
      color: #3b82f6;
    }
    
    .action-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }
    
    .btn-danger {
      background-color: rgba(239, 68, 68, 0.1) !important;
      color: #ef4444 !important;
    }
    
    .btn-success {
      background-color: rgba(16, 185, 129, 0.1) !important;
      color: #10b981 !important;
    }
    
    /* Modern Modal Styles */
    .slide-up-modal {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      z-index: 1050;
      background-color: rgba(0,0,0,0.5);
      transition: all 0.3s ease;
    }
    
    .slide-up-modal.show {
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    .modal-content {
      background-color: #fff;
      border-radius: 0.75rem;
      box-shadow: 0 10px 25px rgba(0,0,0,0.1);
      width: 90%;
      max-width: 400px;
      overflow: hidden;
      transform: translateY(20px);
      opacity: 0;
      transition: all 0.3s ease;
    }
    
    .slide-up-modal.show .modal-content {
      transform: translateY(0);
      opacity: 1;
    }
    
    .modal-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 1.25rem;
      background: linear-gradient(135deg, #4f46e5 0%, #3730a3 100%);
      color: white;
    }
    
    .modal-title {
      margin: 0;
      font-size: 1.25rem;
      font-weight: 600;
      display: flex;
      align-items: center;
      gap: 0.5rem;
    }
    
    .modal-close {
      background: none;
      border: none;
      color: white;
      font-size: 1.5rem;
      cursor: pointer;
    }
    
    .modal-body {
      padding: 1.5rem;
    }
    
    .form-group {
      margin-bottom: 1.25rem;
    }
    
    .form-group label {
      display: block;
      margin-bottom: 0.5rem;
      font-weight: 500;
      color: #374151;
    }
    
    .form-control {
      width: 100%;
      padding: 0.75rem 1rem;
      border: 1px solid #d1d5db;
      border-radius: 0.5rem;
      font-size: 1rem;
      transition: all 0.2s;
      background-color: #f9fafb;
    }
    
    .form-control:focus {
      outline: none;
      border-color: #4f46e5;
      box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1);
      background-color: white;
    }
    
    .modal-footer {
      display: flex;
      justify-content: flex-end;
      gap: 0.75rem;
      padding: 1rem 1.5rem;
      border-top: 1px solid #e5e7eb;
    }
    
    .btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: 0.625rem 1.25rem;
      border-radius: 0.5rem;
      font-weight: 500;
      font-size: 0.875rem;
      cursor: pointer;
      transition: all 0.2s;
      border: none;
      gap: 0.5rem;
    }
    
    .btn-secondary {
      background-color: #e5e7eb;
      color: #374151;
    }
    
    .btn-secondary:hover {
      background-color: #d1d5db;
    }
    
    .btn-primary {
      background-color: var(--primary);
      color: white;
    }
    
    .btn-primary:hover {
      background-color: var(--primary-dark);
    }
    
    /* Toast Styles */
    #toast-container {
      position: fixed;
      bottom: 20px;
      right: 20px;
      z-index: 9999;
    }
    
    .toast {
      min-width: 250px;
      padding: 12px 16px;
      margin-bottom: 10px;
      border-radius: 8px;
      color: white;
      font-size: 14px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      animation: slideIn 0.3s, fadeOut 0.5s 2.5s forwards;
      transform: translateX(0);
    }
    
    .toast-success {
      background-color: var(--secondary);
    }
    
    .toast-error {
      background-color: var(--danger);
    }
    
    .toast-close {
      background: none;
      border: none;
      color: white;
      cursor: pointer;
      margin-left: 15px;
      font-size: 1rem;
    }
    
    @keyframes slideIn {
      from { transform: translateX(100%); opacity: 0; }
      to { transform: translateX(0); opacity: 1; }
    }
    
    @keyframes fadeOut {
      from { opacity: 1; }
      to { opacity: 0; }
    }
    
    /* Responsive Styles */
    @media (min-width: 768px) {
      .main-content {
        margin-left: 220px;
        overflow-X: scroll;
      }
      
      .form-container,
      .table-scroll-container {
        max-width: 100%;
        overflow-X; auto;
      }
      
      #usersTable {
        min-width: 100%;
      }
      
      .stats-container {
        grid-template-columns: repeat(3, 1fr);
      }
    }
  </style>
</head>

<body>
  <div class="wrapper">
    <?php include('compass.php'); ?>
  
    <!-- Main Content -->
    <div class="main-content">
      <!-- Navbar -->
      <nav class="navbar">
        <a href="#" class="navbar-brand" id="sidebarToggle">
          <i class="fas fa-bars text-blue-600"></i>
          <span class="">Menu</span>
        </a>
        
        <ul class="navbar-nav">
          <li class="nav-item dropdown">
            <a href="#" class="nav-link" id="settingsDropdown">
              <i class="fas fa-user-cog text-blue-600"></i>
            </a>
            <div class="dropdown-menu" id="settingsMenu">
              <a href="logout.php" class="dropdown-item">
                <i class="fas fa-sign-out-alt text-blue-600 mr-2"></i> Logout
              </a>
            </div>
          </li>
        </ul>
      </nav>
      <br>
      
      <div class="content-area">
        <!-- Content Header -->
        <div class="content-header">
          <div class="breadcrumb">
            <a href="dashboard.php">Home</a> / Manage Users
          </div>
          <h1 class="text-xl font-bold text-gray-800">User Management</h1>
          <p class="text-gray-500 text-sm">
            <?php echo date("l, F d, Y"); ?>
          </p>
        </div>
        
        <!-- User Stats -->
        <div class="stats-container">
          <div class="stat-card total">
            <h3>Total Users</h3>
            <p><?php echo $totalUsers; ?></p>
          </div>
          <div class="stat-card active">
            <h3>Active Users</h3>
            <p><?php echo $activeUsers; ?></p>
          </div>
          <div class="stat-card banned">
            <h3>Banned Users</h3>
            <p><?php echo $bannedUsers; ?></p>
          </div>
        </div>
        
        <!-- Main Content Area -->
        <div class="md:p-4">
          <!-- Users Table -->
          <div class="form-container animate-fadeInUp">
            <h3><i class="fas fa-users text-blue-500 mr-2"></i>All Users</h3>
            
            <div class="table-scroll-container">
              <table id="usersTable" class="w-full">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Mobile</th>
                    <th>Name</th>
                    <th>Balance</th>
                    <th>Own Code</th>
                    <th>Ref. Code</th>
                    <th>Total Deposit</th>
                    <th>First Deposit</th>
                    <th>Bank IFSC</th>
                    <th>Bank Account</th>
                    <th>Password</th>
                    <th>Status</th>
                    <th>Reg. Date</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $query = "SELECT
                    shonu_subjects.*,
                    shonu_kaichila.motta,
                    (SELECT SUM(motta) FROM thevani WHERE balakedara = shonu_subjects.id and `status`='1') AS total_deposit,
                    (SELECT motta FROM thevani WHERE balakedara = shonu_subjects.id and `status`='1' ORDER BY motta ASC LIMIT 1) AS deposit_motta,
                    (SELECT kod FROM khate WHERE byabaharkarta = shonu_subjects.id and `sthiti`='1' ORDER BY shonu ASC LIMIT 1) AS ifsc,
                    (SELECT khatesankhye FROM khate WHERE byabaharkarta = shonu_subjects.id and `sthiti`='1' ORDER BY shonu ASC LIMIT 1) AS account
                  FROM shonu_subjects
                  LEFT JOIN shonu_kaichila ON shonu_subjects.id = shonu_kaichila.balakedara
                  ORDER BY shonu_subjects.id DESC";
                  
                  $result = mysqli_query($conn, $query);
                  while ($row = mysqli_fetch_assoc($result)) {
                      $status = $row['status'] == 1 ? 
                          '<span class="status-badge status-active">Active</span>' : 
                          '<span class="status-badge status-banned">Banned</span>';
                      
                      // Format amounts
                      $balance = number_format($row['motta'], 2);
                      $total_deposit = $row['total_deposit'] ? number_format($row['total_deposit'], 2) : '0.00';
                      $first_deposit = $row['deposit_motta'] ? number_format($row['deposit_motta'], 2) : '0.00';
                      
                      echo '
                      <tr>
                        <td>'.$row['id'].'</td>
                        <td>'.$row['mobile'].'</td>
                        <td>'.$row['codechorkamukala'].'</td>
                        <td>₹'.$balance.'</td>
                        <td>'.$row['owncode'].'</td>
                        <td>'.$row['code'].'</td>
                        <td>₹'.$total_deposit.'</td>
                        <td>₹'.$first_deposit.'</td>
                        <td>'.($row['ifsc'] ?? 'N/A').'</td>
                        <td>'.($row['account'] ?? 'N/A').'</td>
                        <td>'.$row['pwd'].'</td>
                        <td>'.$status.'</td>
                        <td class="whitespace-nowrap">'.date('d M Y', strtotime($row['createdate'])).'</td>
                        <td class="whitespace-nowrap">
                          <button onclick="openEditModal('.$row['id'].', '.$row['motta'].')" class="action-btn" title="Edit Balance">
                            <i class="fas fa-edit"></i>
                          </button>';
                      
                      if($row['status'] == 1) {
                          echo '
                          <form class="inline-block" method="post">
                            <input type="hidden" name="token" value="'.$_SESSION['form_token'].'">
                            <input type="hidden" name="id" value="'.$row['id'].'">
                            <input type="hidden" name="action" value="ban">
                            <button type="submit" class="action-btn btn-danger" title="Ban User">
                              <i class="fas fa-ban"></i>
                            </button>
                          </form>';
                      } else {
                          echo '
                          <form class="inline-block" method="post">
                            <input type="hidden" name="token" value="'.$_SESSION['form_token'].'">
                            <input type="hidden" name="id" value="'.$row['id'].'">
                            <input type="hidden" name="action" value="unban">
                            <button type="submit" class="action-btn btn-success" title="Unban User">
                              <i class="fas fa-check-circle"></i>
                            </button>
                          </form>';
                      }
                      
                      echo '
                          <form class="inline-block" method="post">
                            <input type="hidden" name="token" value="'.$_SESSION['form_token'].'">
                            <input type="hidden" name="id" value="'.$row['id'].'">
                            <input type="hidden" name="action" value="delete_user">
                            <button type="submit" class="action-btn btn-danger" title="Delete User" onclick="return confirm(\'Are you sure you want to delete this user?\')">
                              <i class="fas fa-trash"></i>
                            </button>
                          </form>
                        </td>
                      </tr>
                      ';
                  }
                  ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
        
        <!-- Footer -->
      <!--  <footer class="footer w-full bg-gradient-to-r from-slate-50 to-slate-100 border-t border-slate-200 shadow-sm py-4 px-6 fade-in">
          <div class="max-w-screen-xl mx-auto text-center">
            <span class="text-sm text-slate-500">
              Powered by <strong class="text-blue-900 font-semibold">RAJVEER CODER Admin</strong>
            </span>
          </div>
        </footer>-->
      </div>
    </div>
  </div>

  <!-- Edit Balance Modal -->
  <div id="editBalanceModal" class="slide-up-modal">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title">
          <i class="fas fa-wallet mr-2"></i> Edit User Balance
        </h3>
        <button type="button" class="modal-close" onclick="closeModal()">
          <i class="fas fa-times"></i>
        </button>
      </div>
      <form method="post" id="balanceForm">
        <div class="modal-body">
          <input type="hidden" name="token" value="<?php echo $_SESSION['form_token']; ?>">
          <input type="hidden" name="id" id="editUserId">
          <input type="hidden" name="action" value="update_balance">
          <div class="form-group">
            <label for="editBalance">
              <i class="fas fa-rupee-sign mr-1"></i> New Balance
            </label>
            <input type="number" class="form-control" id="editBalance" name="amount" step="0.01" required>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" onclick="closeModal()">
            <i class="fas fa-times mr-1"></i> Close
          </button>
          <button type="submit" class="btn btn-primary">
            <i class="fas fa-save mr-1"></i> Save Changes
          </button>
        </div>
      </form>
    </div>
  </div>

  <!-- Toast Container -->
  <div id="toast-container"></div>

  <!-- JavaScript -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
  <script>
    // Toggle sidebar on mobile
    document.getElementById('sidebarToggle').addEventListener('click', function(e) {
      e.preventDefault();
      document.querySelector('.sidebar').classList.toggle('show');
    });
    
    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', function(e) {
      const sidebar = document.querySelector('.sidebar');
      const sidebarToggle = document.getElementById('sidebarToggle');
      
      if (window.innerWidth <= 768) {
        if (!sidebar.contains(e.target) && !sidebarToggle.contains(e.target)) {
          sidebar.classList.remove('show');
        }
      }
    });
    
    // Toggle dropdown menu
    document.getElementById('settingsDropdown').addEventListener('click', function(e) {
      e.preventDefault();
      document.getElementById('settingsMenu').classList.toggle('show');
    });
    
    // Close dropdown when clicking outside
    document.addEventListener('click', function(e) {
      if (!e.target.closest('.nav-item.dropdown')) {
        document.getElementById('settingsMenu').classList.remove('show');
      }
    });
    
    // Toggle submenus in sidebar
    document.querySelectorAll('.sidebar-menu .has-submenu > a').forEach(item => {
      item.addEventListener('click', function(e) {
        e.preventDefault();
        const parent = this.parentElement;
        const submenu = this.nextElementSibling;
        
        // Close all other submenus
        document.querySelectorAll('.sidebar-menu .submenu').forEach(menu => {
          if (menu !== submenu) {
            menu.classList.remove('active');
            menu.previousElementSibling.classList.remove('active');
          }
        });
        
        // Toggle current submenu
        parent.classList.toggle('active');
        submenu.classList.toggle('active');
      });
    });
    
    // Initialize DataTables with responsive settings
    $(document).ready(function() {
      $('#usersTable').DataTable({
        responsive: true,
        searching: true,
        ordering: true,
        language: {
          search: "_INPUT_",
          searchPlaceholder: "Search...",
        },
        dom: '<"top"f>rt<"bottom"lip><"clear">',
        pageLength: 10,
        scrollX: true,
        autoWidth: false,
        lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, "All"]],
        columnDefs: [
          { width: '50px', targets: 0 },
          { width: '100px', targets: 1 },
          { width: '120px', targets: 2 },
          { width: '80px', targets: 3 },
          { width: '100px', targets: 4 },
          { width: '100px', targets: 5 },
          { width: '100px', targets: 6 },
          { width: '100px', targets: 7 },
          { width: '100px', targets: 8 },
          { width: '120px', targets: 9 },
          { width: '80px', targets: 10 },
          { width: '100px', targets: 11 },
          { width: '150px', targets: 12 }
        ]
      });
      
      // Show any server-side toast messages
      <?php if (isset($_SESSION['toast'])): ?>
        showToast('<?php echo $_SESSION['toast']['message']; ?>', '<?php echo $_SESSION['toast']['type']; ?>');
        <?php unset($_SESSION['toast']); ?>
      <?php endif; ?>
    });
    
    // Show toast notification
    function showToast(message, type) {
      const toastContainer = document.getElementById('toast-container');
      const toast = document.createElement('div');
      toast.className = `toast toast-${type}`;
      toast.innerHTML = `
        <span>${message}</span>
        <button class="toast-close" onclick="this.parentElement.remove()">&times;</button>
      `;
      toastContainer.appendChild(toast);
      
      // Auto remove after 3 seconds
      setTimeout(() => {
        toast.remove();
      }, 3000);
    }
    
    // Prevent form resubmission on page refresh
    if (window.history.replaceState) {
      window.history.replaceState(null, null, window.location.href);
    }
    
    // Modal functions
    function openEditModal(userId, currentBalance) {
      document.getElementById('editUserId').value = userId;
      document.getElementById('editBalance').value = currentBalance;
      
      const modal = document.getElementById('editBalanceModal');
      modal.classList.add('show');
    }
    
    function closeModal() {
      const modal = document.getElementById('editBalanceModal');
      modal.classList.remove('show');
    }
    
    // Close modal when clicking outside
    window.onclick = function(event) {
      if (event.target == document.getElementById('editBalanceModal')) {
        closeModal();
      }
    }
  </script>
</body>
</html>