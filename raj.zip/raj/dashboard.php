<?php
    session_start();
    if($_SESSION['unohs'] == null){
        header("location:index.php?msg=unauthorized");
    }    
    date_default_timezone_set("Asia/Kolkata");
?>
<?php 
    include ("conn.php");
    $curdate = date('Y-m-d h:i:s');
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Admin Dashboard</title>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Montserrat:wght@600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/common.css"/>
  <!-- Custom CSS -->
  <style>
   
  </style>
  <!-- Tailwind CDN for demo (remove if already included in your project) -->
<script src="https://cdn.tailwindcss.com"></script>

</head>

<body>
  <div class="wrapper">
  <?php include('compass.php'); 
  
          $admin = $salu['hesaru'];
   ?>
  
    <!-- Main Content -->
    <div class="main-content">
      <!-- Navbar -->
      <nav class="navbar">
        <a href="#" class="navbar-brand" id="sidebarToggle">
          <i class="fas fa-bars"></i>
          <span>Menu</span>
        </a>
        
        <ul class="navbar-nav">
          <li class="nav-item dropdown">
            <a href="#" class="nav-link" id="settingsDropdown">
              <i class="fas fa-user-cog"></i>
            </a>
            <div class="dropdown-menu">
              <a href="logout.php" class="dropdown-item">
                <i class="fas fa-sign-out-alt"></i> Logout
              </a>
            </div>
          </li>
        </ul>
      </nav>
      
      <!-- Content Header -->
      
<!-- Content Header -->
<div class="content-header px-6 py-8 md:px-12 bg-gradient-to-r from-white to-gray-50 shadow-sm rounded-2xl border border-gray-200 animate-fadeInUp">

  <!-- Breadcrumbs -->
  <div class="flex items-center text-sm text-gray-500 mb-4 space-x-1">
    <a href="dashboard.php" class="text-blue-600 font-medium hover:underline">Home</a>
    <span>/</span>
    <span class="text-gray-700">Dashboard</span>
  </div>

  <!-- Greeting -->
  <h1 class="text-xl md:text-2xl font-bold text-gray-800 mb-2 leading-tight tracking-tight">
    👋 Hi, <span class="text-blue-600"><?php echo $admin ?>!</span>
  </h1>

  <!-- Date -->
  <p class="text-gray-500 text-base">
    <?php echo date("l, F d, Y"); ?>
  </p>

</div>
      <!-- Dashboard Cards -->
      <div class="dashboard-cards">
        <?php 
          $dashboard = $salu['dashboard'];
          if($dashboard == 1):
        ?>
        
        <!-- Today User Join -->
        <div class="card card-primary fade-in">
          <div class="card-header">
            <h3><i class="fas fa-users"></i> Today User Join</h3>
          </div>
          <div class="card-body">
            <div class="card-value">
              <?php
                $result = mysqli_query($conn,"SELECT count(*) as 'total_user' FROM shonu_subjects where status = 1 AND id NOT IN (SELECT balakedara FROM `demo` WHERE `sthiti`='1') AND DATE(createdate) = DATE('".$curdate."')");
                echo (mysqli_num_rows($result) > 0) ? mysqli_fetch_array($result)["total_user"] : "0";
              ?>
            </div>
          </div>
          <div class="card-footer">
            <a href="#">
              View Details <i class="fas fa-arrow-right"></i>
            </a>
          </div>
        </div>
        
        <!-- Today's Recharge -->
        <div class="card card-secondary fade-in">
          <div class="card-header">
            <h3><i class="fas fa-money-bill-wave"></i> Today's Recharge</h3>
          </div>
          <div class="card-body">
            <div class="card-value">
          ₹ <?php
                $result = mysqli_query($conn,"SELECT sum(motta) as 'pending' FROM thevani WHERE sthiti = '1' AND balakedara NOT IN (SELECT balakedara FROM `demo` WHERE `sthiti`='1') AND DATE(dinankavannuracisi) = DATE('".$curdate."')");
                echo (mysqli_num_rows($result) > 0) ? number_format(mysqli_fetch_array($result)["pending"], 0) : "0";
              ?>
            </div>
          </div>
          <div class="card-footer">
            <a href="#">
              View Details <i class="fas fa-arrow-right"></i>
            </a>
          </div>
        </div>
        
        <!-- Today's Withdrawal -->
        <div class="card card-danger fade-in">
          <div class="card-header">
            <h3><i class="fas fa-wallet"></i> Today's Withdrawal</h3>
          </div>
          <div class="card-body">
            <div class="card-value">
             ₹ <?php
                $result = mysqli_query($conn,"SELECT sum(motta) as 'succ_w' FROM hintegedukolli where sthiti = 1 AND balakedara NOT IN (SELECT balakedara FROM `demo` WHERE `sthiti`='1') AND DATE(dinankavannuracisi) = DATE('".$curdate."')");
                echo (mysqli_num_rows($result) > 0) ? number_format(mysqli_fetch_array($result)["succ_w"], 0) : "0";
              ?>
            </div>
          </div>
          <div class="card-footer">
            <a href="#">
              View Details <i class="fas fa-arrow-right"></i>
            </a>
          </div>
        </div>
        
        <!-- User Balance -->
        <div class="card card-warning fade-in">
          <div class="card-header">
            <h3><i class="fas fa-coins"></i> User Balance</h3>
          </div>
          <div class="card-body">
            <div class="card-value">
           ₹ <?php
                $result = mysqli_query($conn,"SELECT sum(motta) as 'wallt' FROM shonu_kaichila where balakedara NOT IN (SELECT balakedara FROM `demo` WHERE `sthiti`='1') AND motta > 0");
                echo (mysqli_num_rows($result) > 0) ? number_format(mysqli_fetch_array($result)["wallt"], 2) : "0";
              ?>
            </div>
          </div>
          <div class="card-footer">
            <a href="manage_user.php">
              View Details <i class="fas fa-arrow-right"></i>
            </a>
          </div>
        </div>
        
        <!-- Total Users -->
        <div class="card fade-in">
          <div class="card-header">
            <h3><i class="fas fa-user-friends"></i> Total Users</h3>
          </div>
          <div class="card-body">
            <div class="card-value">
              <?php
                $result = mysqli_query($conn,"SELECT count(*) as 'total_user' FROM shonu_subjects where id NOT IN (SELECT balakedara FROM `demo` WHERE `sthiti`='1') AND status = 1");
                echo (mysqli_num_rows($result) > 0) ? mysqli_fetch_array($result)["total_user"] : "0";
              ?>
            </div>
          </div>
          <div class="card-footer">
            <a href="manage_user.php">
              View Details <i class="fas fa-arrow-right"></i>
            </a>
          </div>
        </div>
        
        <!-- Pending Recharge -->
        <div class="card fade-in">
          <div class="card-header">
            <h3><i class="fas fa-clock"></i> Pending Recharge</h3>
          </div>
          <div class="card-body">
            <div class="card-value">
           ₹   <?php
                $result = mysqli_query($conn,"SELECT sum(motta) as '2' FROM thevani where balakedara NOT IN (SELECT balakedara FROM `demo` WHERE `sthiti`='1') AND sthiti = '0'");
                echo (mysqli_num_rows($result) > 0) ? number_format(mysqli_fetch_array($result)["2"], 0) : "0";
              ?>
            </div>
          </div>
          <div class="card-footer">
            <a href="deposit_update.php">
              View Details <i class="fas fa-arrow-right"></i>
            </a>
          </div>
        </div>
        
        <!-- Success Recharge -->
        <div class="card fade-in">
          <div class="card-header">
            <h3><i class="fas fa-check-circle"></i> Success Recharge</h3>
          </div>
          <div class="card-body">
            <div class="card-value">
            ₹  <?php
                $result = mysqli_query($conn,"SELECT sum(motta) as 'pending' FROM thevani where balakedara NOT IN (SELECT balakedara FROM `demo` WHERE `sthiti`='1') AND sthiti = '1'");
                echo (mysqli_num_rows($result) > 0) ? number_format(mysqli_fetch_array($result)["pending"], 0) : "0";
              ?>
            </div>
          </div>
          <div class="card-footer">
            <a href="deposit_update.php">
              View Details <i class="fas fa-arrow-right"></i>
            </a>
          </div>
        </div>
        
        <!-- Total Withdrawal -->
        <div class="card fade-in">
          <div class="card-header">
            <h3><i class="fas fa-hand-holding-usd"></i> Total Withdrawal</h3>
          </div>
          <div class="card-body">
            <div class="card-value">
           ₹   <?php
                $result = mysqli_query($conn,"SELECT sum(motta) as 'pending_w' FROM hintegedukolli where balakedara NOT IN (SELECT balakedara FROM `demo` WHERE `sthiti`='1') AND sthiti = '1'");
                echo (mysqli_num_rows($result) > 0) ? number_format(mysqli_fetch_array($result)["pending_w"], 0) : "0";
              ?>
            </div>
          </div>
          <div class="card-footer">
            <a href="withdraw_accept_list.php">
              View Details <i class="fas fa-arrow-right"></i>
            </a>
          </div>
        </div>
        
        <!-- Withdrawal Requests -->
        <div class="card fade-in">
          <div class="card-header">
            <h3><i class="fas fa-exchange-alt"></i> Withdrawal Requests</h3>
          </div>
          <div class="card-body">
            <div class="card-value">
           ₹   <?php
                $result = mysqli_query($conn,"SELECT sum(motta) as 'approve_withdrawal' FROM hintegedukolli where balakedara NOT IN (SELECT balakedara FROM `demo` WHERE `sthiti`='1') AND sthiti = '0'");
                echo (mysqli_num_rows($result) > 0) ? number_format(mysqli_fetch_array($result)["approve_withdrawal"], 0) : "0";
              ?>
            </div>
          </div>
          <div class="card-footer">
            <a href="manage_withdraw.php">
              View Details <i class="fas fa-arrow-right"></i>
            </a>
          </div>
        </div>
        
        <!-- Today's total bet -->
        <div class="card fade-in">
          <div class="card-header">
            <h3><i class="fas fa-chart-line"></i> Today's Total Bet</h3>
          </div>
          <div class="card-body">
            <div class="card-value">
             ₹ <?php
                $bet_wingo_1 = mysqli_fetch_assoc(mysqli_query($conn,"SELECT sum(ketebida) as total FROM `bajikattuttate` where byabaharkarta NOT IN (SELECT balakedara FROM `demo` WHERE `sthiti`='1') AND DATE(tiarikala) = DATE('".$curdate."')"));
                $bet_wingo_3 = mysqli_fetch_assoc(mysqli_query($conn,"SELECT sum(ketebida) as total FROM `bajikattuttate_drei` where byabaharkarta NOT IN (SELECT balakedara FROM `demo` WHERE `sthiti`='1') AND DATE(tiarikala) = DATE('".$curdate."')"));
                $bet_wingo_5 = mysqli_fetch_assoc(mysqli_query($conn,"SELECT sum(ketebida) as total FROM `bajikattuttate_funf` where byabaharkarta NOT IN (SELECT balakedara FROM `demo` WHERE `sthiti`='1') AND DATE(tiarikala) = DATE('".$curdate."')"));
                $bet_wingo_10 = mysqli_fetch_assoc(mysqli_query($conn,"SELECT sum(ketebida) as total FROM `bajikattuttate_zehn` where byabaharkarta NOT IN (SELECT balakedara FROM `demo` WHERE `sthiti`='1') AND DATE(tiarikala) = DATE('".$curdate."')"));
                $bet_k3_1 = mysqli_fetch_assoc(mysqli_query($conn,"SELECT sum(ketebida) as total FROM `bajikattuttate_kemuru` where byabaharkarta NOT IN (SELECT balakedara FROM `demo` WHERE `sthiti`='1') AND DATE(tiarikala) = DATE('".$curdate."')"));
                $bet_k3_3 = mysqli_fetch_assoc(mysqli_query($conn,"SELECT sum(ketebida) as total FROM `bajikattuttate_kemuru_drei` where byabaharkarta NOT IN (SELECT balakedara FROM `demo` WHERE `sthiti`='1') AND DATE(tiarikala) = DATE('".$curdate."')"));
                $bet_k3_5 = mysqli_fetch_assoc(mysqli_query($conn,"SELECT sum(ketebida) as total FROM `bajikattuttate_kemuru_funf` where byabaharkarta NOT IN (SELECT balakedara FROM `demo` WHERE `sthiti`='1') AND DATE(tiarikala) = DATE('".$curdate."')"));
                $bet_k3_10 = mysqli_fetch_assoc(mysqli_query($conn,"SELECT sum(ketebida) as total FROM `bajikattuttate_kemuru_zehn` where byabaharkarta NOT IN (SELECT balakedara FROM `demo` WHERE `sthiti`='1') AND DATE(tiarikala) = DATE('".$curdate."')"));
                $bet_5d_1 = mysqli_fetch_assoc(mysqli_query($conn,"SELECT sum(ketebida) as total FROM `bajikattuttate_aidudi` where byabaharkarta NOT IN (SELECT balakedara FROM `demo` WHERE `sthiti`='1') AND DATE(tiarikala) = DATE('".$curdate."')"));
                $bet_5d_3 = mysqli_fetch_assoc(mysqli_query($conn,"SELECT sum(ketebida) as total FROM `bajikattuttate_aidudi_drei` where byabaharkarta NOT IN (SELECT balakedara FROM `demo` WHERE `sthiti`='1') AND DATE(tiarikala) = DATE('".$curdate."')"));
                $bet_5d_5 = mysqli_fetch_assoc(mysqli_query($conn,"SELECT sum(ketebida) as total FROM `bajikattuttate_aidudi_funf` where byabaharkarta NOT IN (SELECT balakedara FROM `demo` WHERE `sthiti`='1') AND DATE(tiarikala) = DATE('".$curdate."')"));
                $bet_5d_10 = mysqli_fetch_assoc(mysqli_query($conn,"SELECT sum(ketebida) as total FROM `bajikattuttate_aidudi_zehn` where byabaharkarta NOT IN (SELECT balakedara FROM `demo` WHERE `sthiti`='1') AND DATE(tiarikala) = DATE('".$curdate."')"));
                $total_bet = $bet_wingo_1['total'] + $bet_wingo_3['total'] + $bet_wingo_5['total'] + $bet_wingo_10['total'] + $bet_k3_1['total'] + $bet_k3_3['total'] + $bet_k3_5['total'] + $bet_k3_10['total'] + $bet_5d_1['total'] + $bet_5d_3['total'] + $bet_5d_5['total'] + $bet_5d_10['total'];
                $asila = $total_bet;
                echo number_format($total_bet, 2);
              ?>
            </div>
          </div>
        </div>
        
        <!-- Today's total win -->
        <div class="card fade-in">
          <div class="card-header">
            <h3><i class="fas fa-trophy"></i> Today's Total Win</h3>
          </div>
          <div class="card-body">
            <div class="card-value">
            ₹  <?php
                $bet_wingo_1 = mysqli_fetch_assoc(mysqli_query($conn,"SELECT sum(sesabida) as total FROM `bajikattuttate` where `phalaphala` = 'gagner' AND byabaharkarta NOT IN (SELECT balakedara FROM `demo` WHERE `sthiti`='1') AND DATE(tiarikala) = DATE('".$curdate."')"));
                $bet_wingo_3 = mysqli_fetch_assoc(mysqli_query($conn,"SELECT sum(sesabida) as total FROM `bajikattuttate_drei` where `phalaphala` = 'gagner' AND byabaharkarta NOT IN (SELECT balakedara FROM `demo` WHERE `sthiti`='1') AND DATE(tiarikala) = DATE('".$curdate."')"));
                $bet_wingo_5 = mysqli_fetch_assoc(mysqli_query($conn,"SELECT sum(sesabida) as total FROM `bajikattuttate_funf` where `phalaphala` = 'gagner' AND byabaharkarta NOT IN (SELECT balakedara FROM `demo` WHERE `sthiti`='1') AND DATE(tiarikala) = DATE('".$curdate."')"));
                $bet_wingo_10 = mysqli_fetch_assoc(mysqli_query($conn,"SELECT sum(sesabida) as total FROM `bajikattuttate_zehn` where `phalaphala` = 'gagner' AND byabaharkarta NOT IN (SELECT balakedara FROM `demo` WHERE `sthiti`='1') AND DATE(tiarikala) = DATE('".$curdate."')"));
                $bet_k3_1 = mysqli_fetch_assoc(mysqli_query($conn,"SELECT sum(sesabida) as total FROM `bajikattuttate_kemuru` where `phalaphala` = 'gagner' AND byabaharkarta NOT IN (SELECT balakedara FROM `demo` WHERE `sthiti`='1') AND DATE(tiarikala) = DATE('".$curdate."')"));
                $bet_k3_3 = mysqli_fetch_assoc(mysqli_query($conn,"SELECT sum(sesabida) as total FROM `bajikattuttate_kemuru_drei` where `phalaphala` = 'gagner' AND byabaharkarta NOT IN (SELECT balakedara FROM `demo` WHERE `sthiti`='1') AND DATE(tiarikala) = DATE('".$curdate."')"));
                $bet_k3_5 = mysqli_fetch_assoc(mysqli_query($conn,"SELECT sum(sesabida) as total FROM `bajikattuttate_kemuru_funf` where `phalaphala` = 'gagner' AND byabaharkarta NOT IN (SELECT balakedara FROM `demo` WHERE `sthiti`='1') AND DATE(tiarikala) = DATE('".$curdate."')"));
                $bet_k3_10 = mysqli_fetch_assoc(mysqli_query($conn,"SELECT sum(sesabida) as total FROM `bajikattuttate_kemuru_zehn` where `phalaphala` = 'gagner' AND byabaharkarta NOT IN (SELECT balakedara FROM `demo` WHERE `sthiti`='1') AND DATE(tiarikala) = DATE('".$curdate."')"));
                $bet_5d_1 = mysqli_fetch_assoc(mysqli_query($conn,"SELECT sum(sesabida) as total FROM `bajikattuttate_aidudi` where `phalaphala` = 'gagner' AND byabaharkarta NOT IN (SELECT balakedara FROM `demo` WHERE `sthiti`='1') AND DATE(tiarikala) = DATE('".$curdate."')"));
                $bet_5d_3 = mysqli_fetch_assoc(mysqli_query($conn,"SELECT sum(sesabida) as total FROM `bajikattuttate_aidudi_drei` where `phalaphala` = 'gagner' AND byabaharkarta NOT IN (SELECT balakedara FROM `demo` WHERE `sthiti`='1') AND DATE(tiarikala) = DATE('".$curdate."')"));
                $bet_5d_5 = mysqli_fetch_assoc(mysqli_query($conn,"SELECT sum(sesabida) as total FROM `bajikattuttate_aidudi_funf` where `phalaphala` = 'gagner' AND byabaharkarta NOT IN (SELECT balakedara FROM `demo` WHERE `sthiti`='1') AND DATE(tiarikala) = DATE('".$curdate."')"));
                $bet_5d_10 = mysqli_fetch_assoc(mysqli_query($conn,"SELECT sum(sesabida) as total FROM `bajikattuttate_aidudi_zehn` where `phalaphala` = 'gagner' AND byabaharkarta NOT IN (SELECT balakedara FROM `demo` WHERE `sthiti`='1') AND DATE(tiarikala) = DATE('".$curdate."')"));
                $total_bet = $bet_wingo_1['total'] + $bet_wingo_3['total'] + $bet_wingo_5['total'] + $bet_wingo_10['total'] + $bet_k3_1['total'] + $bet_k3_3['total'] + $bet_k3_5['total'] + $bet_k3_10['total'] + $bet_5d_1['total'] + $bet_5d_3['total'] + $bet_5d_5['total'] + $bet_5d_10['total'];
                $gala = $total_bet;
                echo number_format($total_bet, 2);
              ?>
            </div>
          </div>
        </div>
        
        <!-- Today's profit -->
        <div class="card fade-in">
          <div class="card-header">
            <h3><i class="fas fa-chart-pie"></i> Today's Profit</h3>
          </div>
          <div class="card-body">
            <div class="card-value">
          ₹    <?php
                $amount = $asila - $gala;
                echo round($amount, 2);
              ?>
            </div>
          </div>
        </div>
        
        <?php endif; ?>
      </div>
      
      <!-- Footer -->
<footer class="footer w-full bg-gradient-to-r from-slate-50 to-slate-100 border-t border-slate-200 shadow-sm py-4 px-6 fade-in">
  <div class="max-w-screen-xl mx-auto text-center">
    <span class="text-sm text-slate-500">
      Powered by <strong class="text-blue-900 font-semibold">RAHUL CODER Admin</strong>
    </span>
  </div>
</footer>
    </div>
  </div>

  <!-- JavaScript -->
  <script>
    // Toggle sidebar on mobile
    document.getElementById('sidebarToggle').addEventListener('click', function(e) {
      e.preventDefault();
      document.querySelector('.sidebar').classList.toggle('show');
    });
    
    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', function(e) {
      const sidebar = document.querySelector('.sidebar');
      const sidebarToggle = document.getElementById('sidebarToggle');
      
      if (window.innerWidth <= 992) {
        if (!sidebar.contains(e.target) && !sidebarToggle.contains(e.target)) {
          sidebar.classList.remove('show');
        }
      }
    });
    
    // Toggle dropdown menu
    document.getElementById('settingsDropdown').addEventListener('click', function(e) {
      e.preventDefault();
      document.querySelector('.dropdown-menu').classList.toggle('show');
    });
    
    // Close dropdown when clicking outside
    document.addEventListener('click', function(e) {
      if (!e.target.closest('.nav-item.dropdown')) {
        document.querySelector('.dropdown-menu').classList.remove('show');
      }
    });
    
    // Toggle submenus in sidebar - FIXED VERSION
    document.querySelectorAll('.sidebar-menu .has-submenu > a').forEach(item => {
      item.addEventListener('click', function(e) {
        e.preventDefault();
        const parent = this.parentElement;
        const submenu = this.nextElementSibling;
        
        // Close all other submenus
        document.querySelectorAll('.sidebar-menu .submenu').forEach(menu => {
          if (menu !== submenu) {
            menu.classList.remove('active');
            menu.previousElementSibling.classList.remove('active');
          }
        });
        
        // Toggle current submenu
        parent.classList.toggle('active');
        submenu.classList.toggle('active');
      });
    });
    
    // Auto-close notifications
    function showNotification(message, type) {
      const notification = document.createElement('div');
      notification.className = `notification ${type}`;
      notification.innerHTML = `
        <i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'}"></i>
        <span>${message}</span>
      `;
      
      document.body.appendChild(notification);
      
      setTimeout(() => {
        notification.classList.add('show');
      }, 10);
      
      setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
          notification.remove();
        }, 500);
      }, 3000);
    }
    
    // Check for URL messages to show notifications
    const urlParams = new URLSearchParams(window.location.search);
    const msg = urlParams.get('msg');
    
    if (msg === 'unauthorized') {
      showNotification('Unauthorized access! Please login.', 'error');
    }
  </script>
</body>
</html>