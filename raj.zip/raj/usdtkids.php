<?php
session_start();
if ($_SESSION['unohs'] == null) {
    header("location:index.php?msg=unauthorized");
}
date_default_timezone_set("Asia/Kolkata");
include("conn.php");

// Generate unique token for form
if (!isset($_SESSION['form_token'])) {
    $_SESSION['form_token'] = bin2hex(random_bytes(32));
}

$query = "SELECT rate FROM tbl_pg WHERE value = 'usdt' LIMIT 1";
$result = mysqli_query($conn, $query);
$currentRate = 0;
if ($result && mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $currentRate = $row['rate'];
}

if (isset($_POST['newupi']) && isset($_POST['form_token']) && $_POST['form_token'] === $_SESSION['form_token']) {
    $newRate = mysqli_real_escape_string($conn, $_POST['newupi']);
    
    if (!is_numeric($newRate)) {
        $_SESSION['toast'] = [
            'type' => 'error',
            'message' => 'Invalid USDT rate. Please enter a valid number'
        ];
    } else {
        $sql_q = "UPDATE tbl_pg SET rate='" . $newRate . "' WHERE value = 'usdt'";
        $chk = mysqli_query($conn, $sql_q);
        
        if($chk){
            $_SESSION['toast'] = [
                'type' => 'success',
                'message' => 'USDT rate updated successfully'
            ];
            // Regenerate token after successful submission
            $_SESSION['form_token'] = bin2hex(random_bytes(32));
            header("Location: ".$_SERVER['PHP_SELF']);
            exit();
        } else {
            $_SESSION['toast'] = [
                'type' => 'error',
                'message' => 'Failed to update USDT rate'
            ];
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>USDT Rate Management</title>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="css/common.css" rel="stylesheet">
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    :root {
      --primary: #3498db;
      --primary-light: #5dade2;
      --primary-dark: #2874a6;
      --secondary: #2ecc71;
      --secondary-dark: #27ae60;
      --danger: #e74c3c;
      --warning: #f39c12;
      --info: #1abc9c;
      --dark: #2c3e50;
      --light: #ecf0f1;
      --gray: #bdc3c7;
      --white: #ffffff;
      --sidebar-bg: #2c3e50;
      --sidebar-text: #ecf0f1;
      --sidebar-active: rgba(52, 152, 219, 0.2);
      --sidebar-submenu: #34495e;
      --card-shadow: 0 2px 8px rgba(52, 152, 219, 0.1);
      --transition: all 0.2s ease;
    }
    
    body {
      font-family: 'Poppins', sans-serif;
      background-color: #f5f7fa;
      color: var(--dark);
      line-height: 1.5;
      margin: 0;
      padding: 0;
      overflow-x: hidden;
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }
    
    .wrapper {
      display: flex;
      flex: 1;
    }
    
    /* Sidebar Styles */
    .sidebar {
      width: 220px;
      background: var(--sidebar-bg);
      position: fixed;
      height: 100vh;
      z-index: 1000;
      overflow-y: auto;
      transform: translateX(-100%);
      transition: transform 0.3s ease;
    }
    
    .sidebar.show {
      transform: translateX(0);
    }
    
    /* Main Content Styles */
    .main-content {
      flex: 1;
      margin-left: 0;
      transition: var(--transition);
      background-color: var(--white);
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }
    
    .content-area {
      flex: 1;
      padding-bottom: 60px; /* Footer height */
    }
    
    /* Navbar Styles */
    .navbar {
      background: var(--white);
      padding: 0.6rem 1rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
      position: sticky;
      top: 0;
      z-index: 999;
      border-bottom: 1px solid var(--light);
      height: 60px;
    }
    
    .navbar-brand {
      display: flex;
      align-items: center;
      color: var(--dark);
      font-size: 0.9rem;
      font-weight: 600;
    }
    
    .navbar-brand i {
      margin-right: 0.5rem;
      color: var(--primary);
    }
    
    /* Form Styles */
    .form-container {
      background: var(--white);
      padding: 1.5rem;
      border-radius: 0.5rem;
      box-shadow: var(--card-shadow);
      margin: 1rem;
      border: 1px solid rgba(52, 152, 219, 0.1);
    }
    
    .form-container h3 {
      color: var(--dark);
      margin-bottom: 1.5rem;
      font-weight: 600;
      display: flex;
      align-items: center;
      gap: 10px;
      font-size: 1.1rem;
    }
    
    .form-group {
      margin-bottom: 1rem;
    }
    
    .form-group label {
      display: block;
      margin-bottom: 0.5rem;
      font-weight: 500;
      color: var(--dark);
      font-size: 0.9rem;
    }
    
    .form-control {
      width: 100%;
      padding: 0.75rem;
      border: 1px solid var(--light);
      border-radius: 0.375rem;
      font-size: 0.9rem;
      transition: all 0.3s ease;
      height: 45px;
    }
    
    .form-control:focus {
      border-color: var(--primary);
      box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.1);
      outline: none;
    }
    
    /* Button Styles */
    .btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: 0.75rem 1.5rem;
      border-radius: 0.375rem;
      font-weight: 500;
      font-size: 0.9rem;
      line-height: 1.5;
      cursor: pointer;
      transition: all 0.3s ease;
      border: none;
    }
    
    .btn-primary {
      background-color: var(--primary);
      color: white;
    }
    
    .btn-primary:hover {
      background-color: var(--primary-dark);
      transform: translateY(-1px);
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }
    
    /* Toast Styles */
    #toast-container {
      position: fixed;
      bottom: 20px;
      right: 20px;
      z-index: 9999;
    }
    
    .toast {
      min-width: 300px;
      padding: 15px 20px;
      margin-bottom: 10px;
      border-radius: 8px;
      color: white;
      font-size: 14px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      animation: slideIn 0.3s, fadeOut 0.5s 2.5s forwards;
      transform: translateX(0);
    }
    
    .toast-success {
      background-color: var(--secondary);
    }
    
    .toast-error {
      background-color: var(--danger);
    }
    
    .toast-close {
      background: none;
      border: none;
      color: white;
      cursor: pointer;
      margin-left: 15px;
      font-size: 1rem;
    }
    
    @keyframes slideIn {
      from { transform: translateX(100%); opacity: 0; }
      to { transform: translateX(0); opacity: 1; }
    }
    
    @keyframes fadeOut {
      from { opacity: 1; }
      to { opacity: 0; }
    }
    
    /* Content Header */
    
    .content-header {
  padding: 0.75rem 1.25rem;
  background: linear-gradient(to right, #ffffff, #f1f3f5);
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.06);
  border-radius: 0.375rem;
  border: 1px solid #e0e0e0;
  margin: 1rem;
  transition: all 0.3s ease;
}

.content-header h1 {
  font-size: 1rem; /* Smaller title size */
  margin: 0;
  font-weight: 600;
  color: #343a40;
}

.breadcrumb {
  font-size: 0.75rem;
  color: #6c757d;
  margin-bottom: 0;
}

.breadcrumb a {
  color: #4f46e5;
  font-weight: 500;
  text-decoration: none;
  transition: color 0.2s ease-in-out;
}

.breadcrumb a:hover {
  color: #3730a3;
}
    .current-rate {
      font-size: 1.2rem;
      font-weight: 600;
      color: var(--primary);
      margin: 10px 0;
    }
    
    /* Footer Styles */
    .footer {
      width: 100%;
      background: linear-gradient(to right, #f8f9fa, #e9ecef);
      border-top: 1px solid var(--light);
      padding: 1rem;
      text-align: center;
      position: relative;
      bottom: 0;
    }
    
    /* Dropdown Menu */
    .dropdown-menu {
      position: absolute;
      right: 0;
      top: 100%;
      background: var(--white);
      border-radius: 0.3rem;
      box-shadow: var(--card-shadow);
      min-width: 160px;
      padding: 0.3rem 0;
      opacity: 0;
      visibility: hidden;
      transition: var(--transition);
      z-index: 1000;
      border: 1px solid var(--light);
    }
    
    .dropdown-menu.show {
      opacity: 1;
      visibility: visible;
    }
    
    .dropdown-item {
      padding: 0.5rem 1rem;
      color: var(--dark);
      display: flex;
      align-items: center;
      transition: var(--transition);
      font-size: 0.8rem;
    }
    
    .dropdown-item:hover {
      background: rgba(52, 152, 219, 0.05);
      color: var(--primary);
    }
    
    .dropdown-item i {
      margin-right: 0.5rem;
      font-size: 0.8rem;
      color: var(--primary);
    }
    
    /* Responsive Styles */
    @media (min-width: 768px) {
      .sidebar {
        transform: translateX(0);
      }
      
      .main-content {
        margin-left: 220px;
      }
    }
  </style>
</head>

<body>
  <div class="wrapper">
    <?php include('compass.php'); ?>
  
    <!-- Main Content -->
    <div class="main-content">
      <!-- Navbar -->
      <nav class="navbar">
        <a href="#" class="navbar-brand" id="sidebarToggle">
          <i class="fas fa-bars"></i>
          <span>Menu</span>
        </a>
        
        <ul class="navbar-nav">
          <li class="nav-item dropdown">
            <a href="#" class="nav-link" id="settingsDropdown">
              <i class="fas fa-user-cog"></i>
            </a>
            <div class="dropdown-menu" id="settingsMenu">
              <a href="logout.php" class="dropdown-item">
                <i class="fas fa-sign-out-alt"></i> Logout
              </a>
            </div>
          </li>
        </ul>
      </nav>
      
      <!-- Content Area -->
      <div class="content-area">
        <!-- Content Header -->
        <div class="content-header">
          <div class="breadcrumb">
            <a href="dashboard.php">Home</a> / USDT Rate
          </div>
          <h1 class="text-xl font-bold text-gray-800">Update USDT Rate</h1>
          <p class="text-gray-500 text-sm">
            <?php echo date("l, F d, Y"); ?>
          </p>
        </div>
        
        <!-- Form Container -->
        <div class="form-container">
          <h3><i class="fas fa-coins text-blue-500"></i> Current USDT Rate</h3>
          <div class="current-rate">
            Current Rate: ₹<?php echo htmlspecialchars($currentRate); ?>
          </div>
          <form action="#" id="rateForm" method="post" autocomplete="off">
            <input type="hidden" name="form_token" value="<?php echo $_SESSION['form_token']; ?>">
            
            <div class="form-group">
              <label>New USDT Rate (₹)</label>
              <input name="newupi" type="text" placeholder="Enter new USDT rate" required class="form-control" />
              <p class="text-xs text-gray-500 mt-1">Enter the new exchange rate for USDT to INR</p>
            </div>
            <button type="submit" class="btn btn-primary" id="submitBtn">
              <i class="fas fa-sync-alt mr-2"></i> Update Rate
            </button>
          </form>
        </div>
      </div>
      
      <!-- Footer -->
      <footer class="footer">
        <div class="max-w-screen-xl mx-auto text-center">
          <span class="text-sm text-slate-500">
            Powered by <strong class="text-blue-900 font-semibold">RAJVEER CODER Admin</strong>
          </span>
        </div>
      </footer>
    </div>
  </div>

  <!-- Toast Container -->
  <div id="toast-container"></div>

  <!-- JavaScript -->
  <script>
    // Toggle sidebar on mobile
    document.getElementById('sidebarToggle').addEventListener('click', function(e) {
      e.preventDefault();
      document.querySelector('.sidebar').classList.toggle('show');
    });
    
    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', function(e) {
      const sidebar = document.querySelector('.sidebar');
      const sidebarToggle = document.getElementById('sidebarToggle');
      
      if (window.innerWidth <= 768) {
        if (!sidebar.contains(e.target) && !sidebarToggle.contains(e.target)) {
          sidebar.classList.remove('show');
        }
      }
    });
    
    // Toggle dropdown menu
    const settingsDropdown = document.getElementById('settingsDropdown');
    const settingsMenu = document.getElementById('settingsMenu');
    
    if (settingsDropdown && settingsMenu) {
      settingsDropdown.addEventListener('click', function(e) {
        e.preventDefault();
        settingsMenu.classList.toggle('show');
      });
      
      // Close dropdown when clicking outside
      document.addEventListener('click', function(e) {
        if (!e.target.closest('.nav-item.dropdown')) {
          settingsMenu.classList.remove('show');
        }
      });
    }
    
    // Toggle submenus in sidebar
    const submenuItems = document.querySelectorAll('.sidebar-menu .has-submenu > a');
    if (submenuItems) {
      submenuItems.forEach(item => {
        item.addEventListener('click', function(e) {
          e.preventDefault();
          const parent = this.parentElement;
          const submenu = this.nextElementSibling;
          
          // Close all other submenus
          document.querySelectorAll('.sidebar-menu .submenu').forEach(menu => {
            if (menu !== submenu) {
              menu.classList.remove('active');
              menu.previousElementSibling.classList.remove('active');
            }
          });
          
          // Toggle current submenu
          parent.classList.toggle('active');
          submenu.classList.toggle('active');
        });
      });
    }
    
    // Form validation and submission handling
    document.getElementById('rateForm').addEventListener('submit', function(e) {
      e.preventDefault();
      const rateInput = this.querySelector('input[name="newupi"]');
      const rateValue = rateInput.value.trim();
      const submitBtn = document.getElementById('submitBtn');
      
      if (!/^\d+(\.\d{1,2})?$/.test(rateValue)) {
        showToast('Invalid USDT rate. Please enter a valid number', 'error');
        rateInput.focus();
        return;
      }
      
      // Disable button to prevent double submission
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Updating...';
      
      // Submit form
      this.submit();
    });
    
    // Show toast notification
    function showToast(message, type) {
      const toastContainer = document.getElementById('toast-container');
      const toast = document.createElement('div');
      toast.className = `toast toast-${type}`;
      toast.innerHTML = `
        <span>${message}</span>
        <button class="toast-close" onclick="this.parentElement.remove()">&times;</button>
      `;
      toastContainer.appendChild(toast);
      
      // Auto remove after 3 seconds
      setTimeout(() => {
        toast.remove();
      }, 3000);
    }
    
    // Show any server-side toast messages
    <?php if (isset($_SESSION['toast'])): ?>
      document.addEventListener('DOMContentLoaded', function() {
        showToast('<?php echo $_SESSION['toast']['message']; ?>', '<?php echo $_SESSION['toast']['type']; ?>');
      });
      <?php unset($_SESSION['toast']); ?>
    <?php endif; ?>
  </script>
</body>
</html>