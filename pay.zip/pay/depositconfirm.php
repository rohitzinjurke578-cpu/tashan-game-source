<?php include ("../serive/samparka.php");?>
<?php 
    if(isset($_GET['amt'])){
    $amt = $_GET['amt'];
    } else{
        $amt = 0;
    }
    if(isset($_GET['refnum'])){
    $refnum = $_GET['refnum'];
    } else{
        $refnum = 0;
    }
    if(isset($_GET['srl'])){
    $srl = $_GET['srl'];
    } else{
        $srl = 0;
    }
?>
<?php 
    $res = [
        'code' => 405,
        'message' => 'Illegal access!',
    ];
    
    if (isset($_GET['userId']) && isset($_GET['token'])) {
        $userId = htmlspecialchars(mysqli_real_escape_string($conn, $_GET['userId']));
        $userPhoto = '1';
        
        $numquery = "SELECT mobile, codechorkamukala
          FROM shonu_subjects
          WHERE id = ".$userId;
        $numresult = $conn->query($numquery);
        $numarr = mysqli_fetch_array($numresult);
        
        $userName = '91'.$numarr['mobile'];
        $nickName = $numarr['codechorkamukala'];
        
        $creaquery = "SELECT createdate
          FROM shonu_subjects
          WHERE id = ".$userId;
        $crearesult = $conn->query($creaquery);
        $creaarr = mysqli_fetch_array($crearesult);
        
        $knbdstr = '{"userId":'.$userId.',"userPhoto":"'.$userPhoto.'","userName":'.$userName.',"nickName":"'.$nickName.'","createdate":"'.$creaarr['createdate'].'"}';
        $shonusign = strtoupper(hash('sha256', $knbdstr));
        
        $token = htmlspecialchars(mysqli_real_escape_string($conn, $_GET['token']));
        
        if($shonusign == $token){
?>
            <!DOCTYPE html>
            <html lang="en">
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>Payment Confirmation | Transaction Processing</title>
                    <link rel="preconnect" href="https://fonts.googleapis.com">
                    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
                    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
                    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
                    <style>
                        :root {
                            --primary: #4361ee;
                            --primary-light: #eef2ff;
                            --success: #22c55e;
                            --warning: #f59e0b;
                            --danger: #ef4444;
                            --dark: #1e293b;
                            --light: #f8fafc;
                            --gray: #94a3b8;
                            --gray-dark: #64748b;
                        }
                        
                        * {
                            margin: 0;
                            padding: 0;
                            box-sizing: border-box;
                        }
                        
                        html, body {
                            height: 100%;
                            width: 100%;
                            font-family: 'Inter', sans-serif;
                            background-color: #f1f5f9;
                            color: var(--dark);
                            line-height: 1.6;
                        }
                        
                        .container {
                            min-height: 100vh;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            padding: 0rem;
                        }
                        
                        .payment-card {
                            background: white;
                            border-radius: 0rem;
                            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
                            overflow: hidden;
                            padding: 2rem;
                            text-align: center;
                            position: relative;
                            width: 100%;
                            max-width: 500px;
                        }
                        
                        .payment-header {
                            margin-bottom: 2rem;
                        }
                        
                        .payment-icon {
                            width: 80px;
                            height: 80px;
                            background-color: var(--primary-light);
                            border-radius: 50%;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            margin: 0 auto 1.5rem;
                        }
                        
                        .payment-icon i {
                            font-size: 2.5rem;
                            color: var(--primary);
                        }
                        
                        .payment-title {
                            font-size: 1.5rem;
                            font-weight: 600;
                            margin-bottom: 0.5rem;
                        }
                        
                        .payment-subtitle {
                            color: var(--gray-dark);
                            font-size: 0.9rem;
                        }
                        
                        .payment-amount {
                            font-size: 2.5rem;
                            font-weight: 700;
                            margin: 1.5rem 0;
                            color: var(--primary);
                            position: relative;
                            display: inline-block;
                        }
                        
                        .payment-amount::before {
                            content: '₹';
                            font-size: 1.5rem;
                            position: relative;
                            top: -0.5rem;
                            margin-right: 0.25rem;
                        }
                        
                        .payment-details {
                            text-align: left;
                            margin: 2rem 0;
                            border-top: 1px solid #e2e8f0;
                            padding-top: 1.5rem;
                            font-size: 13px;
                        }
                        
                        .detail-item {
                            display: flex;
                            justify-content: space-between;
                            margin-bottom: 1rem;
                            word-break: break-all;
                        }
                        
                        .detail-label {
                            color: var(--gray-dark);
                            font-weight: 500;
                            flex: 0 0 120px;
                        }
                        
                        .detail-value {
                            font-weight: 600;
                            text-align: right;
                            flex: 1;
                            padding-left: 1rem;
                        }
                        
                        .payment-status {
                            background-color: var(--primary-light);
                            padding: 1.5rem;
                            border-radius: 0.75rem;
                            margin: 1.5rem 0;
                            text-align: center;
                        }
                        
                        .status-title {
                            font-weight: 600;
                            margin-bottom: 0.5rem;
                        }
                        
                        .status-description {
                            color: var(--gray-dark);
                            font-size: 0.9rem;
                        }
                        
                        .payment-timer {
                            display: flex;
                            justify-content: center;
                            align-items: center;
                            gap: 0.5rem;
                            margin: 1rem 0;
                            font-size: 1.1rem;
                            font-weight: 600;
                        }
                        
                        .timer-segment {
                            background-color: var(--dark);
                            color: white;
                            padding: 0.5rem 0.75rem;
                            border-radius: 0.5rem;
                            min-width: 50px;
                            text-align: center;
                        }
                        
                        .timer-label {
                            font-size: 0.6rem;
                            margin-top: 0.25rem;
                            color: var(--gray-dark);
                        }
                        
                        .btn {
                            display: inline-flex;
                            align-items: center;
                            justify-content: center;
                            padding: 0.75rem 1.5rem;
                            border-radius: 0.75rem;
                            font-weight: 600;
                            cursor: pointer;
                            transition: all 0.2s;
                            border: none;
                            width: 100%;
                            font-size: 1rem;
                        }
                        
                        .btn-primary {
                            background-color: var(--primary);
                            color: white;
                        }
                        
                        .btn-primary:hover {
                            background-color: #3a56d4;
                        }
                        
                        .btn-loading {
                            opacity: 0.8;
                            cursor: not-allowed;
                        }
                        
                        .btn-loading i {
                            animation: spin 1s linear infinite;
                            margin-right: 0.5rem;
                        }
                        
                        @keyframes spin {
                            from { transform: rotate(0deg); }
                            to { transform: rotate(360deg); }
                        }
                        
                        .progress-container {
                            width: 100%;
                            height: 6px;
                            background-color: #e2e8f0;
                            border-radius: 3px;
                            margin: 1.5rem 0;
                            overflow: hidden;
                        }
                        
                        .progress-bar {
                            height: 100%;
                            width: 60%;
                            background-color: var(--primary);
                            border-radius: 3px;
                            animation: progress 2s ease-in-out infinite;
                            background-image: linear-gradient(
                                45deg,
                                rgba(255, 255, 255, 0.15) 25%,
                                transparent 25%,
                                transparent 50%,
                                rgba(255, 255, 255, 0.15) 50%,
                                rgba(255, 255, 255, 0.15) 75%,
                                transparent 75%,
                                transparent
                            );
                            background-size: 1rem 1rem;
                        }
                        
                        @keyframes progress {
                            0% { background-position: 1rem 0; }
                            100% { background-position: 0 0; }
                        }

                        /* Toast styles */
                        .toast {
                            position: fixed;
                            bottom: 20px;
                            left: 50%;
                            transform: translateX(-50%);
                            background-color: white;
                            color: var(--dark);
                            padding: 1rem 1.5rem;
                            border-radius: 0.5rem;
                            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
                            display: flex;
                            align-items: center;
                            gap: 1rem;
                            z-index: 1000;
                            opacity: 0;
                            transition: all 0.3s ease;
                            max-width: 90%;
                            width: max-content;
                        }
                        
                        .toast.show {
                            opacity: 1;
                            bottom: 30px;
                        }
                        
                        .toast-success {
                            border-left: 4px solid var(--success);
                        }
                        
                        .toast-error {
                            border-left: 4px solid var(--danger);
                        }
                        
                        .toast-warning {
                            border-left: 4px solid var(--warning);
                        }
                        
                        .toast-icon {
                            font-size: 1.5rem;
                        }
                        
                        .toast-success .toast-icon {
                            color: var(--success);
                        }
                        
                        .toast-error .toast-icon {
                            color: var(--danger);
                        }
                        
                        .toast-warning .toast-icon {
                            color: var(--warning);
                        }
                        
                        .toast-message {
                            font-weight: 500;
                        }
                    </style>
                </head>
                <body>
                    <div class="container">
                        <div class="payment-card">
                            <div class="payment-header">
                                <div class="payment-icon">
                                    <i class="fas fa-clock"></i>
                                </div>
                                <h1 class="payment-title">Payment In Review</h1>
                                <p class="payment-subtitle">We're verifying your transaction</p>
                            </div>
                            
                            <div class="payment-amount"><?php echo $amt; ?></div>
                            
                            <div class="progress-container">
                                <div class="progress-bar"></div>
                            </div>
                            
                            <div class="payment-timer">
                                <div>
                                    <div class="timer-segment" id="_m">30m</div>
                                    <div class="timer-label">Minutes</div>
                                </div>
                                <div>
                                    <div class="timer-segment" id="_s">00s</div>
                                    <div class="timer-label">Seconds</div>
                                </div>
                            </div>
                            
                            <div class="payment-details">
                                <div class="detail-item">
                                    <span class="detail-label">UTR / Ref No</span>
                                    <span class="detail-value"><?php echo $refnum; ?></span>
                                </div>
                                <div class="detail-item">
                                    <span class="detail-label">Transaction No</span>
                                    <span class="detail-value"><?php echo $srl; ?></span>
                                </div>
                                <div class="detail-item">
                                    <span class="detail-label">User ID</span>
                                    <span class="detail-value"><?php echo $userId; ?></span>
                                </div>
                            </div>
                            
                            <div class="payment-status">
                                <h3 class="status-title">Transaction in Progress</h3>
                                <p class="status-description">Your transfer is being confirmed. This usually takes less than 30 minutes.</p>
                            </div>
                            
                            <button class="btn btn-primary btn-loading">
                                <i class="fas fa-spinner"></i> Confirming Payment
                            </button>
                        </div>
                    </div>

                    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
                    <script>
                        var base_url = '';
                        var order_no = "ApOGapJbJkm6";
                        var refNo = "<?php echo $refnum; ?>";
                        
                        var userId = "<?php echo $userId; ?>";
                        var token = "<?php echo $token; ?>";

                        // Set cookie for timer persistence
                        function setCookie(name, value, minutes) {
                            var expires = "";
                            if (minutes) {
                                var date = new Date();
                                date.setTime(date.getTime() + (minutes * 60 * 1000));
                                expires = "; expires=" + date.toUTCString();
                            }
                            document.cookie = name + "=" + (value || "") + expires + "; path=/";
                        }

                        // Get cookie value
                        function getCookie(name) {
                            var nameEQ = name + "=";
                            var ca = document.cookie.split(';');
                            for(var i=0;i < ca.length;i++) {
                                var c = ca[i];
                                while (c.charAt(0)==' ') c = c.substring(1,c.length);
                                if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
                            }
                            return null;
                        }

                        // Initialize timer with cookie if exists
                        function initTimer() {
                            var timerCookie = getCookie('paymentTimer');
                            if (timerCookie) {
                                return parseInt(timerCookie);
                            } else {
                                var date = new Date();
                                var now = date.getTime();
                                var endTime = now + 1800000; // 30 minutes
                                setCookie('paymentTimer', endTime, 30);
                                return endTime;
                            }
                        }

                        var endTime = initTimer();

                        $(function (){
                            countTime();       
                        })
                       
                        const myInterval = setInterval(check, 3000);
                        function check(){
                            $.post(base_url + "checksuccesspay?refnum=" + refNo + "&userId=" + userId + "&token=" + token, function(e) {
                                console.log(e)
                                if (e == 1){
                                    clearInterval(myInterval);
                                    setCookie('paymentTimer', '', -1); // Clear cookie
                                    showSuccess("Recharge Successful! Your account has been credited.");
                                    setTimeout(function() {
                                        window.location.href = base_url + "/#/wallet/RechargeHistory";              
                                    }, 2000);
                                }
                                if (e == 2){
                                    clearInterval(myInterval);
                                    setCookie('paymentTimer', '', -1); // Clear cookie
                                    showError("Recharge Failed. Please try again or contact support.");
                                    setTimeout(function() {
                                        window.location.href = base_url + "/#/wallet/RechargeHistory";
                                    }, 2000);
                                }
                            });
                        }

                        function countTime() {
                            var date = new Date();
                            var now = date.getTime();
                            var leftTime = endTime - now;
                            var d,h,m,s;
                            
                            if (leftTime >= 0) {
                                m = Math.floor(leftTime/1000/60%60);
                                s = Math.floor(leftTime/1000%60);
                            } else {
                                m = 0;
                                s = 0;
                                showWarning("Please verify the UTR/Ref No matches the amount, otherwise the transaction may not be confirmed.");
                                setTimeout(function() {
                                    window.location.href="rechargerecord.php";
                                }, 3000);
                            }

                            document.getElementById("_m").innerHTML = m + "m";
                            document.getElementById("_s").innerHTML = (s < 10 ? "0" : "") + s + "s";
                            
                            if (leftTime > 0) {
                                setTimeout(countTime, 1000);
                            }
                        }

                        function showSuccess(message) {
                            $('.payment-icon').html('<i class="fas fa-check-circle"></i>').css({
                                'background-color': 'rgba(34, 197, 94, 0.1)'
                            });
                            $('.payment-icon i').css({
                                'color': 'var(--success)'
                            });
                            $('.payment-title').text('Payment Confirmed');
                            $('.payment-subtitle').text('Your transaction was successful');
                            $('.status-title').text('Transaction Completed');
                            $('.status-description').text('Your account has been credited successfully');
                            $('.btn').html('<i class="fas fa-check"></i> Payment Verified').removeClass('btn-loading');
                            $('.progress-bar').css({
                                'width': '100%',
                                'background-color': 'var(--success)'
                            });
                            
                            showToast('success', message);
                        }
                        
                        function showError(message) {
                            $('.payment-icon').html('<i class="fas fa-times-circle"></i>').css({
                                'background-color': 'rgba(239, 68, 68, 0.1)'
                            });
                            $('.payment-icon i').css({
                                'color': 'var(--danger)'
                            });
                            $('.payment-title').text('Payment Failed');
                            $('.payment-subtitle').text('Transaction could not be completed');
                            $('.status-title').text('Transaction Failed');
                            $('.status-description').text('Please try again or contact support');
                            $('.btn').html('<i class="fas fa-redo"></i> Try Again').removeClass('btn-loading');
                            $('.progress-bar').css({
                                'width': '100%',
                                'background-color': 'var(--danger)'
                            });
                            
                            showToast('error', message);
                        }
                        
                        function showWarning(message) {
                            $('.payment-icon').html('<i class="fas fa-exclamation-circle"></i>').css({
                                'background-color': 'rgba(245, 158, 11, 0.1)'
                            });
                            $('.payment-icon i').css({
                                'color': 'var(--warning)'
                            });
                            $('.payment-title').text('Verification Needed');
                            $('.payment-subtitle').text('Please check transaction details');
                            $('.status-title').text('Attention Required');
                            $('.status-description').text(message);
                            $('.btn').html('<i class="fas fa-info-circle"></i> Check Details').removeClass('btn-loading');
                            $('.progress-bar').css({
                                'width': '100%',
                                'background-color': 'var(--warning)'
                            });
                            
                            showToast('warning', message);
                        }
                        
                        function showToast(type, message) {
                            const toast = document.createElement('div');
                            toast.className = `toast toast-${type}`;
                            toast.innerHTML = `
                                <div class="toast-icon">
                                    <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'times-circle' : 'exclamation-circle'}"></i>
                                </div>
                                <div class="toast-message">${message}</div>
                            `;
                            
                            document.body.appendChild(toast);
                            
                            setTimeout(() => {
                                toast.classList.add('show');
                            }, 100);
                            
                            setTimeout(() => {
                                toast.classList.remove('show');
                                setTimeout(() => {
                                    document.body.removeChild(toast);
                                }, 300);
                            }, 5000);
                        }
                    </script>
                </body>
            </html>
<?php
        }
        else{
            $res['code'] = 10000;
            $res['success'] = 'false';
            $res['message'] = 'Sorry, The system is busy, please try again later!';
            
            header('Content-Type: text/html; charset=utf-8');
            http_response_code(200);
            echo json_encode($res);
        }
    }
    else{
        header('Content-Type: application/json; charset=utf-8');
        http_response_code(200);
        echo json_encode($res);    
    }
?>