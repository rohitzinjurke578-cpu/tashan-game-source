<?php
include ("../serive/samparka.php");

// Log function
function logError($message) {
    file_put_contents('log.txt', date('Y-m-d H:i:s') . " - " . $message . "\n", FILE_APPEND);
}

// Get POST data
$data = $_POST;
logError("Received data: " . json_encode($data));

// Extract required fields
$orderID = $data['client_orderid'] ?? null;
$status = $data['status'] ?? null;
$amount = $data['amount'] ?? null;

if (!$orderID || !$status || !$amount) {
    logError("Error: Missing parameters");
    exit("fail");
}

// Validate transaction in database
$checkQuery = "SELECT motta, balakedara FROM thevani WHERE dharavahi = '$orderID' AND sthiti = '0'";
$checkResult = mysqli_query($conn, $checkQuery);

if ($checkResult && mysqli_num_rows($checkResult) > 0) {
    $row = mysqli_fetch_assoc($checkResult);
    $userID = $row['balakedara'];
    $depositAmount = $row['motta'];

    if ($status == "success") {
        // Update user's balance
        $updateBalance = "UPDATE shonu_kaichila SET motta = motta + $depositAmount WHERE balakedara = '$userID'";
        $conn->query($updateBalance);

        // Mark transaction as completed
        $updateTransaction = "UPDATE thevani SET sthiti = '1' WHERE dharavahi = '$orderID'";
        $conn->query($updateTransaction);
    }
}

exit("ok");
?>
