<?php
return [
    'db_host' => 'localhost',       
    'db_user' => 'yilkwayn_game',  
    'db_pass' => 'yilkwayn_game',  
    'db_name' => 'yilkwayn_game',
    'api_url' => 'https://www.lg-pay.com/api/order/create',
    'secret_key' => 'u2kaZsDpW2bHxtAbkaRp2o5pkRXOiKvN',
    'app_id' => 'YD4195',
    'name' => 'rozwin.site',
];
