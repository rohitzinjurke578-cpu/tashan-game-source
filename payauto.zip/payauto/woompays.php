<?php
header('Content-Type: application/json');
include ("../serive/samparka.php"); // Database connection

// Woompays API Credentials
$api_url = "https://api.woompays.com/v1/pay";
$mchid = "500885792";
$api_key = "vfk2td69xhmap81izqje";
$channel_code = "101"; // Change if needed
$notify_url = "https://56lottery.site/pay/callbackwoompays.php"; // Your callback URL

// Validate required parameters
if (!isset($_GET['amount']) || !isset($_GET['uid'])) {
    die(json_encode(["error" => "Missing required parameters."]));
}

// Get Parameters
$amount = number_format((float) $_GET['amount'], 2, '.', '');
$uid = htmlspecialchars(mysqli_real_escape_string($conn, $_GET['uid']));
$order_id = date("YmdHis") . rand(1000, 9999);

// Validate transaction amount
if ($amount < 100 || $amount > 100000000) {
    die(json_encode(["error" => "Invalid amount. Must be between ¥100 and ¥10,000,000."]));
}

// Fetch user details from database
$userQuery = "SELECT name, bank_name, bank_acc_num, bank_ifsc FROM users WHERE id = '$uid'";
$userResult = $conn->query($userQuery);
if ($userResult->num_rows == 0) {
    die(json_encode(["error" => "User not found."]));
}

$user = $userResult->fetch_assoc();
$real_name = $user['name'];
$bank_name = $user['bank_name'];
$bank_acc_num = $user['bank_acc_num'];
$bank_ifsc = $user['bank_ifsc'];

// Prepare API request data
$data = [
    "mchID" => $mchid,
    "mchorderid" => $order_id,
    "channel_code" => $channel_code,
    "api_key" => $api_key,
    "amount" => $amount,
    "return_url" => "https://56lottery.site/status/rechargeStatus",
    "notify_url" => $notify_url
];

// Send API request using file_get_contents
$options = [
    "http" => [
        "header"  => "Content-Type: application/x-www-form-urlencoded\r\n",
        "method"  => "POST",
        "content" => http_build_query($data),
    ],
];

$context  = stream_context_create($options);
$response = file_get_contents($api_url, false, $context);

// Log response for debugging
file_put_contents('log.txt', date('Y-m-d H:i:s') . " - API Response: " . $response . "\n", FILE_APPEND);

// Handle API response
if ($response === FALSE) {
    die(json_encode(["error" => "API request failed."]));
}

$result = json_decode($response, true);

// Check API response status
if (isset($result['status']) && $result['status'] == "success") {
    // Insert transaction into database
    $created_at = date("Y-m-d H:i:s");
    $insertQuery = "INSERT INTO transactions (user_id, amount, order_id, type, status, created_at) 
                    VALUES ('$uid', '$amount', '$order_id', 'Deposit', 'Pending', '$created_at')";
    $conn->query($insertQuery);

    echo json_encode(["success" => "Transaction initiated.", "order_id" => $order_id]);
} else {
    echo json_encode(["error" => "Transaction failed.", "details" => $result]);
}
?>
