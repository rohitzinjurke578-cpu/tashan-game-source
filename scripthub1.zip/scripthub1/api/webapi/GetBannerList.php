{
    "data": [
        {
            "url": "/#/main/SuperJackpot",
            "bannerUrl": "/banner/1.jpg"
        },
        {
            "url": "/#/activity",
            "bannerUrl": "/banner/2.jpg"
        },
        {
            "url": "/#/promotion/TeamPartner",
            "bannerUrl": "/banner/3.jpg"
        },
        {
            "url": "",
            "bannerUrl": "/banner/4.jpg"
        },
        {
            "url": "/#/main/Laundry",
            "bannerUrl": "/banner/5.jpg"
        },
          {
            "url": "",
            "bannerUrl": "/banner/6.jpg"
        },
        {
            "url": "",
            "bannerUrl": "/banner/7.jpg"
        }
        ,
        {
            "url": "",
            "bannerUrl": "/banner/8.jpg"
        }

        
        ],
    "code": 0,
    "msg": "Succeed",
    "msgCode": 0,
    "serviceNowTime": "2025-02-12 21:57:54"
}