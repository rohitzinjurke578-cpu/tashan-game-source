{
    "data": {
        "id": 45,
        "vendorId": 23,
        "vendorCode": "TB_Chess",
        "iconUrl": "https://56lottery.site/scripthub1/api/webapi/images/turnover.png",
        "categoryType": 0,
        "sumBonus": 103880.00,
        "maxBonus": 15800.00,
        "startTime": "2025-02-14 00:00:00",
        "endTime": "2025-02-14 23:59:59",
        "state": 0,
        "isJoin": false
    },
    "code": 0,
    "msg": "Succeed",
    "msgCode": 0,
    "serviceNowTime": "2025-02-13 00:12:09"
}