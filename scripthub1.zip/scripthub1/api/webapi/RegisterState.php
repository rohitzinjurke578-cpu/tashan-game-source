{
    "data": {
        "isOpenRegisterSMS": "0",
        "isOpenRegisterEmail": "0",
        "registerEmailState": "0",
        "registerMobileState": "1",
        "registerPrivacyChecked": "0",
        "registerStateMsg": null,
        "isOpenForgetPasswordSMS": "1",
        "isOpenForgetPasswordEmail": "0",
        "isOpenAddWithdrawSMS": "0",
        "isOpenAddWithdrawEmail": "0",
        "isOpenCaptcha": "1",
        "isOpenRegisterCaptcha": "0",
        "isOpenGoogleVerifySms": "1",
        "isOpenGoogleVerifyEmail": "0",
        "addBankCardOpenEmail": "0",
        "isOpenExternalAccount": "0",
        "isInvitecode": "1"
    },
    "code": 0,
    "msg": "Succeed",
    "msgCode": 0,
    "serviceNowTime": "2025-02-28 12:26:33"
}