<?php
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'fqckxrbk_vishalbro');
define('DB_PASSWORD', 'fqckxrbk_vishalbro');
define('DB_NAME', 'fqckxrbk_vishalbro');

function getDBConnection() {
    $conn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    return $conn;
}
?>
