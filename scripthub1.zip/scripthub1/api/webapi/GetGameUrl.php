<?php 
include "../../conn.php";
include "../../functions2.php";

// Header setup
header('Content-Type: application/json; charset=utf-8');
header('Strict-Transport-Security: max-age=31536000');
header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, Authorization');
header('Access-Control-Allow-Credentials: true');

$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
header('Access-Control-Allow-Origin: ' . $origin);
header('Vary: Origin');

// Set timezone
date_default_timezone_set("Asia/Kolkata");
$currentTime = date("Y-m-d H:i:s");

// Collect parameters (GET preferred, fallback to POST JSON)
$params = $_GET;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && empty($params)) {
    $rawInput = file_get_contents("php://input");
    $decoded = json_decode($rawInput, true);
    if (is_array($decoded)) {
        $params = $decoded;
    }
}

// Create query string
$queryString = http_build_query($params);

// Final redirection URL
$finalUrl = 'https://56lottery.site/jet?' . $queryString;

// Success response
$response = [
    'code' => 0,
    'msg' => 'Succeed',
    'msgCode' => 0,
    'serviceNowTime' => $currentTime,
    'data' => [
        'url' => $finalUrl,
        'returnType' => 1
    ]
];

// Send response
http_response_code(200);
echo json_encode($response);