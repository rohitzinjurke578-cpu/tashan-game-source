<?php 
	include "../../conn.php";
	include "../../functions2.php";

	// Set timezone
	date_default_timezone_set("Asia/Kolkata");
	$currentTime = date("Y-m-d H:i:s");

	// Handle CORS headers
	$origin = isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : '*';
	header('Access-Control-Allow-Origin: ' . $origin);
	header('Access-Control-Allow-Credentials: true');
	header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, Authorization');
	header('Content-Type: application/json; charset=utf-8');
	header('Strict-Transport-Security: max-age=31536000');
	header('Vary: Origin');

	// STEP 1: Handle GET requests with friendly response
	if ($_SERVER['REQUEST_METHOD'] === 'GET') {
		header("Content-Type: text/plain");
		echo "🔒 This API only accepts POST requests with JSON input.";
		exit;
	}

	// STEP 2: Only allow POST
	if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
		http_response_code(405);
		echo json_encode([
			'code' => 11,
			'msg' => 'Only POST method allowed',
			'msgCode' => 12,
			'serviceNowTime' => $currentTime,
		]);
		exit;
	}

	// STEP 3: Get POST body and decode JSON
	$requestBody = file_get_contents("php://input");
	$requestData = json_decode($requestBody, true);

	// STEP 4: Validate parameters
	if (!isset($requestData['language'], $requestData['random'], $requestData['signature'], $requestData['timestamp'])) {
		http_response_code(400);
		echo json_encode([
			'code' => 7,
			'msg' => 'Missing required parameters',
			'msgCode' => 6,
			'serviceNowTime' => $currentTime,
		]);
		exit;
	}

	// STEP 5: Sanitize inputs
	$language = htmlspecialchars(mysqli_real_escape_string($conn, $requestData['language']));
	$random = htmlspecialchars(mysqli_real_escape_string($conn, $requestData['random']));
	$signature = htmlspecialchars(mysqli_real_escape_string($conn, $requestData['signature']));

	// STEP 6: Validate signature
	$expectedString = '{"language":' . $language . ',"random":"' . $random . '"}';
	$expectedSignature = strtoupper(md5($expectedString));

	if ($signature !== $expectedSignature) {
		http_response_code(401);
		echo json_encode([
			'code' => 5,
			'msg' => 'Wrong signature',
			'msgCode' => 3,
			'serviceNowTime' => $currentTime,
		]);
		exit;
	}

	// STEP 7: Check Authorization header
	if (!isset($_SERVER['HTTP_AUTHORIZATION'])) {
		http_response_code(401);
		echo json_encode([
			'code' => 8,
			'msg' => 'Missing Authorization header',
			'msgCode' => 4,
			'serviceNowTime' => $currentTime,
		]);
		exit;
	}

	$authParts = explode(" ", $_SERVER['HTTP_AUTHORIZATION']);
	$token = $authParts[1] ?? '';

	// STEP 8: Validate JWT
	$jwtValidation = is_jwt_valid($token);
	$authData = json_decode($jwtValidation, true);

	if (!isset($authData['status']) || $authData['status'] !== 'Success') {
		http_response_code(401);
		echo json_encode([
			'code' => 9,
			'msg' => 'Invalid token',
			'msgCode' => 5,
			'serviceNowTime' => $currentTime,
		]);
		exit;
	}

	// STEP 9: Check token in database
	$query = "SELECT akshinak FROM shonu_subjects WHERE akshinak = '$token' LIMIT 1";
	$result = $conn->query($query);

	if ($result && $result->num_rows === 1) {
		// Success response
		echo json_encode([
			'code' => 0,
			'msg' => 'Succeed',
			'msgCode' => 0,
			'serviceNowTime' => $currentTime,
			'data' => [
				[
					'typeID' => 3,
					'typeName' => 'LiveChat'
				]
			]
		]);
	} else {
		// Unauthorized user
		http_response_code(403);
		echo json_encode([
			'code' => 10,
			'msg' => 'Unauthorized user',
			'msgCode' => 7,
			'serviceNowTime' => $currentTime,
		]);
	}
?>